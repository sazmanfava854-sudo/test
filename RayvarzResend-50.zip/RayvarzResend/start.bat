@echo off
cd /d "%~dp0"
echo RayvarzResend v50 — رفع SSO + تمپلیت اکسل
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
