@echo off
cd /d "%~dp0"
echo RayvarzResend v44 — UI تاریخ چک + Guid fix + چک رایورز/واسط
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
