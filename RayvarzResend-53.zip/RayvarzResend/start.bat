@echo off
cd /d "%~dp0"
echo RayvarzResend v53 — ابطال Duty status 2
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
