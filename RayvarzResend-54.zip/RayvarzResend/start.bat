@echo off
cd /d "%~dp0"
echo RayvarzResend v54 — toast ارسال + وضعیت فیش
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
