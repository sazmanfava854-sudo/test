@echo off
cd /d "%~dp0"
echo RayvarzResend v43 — Guid NidInstallment + تاریخ چک + چک رایورز/واسط
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
