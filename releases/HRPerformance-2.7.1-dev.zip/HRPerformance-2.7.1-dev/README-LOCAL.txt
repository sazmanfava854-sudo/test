HR Performance — نسخه توسعه لوکال (سورس کامل)

این ZIP برای کار روی سیستم خودتان است — مثل v2.0.0-simple.

شامل:
  HRPerformance.sln
  src/ (4 پروژه: Domain, Application, Infrastructure, API)
  frontend/hr-performance-web
  database/

پیش‌نیاز: .NET 8 SDK + SQL Server + (اختیاری) Node.js برای UI

─── راه‌اندازی اولین بار ───
1) Extract کنید — ترجیحاً C:\Projects\HRPerformance (نه Downloads)
2) database/01 تا 11 را روی SQL Server اجرا کنید
3) src\HRPerformance.API\appsettings.Development.json — پسورد SQL
4) scripts\restore-packages.bat  (فقط اولین بار — ممکن است چند دقیقه)
5) start-local.bat  یا  HRPerformance.sln را در Cursor باز کنید

─── اجراهای بعدی ───
  start-local.bat  → بدون Build مجدد (--no-build)
  یا F5 در Cursor/Visual Studio

─── توسعه UI ───
  cd frontend\hr-performance-web
  npm install
  npm run dev

لاگین: admin / Admin@123
