HR Performance — نسخه لوکال (کامل)

پیش‌نیاز: .NET 8 SDK + SQL Server

1) database/01 تا 12 را روی SQL Server اجرا کنید
2) src/HRPerformance.API/appsettings.Development.json را تنظیم کنید
3) start-local.bat (ویندوز) یا start.sh (لینوکس)
4) http://localhost:5050

سینک MIS:
  POST /api/attendancesync/run
  GET  /api/attendancesync/diagnostic

توسعه UI (اختیاری):
  cd frontend/hr-performance-web
  npm install && npm run dev
