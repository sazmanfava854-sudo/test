HR Performance — نسخه لوکال (معماری v2.0.0-simple + فیلتر تاریخ MIS)

پیش‌نیاز: .NET 8 SDK + SQL Server

1) database/01 تا 11 را روی SQL Server اجرا کنید
2) src/HRPerformance.API/appsettings.Development.json را تنظیم کنید
3) start-local.bat (ویندوز) یا start.sh (لینوکس)
4) http://localhost:5050

سینک MIS (فقط دستی از UI):
  تنظیمات > دریافت از MIS > انتخاب بازه تاریخ > دریافت داده

توسعه UI (اختیاری):
  cd frontend/hr-performance-web
  npm install && npm run dev
