@echo off
cd /d "%~dp0"
echo RayvarzResend v45 — شاهکار security10 + UI تاریخ چک
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
