@echo off
cd /d "%~dp0"
echo RayvarzResend v35 — نسخه آخر (تهاتر درآمدی DTL — گروه 158)
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
