using Microsoft.Data.SqlClient;
using RayvarzResend.Web.Models;

namespace RayvarzResend.Web.Services;

public class FicheRepository
{
    private const string NosaziNickSql = """
        CAST(b.District AS varchar) + '-' + CAST(b.Region AS varchar) + '-' +
        CAST(b.Block AS varchar) + '-' + CAST(b.House AS varchar) + '-' +
        CAST(b.Building AS varchar) + '-' + CAST(b.Apartment AS varchar) + '-' +
        ISNULL(NULLIF(CAST(b.Shop AS varchar), ''), '0')
        """;

    private readonly string _saraCs;
    private readonly string _rayCs;

    public FicheRepository(IConfiguration config)
    {
        _saraCs = config.GetConnectionString("Sara") ?? throw new InvalidOperationException("ConnectionStrings:Sara not set");
        _rayCs = config.GetConnectionString("Rayvarz") ?? throw new InvalidOperationException("ConnectionStrings:Rayvarz not set");
    }

    public async Task<FicheHeaderDto?> LoadAsync(IdentifierType type, string value, CancellationToken ct = default)
    {
        var income = await TryLoadIncomeAsync(type, value, ct);
        if (income != null) return income;
        return await TryLoadDutyAsync(type, value, ct);
    }

    /// <summary>
    /// جفت تهاتر: دو ردیف Income_Fiche با همان NidIncome — گروه ۱۵۷ (Tahator1) و ۱۵۸ (Tahator).
    /// </summary>
    public async Task<TahatorPairInfo?> ResolveTahatorPairAsync(string ficheNo, CancellationToken ct = default)
    {
        ficheNo = TahatorRowBuilder.NormalizeFicheNo(ficheNo);
        var seed = await LoadAsync(IdentifierType.FicheNo, ficheNo, ct);
        if (seed?.NidIncome is not { } nid || nid == Guid.Empty)
            return null;
        if (!TahatorRowBuilder.IsTahatorFiche(seed))
            return null;

        const string sql = @"
SELECT FicheNo, CI_IncomeAccountGroup, EumFicheStatus, NidExportation, Payable
FROM dbo.Income_Fiche
WHERE NidIncome = @nid
  AND CI_IncomeAccountGroup IN (@g157, @g158)";

        var candidates = new List<TahatorPairResolver.Candidate>();

        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@nid", nid);
        cmd.Parameters.AddWithValue("@g157", TahatorRowBuilder.IncomeAccountGroupTahatorAmount);
        cmd.Parameters.AddWithValue("@g158", TahatorRowBuilder.IncomeAccountGroupTahatorIncome);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var exportOrd = reader.GetOrdinal("NidExportation");
            candidates.Add(new TahatorPairResolver.Candidate(
                reader.GetString(reader.GetOrdinal("FicheNo")).Trim(),
                ReadInt32(reader, "CI_IncomeAccountGroup"),
                ReadInt32(reader, "EumFicheStatus"),
                reader.IsDBNull(exportOrd) ? Guid.Empty : reader.GetGuid(exportOrd),
                ReadDecimal(reader, "Payable")));
        }

        var seedRow = candidates.FirstOrDefault(c =>
            string.Equals(c.FicheNo, ficheNo, StringComparison.Ordinal));
        if (seedRow == null)
            return null;

        var resolved = TahatorPairResolver.Resolve(
            candidates,
            ficheNo,
            seed.IncomeAccountGroup ?? seedRow.IncomeAccountGroup,
            seedRow.NidExportation,
            seedRow.Payable);
        if (resolved == null)
            return null;

        var amountNo = resolved.Value.AmountFicheNo;
        var incomeNo = resolved.Value.IncomeFicheNo;

        var amountFiche = string.Equals(amountNo, ficheNo, StringComparison.Ordinal)
            && TahatorRowBuilder.IsTahatorAmountFiche(seed)
            ? seed
            : await LoadAsync(IdentifierType.FicheNo, amountNo, ct);
        var incomeFiche = string.Equals(incomeNo, ficheNo, StringComparison.Ordinal)
            && TahatorRowBuilder.IsTahatorIncomeFiche(seed)
            ? seed
            : await LoadAsync(IdentifierType.FicheNo, incomeNo, ct);

        if (amountFiche == null || incomeFiche == null)
            return null;

        return new TahatorPairInfo
        {
            NidIncome = nid,
            AmountFicheNo = amountFiche.FicheNo.Trim(),
            IncomeFicheNo = incomeFiche.FicheNo.Trim(),
            AmountFiche = amountFiche,
            IncomeFiche = incomeFiche
        };
    }

    private async Task<FicheHeaderDto?> TryLoadIncomeAsync(IdentifierType type, string value, CancellationToken ct)
    {
        var where = type == IdentifierType.FicheNo
            ? "f.FicheNo = @val"
            : "f.BillID + f.PaymentID = @val";

        var sql = $@"
SELECT f.FicheNo, f.BillID, f.PaymentID, f.Payable, f.NidFiche, f.NidIncome,
       i.NidProc,
       ISNULL(f.Brokers, 0) AS Brokers,
       NULLIF(LTRIM(RTRIM(CAST(f.PaymentBranch AS nvarchar(20)))), '') AS PaymentBranch,
       NULLIF(LTRIM(RTRIM(CAST(f.CI_Bank AS nvarchar(20)))), '') AS CiBank,
       NULLIF(LTRIM(RTRIM(CAST(f.PaymentBank AS nvarchar(20)))), '') AS PaymentBank,
       NULLIF(LTRIM(RTRIM(CAST(f.Deposit AS nvarchar(50)))), '') AS Deposit,
       NULLIF(LTRIM(RTRIM(CAST(f.DepositID AS nvarchar(50)))), '') AS DepositID,
       NULLIF(LTRIM(RTRIM(CAST(f.CreditorPapers AS nvarchar(50)))), '') AS CreditorPapers,
       CAST(f.CheckNo AS nvarchar(20)) AS CheckNo,
       COALESCE(f.BankPaymentDate, f.PaymentDate) AS RowDate,
       f.PaymentDate,
       f.BankPaymentDate,
       f.EumFicheStatus, f.CI_IncomeAccountGroup,
       CAST(r.NidWorkItem AS nvarchar(50)) AS RefReconstructionNo,
       ISNULL(
         NULLIF(LTRIM(RTRIM({NosaziNickSql})), '-'),
         ''
       ) AS BnkAcntNo,
       NULLIF(LTRIM(RTRIM(CAST(b.District AS nvarchar(20)))), '') AS IncomeRegion
FROM dbo.Income_Fiche f
JOIN dbo.Income i ON i.NidIncome = f.NidIncome
LEFT JOIN dbo.Sh_RequestInfo r ON r.NidProc = i.NidProc
LEFT JOIN dbo.Base_NosaziCode b ON b.NidNosaziCode = r.NidNosaziCode
WHERE {where}";

        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@val", value.Trim());

        await using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct)) return null;

        var group = ReadInt32(reader, "CI_IncomeAccountGroup");
        var isTahatorAmount = group == TahatorRowBuilder.IncomeAccountGroupTahatorAmount;
        var isTahatorIncome = group == TahatorRowBuilder.IncomeAccountGroupTahatorIncome;
        var isTahator = isTahatorAmount || isTahatorIncome;
        var docTyp = group == 150
            ? 11
            : isTahatorAmount
                ? 14
                : isTahatorIncome
                    ? 18
                    : 3;
        var ciBank = reader.IsDBNull(reader.GetOrdinal("CiBank")) ? null : reader.GetString(reader.GetOrdinal("CiBank"));
        var paymentBank = reader.IsDBNull(reader.GetOrdinal("PaymentBank")) ? null : reader.GetString(reader.GetOrdinal("PaymentBank"));
        var paymentBranch = reader.IsDBNull(reader.GetOrdinal("PaymentBranch"))
            ? null
            : reader.GetString(reader.GetOrdinal("PaymentBranch"));

        var dto = new FicheHeaderDto
        {
            Category = FicheCategory.Income,
            FicheNo = reader.GetString(reader.GetOrdinal("FicheNo")),
            BillIdRaw = reader.GetString(reader.GetOrdinal("BillID")).Trim(),
            PaymentIdRaw = reader.GetString(reader.GetOrdinal("PaymentID")).Trim(),
            BillId = reader.GetString(reader.GetOrdinal("BillID")),
            PaymentId = reader.GetString(reader.GetOrdinal("PaymentID")),
            Payable = ReadDecimal(reader, "Payable"),
            Brokers = ReadDecimal(reader, "Brokers"),
            NidFiche = reader.GetGuid(reader.GetOrdinal("NidFiche")),
            NidIncome = reader.GetGuid(reader.GetOrdinal("NidIncome")),
            NidProc = reader.IsDBNull(reader.GetOrdinal("NidProc"))
                ? null
                : reader.GetGuid(reader.GetOrdinal("NidProc")),
            PaymentBranch = paymentBranch ?? (isTahator ? "" : "18"),
            BankCode = isTahator
                ? (ciBank ?? paymentBank ?? paymentBranch)
                : (paymentBank ?? ciBank ?? paymentBranch ?? "18"),
            Deposit = ReadNullableInt64(reader, "Deposit"),
            DepositId = ReadNullableInt64(reader, "DepositID"),
            CreditorPapers = ReadNullableInt64(reader, "CreditorPapers"),
            CheckNo = reader.IsDBNull(reader.GetOrdinal("CheckNo")) ? null : reader.GetString(reader.GetOrdinal("CheckNo")),
            RowDate = ReadRowDate(reader, "RowDate"),
            CurrentStatus = ReadInt32(reader, "EumFicheStatus"),
            IncomeAccountGroup = group,
            RefReconstructionNo = reader.IsDBNull(reader.GetOrdinal("RefReconstructionNo")) ? null : reader.GetString(reader.GetOrdinal("RefReconstructionNo")),
            BnkAcntNo = reader.IsDBNull(reader.GetOrdinal("BnkAcntNo")) ? "" : reader.GetString(reader.GetOrdinal("BnkAcntNo")),
            BnkAcntNoSource = "کد نوسازی — GetNosaziNickName (منطقه-حوزه-بلوک-ملک-ساختمان-آپارتمان-واحد)",
            IncomeRegion = reader.IsDBNull(reader.GetOrdinal("IncomeRegion")) ? null : reader.GetString(reader.GetOrdinal("IncomeRegion")),
            DocTyp = docTyp,
            DocDsc = isTahatorAmount
                ? "اسناد تهاتر مبلغ"
                : isTahatorIncome
                    ? "اسناد تهاتر درامد"
                    : "اسناد شهرسازی"
        };

        var districtBranch = DutyDistrictBranchResolver.ResolveBranch(dto.BillIdRaw, dto.PaymentIdRaw);
        if (districtBranch > 0)
        {
            dto.ResolvedDistrictBranch = districtBranch;
            if (!isTahatorAmount && !isTahatorIncome)
                dto.SuggestedFund = DutyDistrictBranchResolver.ResolveFund(districtBranch, dto.BankCode ?? "18");
        }

        if (isTahatorAmount)
            TahatorRowBuilder.ApplyTahatorAmountRows(dto);
        else if (isTahatorIncome)
            TahatorRowBuilder.ApplyTahatorIncomeRows(dto);
        else
        {
            dto.Rows = await LoadIncomeRowsAsync(dto.NidIncome!.Value, ct);
            await IncomeFicheSupplementLoader.EnrichAsync(dto, _saraCs, LoadIncomeRowsAsync, ct);
            IncomeMember1388RowBuilder.Apply(dto);
        }
        FicheDateResolver.ApplyFromIncomeColumns(
            dto,
            dto.CurrentStatus,
            ReadRowDate(reader, "PaymentDate"),
            ReadRowDate(reader, "BankPaymentDate"),
            tahatorFiche: isTahator);
        return dto;
    }

    private async Task<List<IncmRowDto>> LoadIncomeRowsAsync(Guid nidIncome, CancellationToken ct)
    {
        const string sql = @"
SELECT ic.CI_IncomeCalculation AS IncmNo,
       COALESCE(ic.SysValue, ic.Value) AS Val,
       ISNULL(c.Title, '') AS IncmRowDsc
FROM dbo.Income_Calculation ic
LEFT JOIN dbo.CI_IncomeCalculation c ON c.ID = ic.CI_IncomeCalculation
WHERE ic.NidIncome = @nid";

        var rows = new List<IncmRowDto>();
        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@nid", nidIncome);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var incmNo = ReadInt32(reader, "IncmNo");
            if (IncomeExcludedCodes.Codes.Contains(incmNo)) continue;
            var val = ReadDecimal(reader, "Val");
            if (val == 0) continue;
            rows.Add(new IncmRowDto
            {
                IncmNo = incmNo,
                Val = val,
                IncmRowDsc = reader.GetString(reader.GetOrdinal("IncmRowDsc"))
            });
        }

        return rows;
    }

    private async Task<FicheHeaderDto?> TryLoadDutyAsync(IdentifierType type, string value, CancellationToken ct)
    {
        var where = type == IdentifierType.FicheNo
            ? "d.FicheNo = @val"
            : "d.BillID + d.PaymentID = @val";

        var sql = $@"
SELECT d.FicheNo, d.BillID, d.PaymentID, d.PayablePrice AS Payable, d.NidFiche,
       d.EumDutyType,
       '18' AS PaymentBranch,
       NULLIF(LTRIM(RTRIM(CAST(d.ConfirmBankCode AS nvarchar(20)))), '') AS BankCode,
       COALESCE(d.BankPaymentDate, d.PaymentDate, d.PrintDate, d.ExportDate) AS RowDate,
       d.PaymentDate,
       d.BankPaymentDate,
       d.PrintDate,
       d.ExportDate,
       d.EumDutyFicheStatus, d.CI_DutyFicheExportType,
       COALESCE(
           NULLIF(LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""کد نوسازی""]/Value)[1]', 'nvarchar(100)'))), ''),
           NULLIF(LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""کد نوسازي""]/Value)[1]', 'nvarchar(100)'))), ''),
           LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""منطقه""]/Value)[1]', 'nvarchar(20)'))) + '-' +
           LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""حوزه""]/Value)[1]', 'nvarchar(20)'))) + '-' +
           LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""بلوک""]/Value)[1]', 'nvarchar(20)'))) + '-' +
           LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""ملک""]/Value)[1]', 'nvarchar(20)'))) + '-' +
           ISNULL(NULLIF(LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""ساختمان""]/Value)[1]', 'nvarchar(20)'))), ''), '0') + '-' +
           ISNULL(NULLIF(LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""آپارتمان""]/Value)[1]', 'nvarchar(20)'))), ''), '0') + '-' +
           ISNULL(NULLIF(LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""واحد صنفی""]/Value)[1]', 'nvarchar(20)'))), ''), '0')
       ) AS BnkAcntNo,
       NULLIF(LTRIM(RTRIM(d.OtherFields.value('(//ClsLog[Subject=""منطقه""]/Value)[1]', 'nvarchar(20)'))), '') AS DutyRegion
FROM dbo.Duty_Fiche d
WHERE {where}";

        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@val", value.Trim());

        await using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct)) return null;

        var exportType = reader.IsDBNull(reader.GetOrdinal("CI_DutyFicheExportType"))
            ? 0 : ReadInt32(reader, "CI_DutyFicheExportType");
        var dutyType = ReadInt32(reader, "EumDutyType");
        var isSenfi = DutyNosaziLogic.IsSenfiObjOnPrice(dutyType);
        var rawBill = reader.GetString(reader.GetOrdinal("BillID"));
        var rawPayment = reader.GetString(reader.GetOrdinal("PaymentID"));
        var bankCode = reader.IsDBNull(reader.GetOrdinal("BankCode"))
            ? "18"
            : DutyNosaziLogic.DefaultBankCode(reader.GetString(reader.GetOrdinal("BankCode")));
        var dutyStatus = ReadInt32(reader, "EumDutyFicheStatus");
        var paymentDateRay = ReadRowDate(reader, "PaymentDate");
        var bankPaymentDateRay = ReadRowDate(reader, "BankPaymentDate");
        var nidFiche = reader.GetGuid(reader.GetOrdinal("NidFiche"));

        var dto = new FicheHeaderDto
        {
            Category = isSenfi ? FicheCategory.DutySenfi : FicheCategory.DutyNosazi,
            FicheNo = reader.GetString(reader.GetOrdinal("FicheNo")),
            BillIdRaw = rawBill.Trim(),
            PaymentIdRaw = rawPayment.Trim(),
            BillId = DutyNosaziLogic.NormalizeMergedId(rawBill),
            PaymentId = DutyNosaziLogic.NormalizeMergedId(rawPayment),
            Payable = ReadDecimal(reader, "Payable"),
            NidFiche = nidFiche,
            PaymentBranch = bankCode,
            BankCode = bankCode,
            RowDate = ReadRowDate(reader, "RowDate"),
            CurrentStatus = dutyStatus,
            DutyExportType = exportType,
            BnkAcntNo = reader.IsDBNull(reader.GetOrdinal("BnkAcntNo")) ? "" : reader.GetString(reader.GetOrdinal("BnkAcntNo")),
            BnkAcntNoSource = "کد نوسازی — از Duty_Fiche.OtherFields (XML فیش)",
            DutyRegion = reader.IsDBNull(reader.GetOrdinal("DutyRegion")) ? null : reader.GetString(reader.GetOrdinal("DutyRegion")),
            DocTyp = isSenfi ? 2 : 1,
            DocDsc = isSenfi ? "اسناد صنفی" : "اسناد نوسازی"
        };

        var districtBranch = DutyDistrictBranchResolver.ResolveBranch(rawBill, rawPayment);
        if (districtBranch > 0)
        {
            dto.ResolvedDistrictBranch = districtBranch;
            dto.SuggestedFund = DutyDistrictBranchResolver.ResolveFund(districtBranch, bankCode);
        }

        if (!isSenfi)
        {
            var nickResult = await TryLoadNosaziNickNameAsync(nidFiche, ct);
            NosaziNickNameLogic.ApplyLoadResult(dto, nickResult.Nick, nickResult.LoadError);
        }

        if (isSenfi)
        {
            dto.BnkAcntNo = "7-14-55-1-1-0-1";
            dto.BnkAcntNoSource = "کد ثابت صنفی — Rayvarz (7-14-55-1-1-0-1)";
        }

        await DutyFicheSupplementLoader.EnrichAsync(dto, _saraCs, dutyType, ct);

        dto.Rows = await LoadDutyRowsAsync(
            dto.NidFiche, dto.Payable, isSenfi, exportType, dto.DutyOddments, dto.FicheNo, ct);
        DutyNosaziLogic.ApplyRayvarzDates(dto, dutyStatus, paymentDateRay, bankPaymentDateRay);
        return dto;
    }

    private async Task<List<IncmRowDto>> LoadDutyRowsAsync(
        Guid nidFiche,
        decimal payable,
        bool isSenfi,
        int exportType,
        IReadOnlyList<DutyOddmentDto> dutyOddments,
        string ficheNo,
        CancellationToken ct)
    {
        const string sql = @"
SELECT CI_DutyFormula, CI_DutyFormulaFiche, Price
FROM dbo.Duty_FicheSub
WHERE NidFiche = @nid";

        var subs = new List<(int Formula, int Fiche, decimal Price)>();
        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@nid", nidFiche);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            subs.Add((
                ReadInt32(reader, "CI_DutyFormula"),
                reader.IsDBNull(reader.GetOrdinal("CI_DutyFormulaFiche")) ? 0 : ReadInt32(reader, "CI_DutyFormulaFiche"),
                ReadDecimal(reader, "Price")
            ));
        }

        DutyOddmentLogic.ApplyToSubs(subs, dutyOddments, ficheNo);

        var amounts = DutyNosaziLogic.CalculateSubAmounts(subs, payable);
        return DutyNosaziLogic.BuildIncmRows(amounts, isSenfi, exportType);
    }

    private async Task<(string? Nick, string? LoadError)> TryLoadNosaziNickNameAsync(Guid nidFiche, CancellationToken ct)
    {
        const string sql = @"
SELECT TOP 1
  CAST(b.District AS varchar) + '-' + CAST(b.Region AS varchar) + '-' +
  CAST(b.Block AS varchar) + '-' + CAST(b.House AS varchar) + '-' +
  CAST(b.Building AS varchar) + '-' + CAST(b.Apartment AS varchar) + '-' +
  ISNULL(NULLIF(CAST(b.Shop AS varchar), ''), '0') AS Nick
FROM dbo.Duty_FicheSub fs
INNER JOIN dbo.Base_NosaziCode b ON b.NidNosaziCode = fs.NidFK
WHERE fs.NidFiche = @nid
ORDER BY fs.CI_DutyFormula, fs.CI_DutyFormulaFiche";

        try
        {
            await using var conn = new SqlConnection(_saraCs);
            await conn.OpenAsync(ct);
            await using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@nid", nidFiche);
            var result = await cmd.ExecuteScalarAsync(ct);
            var s = result?.ToString()?.Trim();
            var nick = string.IsNullOrWhiteSpace(s) || s == "-------0" ? null : s;
            return (nick, null);
        }
        catch (SqlException ex)
        {
            return (null, NosaziNickNameLogic.FormatSqlFailureWarning(ex.Message));
        }
    }

    public async Task<bool> ExistsInRayvarzAsync(string ficheNo, int? shamsiYear = null, CancellationToken ct = default)
    {
        ficheNo = TahatorRowBuilder.NormalizeFicheNo(ficheNo.Trim());
        if (await QueryExistsInRayvarzAsync(ficheNo, shamsiYear, docTypFilter: null, ct))
            return true;

        if (shamsiYear is > 0)
            return await QueryExistsInRayvarzAsync(ficheNo, shamsiYear: null, docTypFilter: null, ct);

        return false;
    }

    /// <summary>تهاتر: RowDocNo + DocTyp ۱۴|۱۵ (مبلغ) یا ۱۷|۱۸ (درآمد) — نه Ref عمومی.</summary>
    public async Task<bool> ExistsTahatorDocumentInRayvarzAsync(
        string ficheNo,
        bool isAmountPath,
        int? shamsiYear = null,
        CancellationToken ct = default)
    {
        ficheNo = TahatorRowBuilder.NormalizeFicheNo(ficheNo.Trim());
        var docTypes = isAmountPath ? new[] { 14, 15 } : new[] { 17, 18 };
        if (await QueryExistsInRayvarzAsync(ficheNo, shamsiYear, docTypes, ct))
            return true;

        if (shamsiYear is > 0)
            return await QueryExistsInRayvarzAsync(ficheNo, shamsiYear: null, docTypes, ct);

        return false;
    }

    public async Task<bool> ExistsTahatorDocumentInRayvarzRobustAsync(
        string ficheNo,
        bool isAmountPath,
        IEnumerable<int> yearCandidates,
        CancellationToken ct = default)
    {
        foreach (var year in yearCandidates.Distinct().Where(y => y > 0))
        {
            if (await ExistsTahatorDocumentInRayvarzAsync(ficheNo, isAmountPath, year, ct))
                return true;
        }

        return await ExistsTahatorDocumentInRayvarzAsync(ficheNo, isAmountPath, shamsiYear: null, ct);
    }

    private async Task<bool> QueryExistsInRayvarzAsync(
        string ficheNo,
        int? shamsiYear,
        int[]? docTypFilter,
        CancellationToken ct)
    {
        var sql = docTypFilter is { Length: > 0 }
            ? shamsiYear is > 0
                ? """
                  SELECT TOP 1 1 FROM ray.incmdocsys
                  WHERE yr = @yr AND RowDocNo = @f AND DocTyp IN (@d0, @d1)
                  """
                : """
                  SELECT TOP 1 1 FROM ray.incmdocsys
                  WHERE RowDocNo = @f AND DocTyp IN (@d0, @d1)
                  """
            : shamsiYear is > 0
                ? """
                  SELECT TOP 1 1 FROM ray.incmdocsys
                  WHERE yr = @yr AND (Ref = @f OR RowDocNo = @f)
                  """
                : """
                  SELECT TOP 1 1 FROM ray.incmdocsys
                  WHERE Ref = @f OR RowDocNo = @f
                  """;

        await using var conn = new SqlConnection(_rayCs);
        await conn.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@f", ficheNo);
        if (shamsiYear is > 0)
            cmd.Parameters.AddWithValue("@yr", shamsiYear.Value);
        if (docTypFilter is { Length: > 0 })
        {
            cmd.Parameters.AddWithValue("@d0", docTypFilter[0]);
            cmd.Parameters.AddWithValue("@d1", docTypFilter[1]);
        }

        var result = await cmd.ExecuteScalarAsync(ct);
        return result != null;
    }

    public async Task ResetStatusAsync(FicheHeaderDto fiche, CancellationToken ct = default)
    {
        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);

        if (fiche.Category == FicheCategory.Income)
        {
            const string sql = @"UPDATE dbo.Income_Fiche SET EumFicheStatus = 2
WHERE FicheNo = @f AND EumFicheStatus IN (5, 7)";
            await using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@f", fiche.FicheNo);
            await cmd.ExecuteNonQueryAsync(ct);
        }
        else
        {
            const string sql = @"UPDATE dbo.Duty_Fiche SET EumDutyFicheStatus = 1
WHERE FicheNo = @f AND EumDutyFicheStatus = 4";
            await using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@f", fiche.FicheNo);
            await cmd.ExecuteNonQueryAsync(ct);
        }
    }

    public async Task<string?> GetDocNotSentErrorAsync(string ficheNo, CancellationToken ct = default)
    {
        const string sql = @"
SELECT TOP 1 Comment FROM dbo.Accounting_DocNotSent
WHERE FicheNo = @f ORDER BY Uptime DESC";

        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);
        await using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@f", ficheNo);
        var result = await cmd.ExecuteScalarAsync(ct);
        return result as string;
    }

    private static long? ReadNullableInt64(SqlDataReader reader, string column)
    {
        var ord = reader.GetOrdinal(column);
        if (reader.IsDBNull(ord)) return null;
        var text = reader.GetString(ord).Trim();
        return long.TryParse(text, out var value) ? value : null;
    }

    private static int ReadInt32(SqlDataReader reader, string column)
    {
        var ord = reader.GetOrdinal(column);
        if (reader.IsDBNull(ord)) return 0;
        return Convert.ToInt32(reader.GetValue(ord));
    }

    private static decimal ReadDecimal(SqlDataReader reader, string column)
    {
        var ord = reader.GetOrdinal(column);
        if (reader.IsDBNull(ord)) return 0;
        return Convert.ToDecimal(reader.GetValue(ord));
    }

    private static string ReadRowDate(SqlDataReader reader, string column)
    {
        var ord = reader.GetOrdinal(column);
        if (reader.IsDBNull(ord)) return "";
        var value = reader.GetValue(ord);
        return value switch
        {
            DateTime => DateHelper.FromDatabaseDateValue(value),
            _ => DateHelper.ToRayvarzDate(value.ToString() ?? "")
        };
    }
}
