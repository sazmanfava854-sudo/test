
Dim M_ShahrsaziArchiveGroup as Integer
Dim LstIncmDet As New List(Of DtoSC.Income_Calculation)
<DisplayName("اجراي فرمول")> Public Function Run() As clsOut

    Try
 ' Call FnSMS("Ray")
 'Exit Function
   ' logfilefj("رایورز","رایورز")
 M_ShahrsaziArchiveGroup=0
  
   
       ' if   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo ="030132823378"   Then   Call FnSMS("sara10" & Info8.GetAccountingDocCreateParameter.AccountingDocumentingCause ) :Exit Function
        If Info8.GetAccountingDocCreateParameter.AccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm) Then
            
            If Info8.GetAccountingDocCreateParameter.ObjOnPrice = BIZ.SA.ClsEnum.EumObjOnPrice.Income Then
                
			'	if Info8.User.UserGuid.ToString() <> "540d119d-14f1-4f65-94d1-7f39fc2b3b48" Then
			'	 	Exit Function
			'	 Else
			
                	Call iNcOME()
            
                    Call IncomeHoushmand()
                    Call IncomeSrvElectronic()
                	Call iNcOMESeprdeh()
               ' 	
                	Call iNcOMEEshghal()
                	Call iNcOMEGhatar_Shahri()
                	Call iNcOMEBackSeprdeh()
                	Call iNcOMEOragh()
                	Call iNcOMEHavaleT()
                
                	Call BazAfarine()
                	Call Tahator1()
                	Call Tahator()
             '   End if	
               

            Else
                

                Call Nosazi()
            End If
         ElseIf Info8.GetAccountingDocCreateParameter.AccountingDocumentingCause = 7 Then 
           
           Call iNcOMECheck()
        End If    
       
   Catch ex As Exception
      'Info8.AddError(BIZ.SA.EumErrorAction.Stop, " * توجه", "اشکال در ارسال به رایورز" & ex.tostring())
    End Try


    
End Function


<DisplayName("نوسازی")> Public Function Nosazi()

  '  Try
		
        Dim TmpDocument As New Biz.Communication.ClsAccounting
        Dim tmpstr As String=""
        Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)
        Dim PParamName As New List(Of String)
        Dim PParamValue As New List(Of String)
        Dim DistrickBranch As String = 0
        Dim ChekMoredi As Integer = 0

       
        Dim ExistRayvarz As Boolean =False
      
      '  ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
      
      if Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.EumDutyFicheStatus <> 4 And Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.CI_DutyFicheExportType<> 15 Then  ExistRayvarz=True
    ExistRayvarz  =False
    
        If ExistRayvarz = False Then
            Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID.Substring(8, 3)

            If PtmpDistrict = "051" Then
                DistrickBranch = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentId.Substring(9, 2)
                If DistrickBranch > 12 And DistrickBranch <> 80 Then DistrickBranch = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentId.Substring(10, 1)
            End If


            Select Case PtmpDistrict
                Case "511"
                	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
                		DistrickBranch = 201
                	Else
                    	DistrickBranch = 1
                    End if	
                Case "512"
                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                	DistrickBranch = 202
	                Else
	                   	DistrickBranch = 2
	                 End if	
                Case "513"
                	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
                    	DistrickBranch =203
                    Else
        				DistrickBranch = 3
	                End if	
                Case "514"
                   	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
                    	DistrickBranch =204
                    Else
        				DistrickBranch = 4
	                End if	
                Case "515"
                   	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    	DistrickBranch =205
                    Else
        				DistrickBranch = 5
	                End if	
                Case "516"
                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
                    	DistrickBranch =206
                    Else
        				DistrickBranch = 6
	                End if	
                Case "517"
                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
                    	DistrickBranch =207
                    Else
        				DistrickBranch = 7
	                End if	
                Case "518"
                     if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
                     	DistrickBranch =208
                     Else
        				DistrickBranch = 8
	                 End if	
                Case "519"
                     if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
                     	DistrickBranch =209
                     Else
        				DistrickBranch = 9
	                 End if	
                Case "520"
                   if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                Case "521"
                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
                     	DistrickBranch =211
                     Else
        				DistrickBranch = 11
	                 End if	
                Case "522"
                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
                     	DistrickBranch =212
                     Else
        				DistrickBranch = 12
	                 End if	
                Case "523"
                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
            End Select
           
            if DistrickBranch =0 Then 
            
		            Select Case Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID.Substring(0, 2)
		                Case "01"
		                	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
		                		DistrickBranch = 201
		                	Else
		                    	DistrickBranch = 1
		                    End if	
		                Case "02"
		                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
			                	DistrickBranch = 202
			                Else
			                   	DistrickBranch = 2
			                 End if	
		                Case "03"
		                	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
		                    	DistrickBranch =203
		                    Else
		        				DistrickBranch = 3
			                End if	
		                Case "04"
		                   	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
		                    	DistrickBranch =204
		                    Else
		        				DistrickBranch = 4
			                End if	
		                Case "05"
		                   	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
		                    	DistrickBranch =205
		                    Else
		        				DistrickBranch = 5
			                End if	
		                Case "06"
		                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
		                    	DistrickBranch =206
		                    Else
		        				DistrickBranch = 6
			                End if	
		                Case "07"
		                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
		                    	DistrickBranch =207
		                    Else
		        				DistrickBranch = 7
			                End if	
		                Case "08"
		                     if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
		                     	DistrickBranch =208
		                     Else
		        				DistrickBranch = 8
			                 End if	
		                Case "09"
		                     if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
		                     	DistrickBranch =209
		                     Else
		        				DistrickBranch = 9
			                 End if	
		                Case "10"
		                   if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
		                     	DistrickBranch =210
		                     Else
		        				DistrickBranch = 10
			                 End if	
		                Case "11"
		                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
		                     	DistrickBranch =211
		                     Else
		        				DistrickBranch = 11
			                 End if	
		                Case "12"
		                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
		                     	DistrickBranch =212
		                     Else
		        				DistrickBranch = 12
			                 End if	
		                Case "80"
		                    if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
			                   	DistrickBranch =218
			                 Else
			        			DistrickBranch = 80
				             End if	
		            End Select
              End if
             
            If Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.FicheNo <> "1" Then
				
                Dim TmpAcc As New Biz.Communication.ClsAccountingDocMessage
                Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)

                Dim DtoAccounting_DocHeader As New Biz.Communication.DataAccess.Accounting_DocHeader

                Dim TmpDocDetails As New Biz.Communication.DataAccess.Accounting_DocDetails
                Dim TmpAccounting_DocDetailsList As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)


                DtoAccounting_DocHeader.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                DtoAccounting_DocHeader.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                DtoAccounting_DocHeader.SaraPrice = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PayablePrice)
                DtoAccounting_DocHeader.PhasType = 7
                
                Dim  AtashNeshsni as Double
                AtashNeshsni=0
                
                Dim  Garbage as Double
                Garbage=0
                
                Dim  Afzodeh as Double
                Afzodeh=0
 ''''''''''''''''''''''Afzodeh
				Dim tmpDutyFicheSubList As New List(Of DtoSC.Duty_FicheSub)
				Dim tmpDutyFicheSubListAfzodeh As New List(Of DtoSC.Duty_FicheSub)
                tmpDutyFicheSubList = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_FicheSub
             	tmpDutyFicheSubListAfzodeh = tmpDutyFicheSubList.where (Function (f) f.CI_DutyFormula=3 And f.CI_DutyFormulaFiche=16).tolist
				Afzodeh=tmpDutyFicheSubListAfzodeh.sum(Function(f) f.price)
			
                
''''''''''''''''''''''AtashNeshsni
				
				Dim tmpDutyFicheSubListAtashNeshsni As New List(Of DtoSC.Duty_FicheSub)
                tmpDutyFicheSubList = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_FicheSub
             '   Info8.AddError(BIZ.SA.EumErrorAction.Stop, " tmpDutyFicheSubList", tmpDutyFicheSubList.count)
				tmpDutyFicheSubListAtashNeshsni = tmpDutyFicheSubList.where (Function (f) f.CI_DutyFormula=5 And f.CI_DutyFormulaFiche=0).tolist
			'	Info8.AddError(BIZ.SA.EumErrorAction.Stop, " tmpDutyFicheSubListAtashNeshsni", tmpDutyFicheSubListAtashNeshsni.count)	
				AtashNeshsni=tmpDutyFicheSubListAtashNeshsni.sum(Function(f) f.price)
			'	Info8.AddError(BIZ.SA.EumErrorAction.Stop, " AtashNeshsnidddddd", AtashNeshsni)	
				tmpDutyFicheSubListAtashNeshsni = tmpDutyFicheSubListAtashNeshsni.where (Function (f) f.CI_DutyFormula=5 And f.CI_DutyFormulaFiche<>0).tolist
		'	Info8.AddError(BIZ.SA.EumErrorAction.Stop, " tmpDutyFicheSubListAtashNeshsni", tmpDutyFicheSubListAtashNeshsni.count)
		'		Info8.AddError(BIZ.SA.EumErrorAction.Stop, " tmpDutyFicheSubListAtashNeshsni", tmpDutyFicheSubListAtashNeshsni.sum(Function(f) f.price))		
				AtashNeshsni=AtashNeshsni-tmpDutyFicheSubListAtashNeshsni.sum(Function(f) f.price)

''''''''''''''''''''''Garbage
			
				Dim tmpDutyFicheSubListGarbage As New List(Of DtoSC.Duty_FicheSub)
				tmpDutyFicheSubListGarbage = tmpDutyFicheSubList.where (Function (f) f.CI_DutyFormula=3 And f.CI_DutyFormulaFiche=0).tolist	
				Garbage=tmpDutyFicheSubListGarbage.sum(Function(f) f.price)
				tmpDutyFicheSubListGarbage = tmpDutyFicheSubListGarbage.where (Function (f) f.CI_DutyFormula=3 And f.CI_DutyFormulaFiche<>0).tolist
				Garbage=Garbage-tmpDutyFicheSubListGarbage.sum(Function(f) f.price)
	'sp 466395	Garbage=Garbage-Afzodeh
			'	Info8.AddError(BIZ.SA.EumErrorAction.Stop, " AtashNeshsni-", AtashNeshsni)
				'	Info8.AddError(BIZ.SA.EumErrorAction.Stop, "-Garbage",Garbage)	
			'	-------------------------------	
                TmpDocDetails.Price = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PayablePrice) - AtashNeshsni-Garbage-Afzodeh
                If  Info8.GetAccountingDocCreateParameter.ObjOnPrice <> CByte(Biz.SA.ClsEnum.EumObjOnPrice.Nosazi) Then
                    if Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.CI_DutyFicheExportType =14 Then
                    	TmpDocDetails.WrapperAccountNo = 2005
                    Else
                    	TmpDocDetails.WrapperAccountNo = 100062 
                    End if		
                    DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.senfi)
                    TmpDocDetails.AccountNo ="7-14-55-1-1-0-1" ' Info8.GetFunctions.GetNosaziNickName(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_FicheSub(0).NidFK)
                Else
                    TmpDocDetails.WrapperAccountNo = 2003
                    DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.Nosazi)
                    TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_FicheSub(0).NidFK)
                End If
                

               
                DtoAccounting_DocHeader.NidFiche = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.NidFiche
                TmpDocDetails.AccountNoComments = iif(DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.senfi),"صنفی","نوسازی") 'DtoAccounting_DocHeader.EumObjOnPrice '"مبلغ کل"
                if Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.CI_DutyFicheExportType =14 Then TmpDocDetails.AccountNoComments = "عوارض سالیانه بانک ها و موسسات اعتباری"
                Dim FF As String = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.FicheNo
                
                TmpDocDetails.FicheNo = FF
                DtoAccounting_DocHeader.FicheNo = FF
                Dim BBB as String()
                Dim PPP as String()
                BBB=Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID.split("/")
                PPP=Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentID.split("/")
                if BBB.count=2 Then  BBB(0)=BBB(0)+BBB(1)
                if PPP.count=2 Then  PPP(0)=PPP(0)+PPP(1)
                TmpDocDetails.BillID = BBB(0)'Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID
                TmpDocDetails.PaymentID = PPP(0)'Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentID
                Try

                   
                   ' if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then TmpDocDetails.BankCode =18
                    TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     					
                Catch ex As Exception
                    TmpDocDetails.BankCode = 18 ' 395467 0 '20
                End Try
               


                Dim TmpDate As String = ""


                If Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.EumDutyFicheStatus = 1 Then
                    TmpDate = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentDate
                Else
                    TmpDate = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BankPaymentDate
                End If
                               

                TmpDocDetails.PaymentDate = ChangeDate(TmpDate) 
                TmpDocDetails.IncmRow = 1
         
                TmpAccounting_DocDetailsList.Add(TmpDocDetails)
                
                 
          if AtashNeshsni<>0 Then  
          	 Dim TmpDocDetailsAtashNeshsni As New Biz.Communication.DataAccess.Accounting_DocDetails  
          	' TmpDocDetailsAtashNeshsni =TmpDocDetailsNew 
          	
          	 TmpDocDetailsAtashNeshsni.PaymentDate = ChangeDate(TmpDate) 
          	 
          	 
          	  Try

                  
                    'TmpDocDetailsAtashNeshsni.BankCode =iif( CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode)="" , 18 ,CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode))
                    'if TmpDocDetailsAtashNeshsni.BankCode="" or TmpDocDetailsAtashNeshsni.BankCode is Nothing Then TmpDocDetailsAtashNeshsni.BankCode =18
                    TmpDocDetailsAtashNeshsni.BankCode = CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode)
                    if CStr(TmpDocDetailsAtashNeshsni.BankCode)=""  Then  TmpDocDetailsAtashNeshsni.BankCode= 18
     				
                
                Catch ex As Exception
                    TmpDocDetailsAtashNeshsni.BankCode = 18 ' 395467 0 '20
                End Try
               
          	 
          	 TmpDocDetailsAtashNeshsni.BillID = BBB(0)'Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID
          	  
             TmpDocDetailsAtashNeshsni.PaymentID = PPP(0)
             
          	 TmpDocDetailsAtashNeshsni.FicheNo = FF	 
          	 
          	 TmpDocDetailsAtashNeshsni.AccountNoComments = iif(DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.senfi),"صنفی","نوسازی") 'DtoAccounting_DocHeader.EumObjOnPrice '"مبلغ کل"
          	 if TmpDocDetailsAtashNeshsni.AccountNoComments="صنفی" Then 
          	 	TmpDocDetailsAtashNeshsni.AccountNo ="7-14-55-1-1-0-1" 
          	 Else	
          	 	TmpDocDetailsAtashNeshsni.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_FicheSub(0).NidFK)
          	 End if
          	 TmpDocDetailsAtashNeshsni.AccountNoComments="آتش نشانی"  
             TmpDocDetailsAtashNeshsni.Price=AtashNeshsni
             TmpDocDetailsAtashNeshsni.WrapperAccountNo = 100002  
             TmpDocDetailsAtashNeshsni.IncmRow = 2
              
             TmpAccounting_DocDetailsList.Add(TmpDocDetailsAtashNeshsni)
            
           End if       
           if Garbage<>0 Then 
           	  Dim TmpDocDetailsGarbage As New Biz.Communication.DataAccess.Accounting_DocDetails
          	  'TmpDocDetailsGarbage =TmpDocDetailsNew    
          	  
          	   TmpDocDetailsGarbage.PaymentDate = ChangeDate(TmpDate) 
          	 
          	 
          	  Try

                    
                   ' TmpDocDetailsGarbage.BankCode =iif( CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode)="" , 18 ,CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode))
                   ' if TmpDocDetailsGarbage.BankCode="" or TmpDocDetailsGarbage.BankCode is Nothing Then TmpDocDetailsGarbage.BankCode =18
                    TmpDocDetailsGarbage.BankCode = CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode)
                    if CStr(TmpDocDetailsGarbage.BankCode)=""  Then  TmpDocDetailsGarbage.BankCode= 18
     			   
               
                Catch ex As Exception
                    TmpDocDetailsGarbage.BankCode = 18 ' 395467 0 '20
                End Try
               
          	 
          	 TmpDocDetailsGarbage.BillID = BBB(0)'Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID
          	  
             TmpDocDetailsGarbage.PaymentID = PPP(0)
             
          	 TmpDocDetailsGarbage.FicheNo = FF	 
          	 
          	 TmpDocDetailsGarbage.AccountNoComments = iif(DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.senfi),"صنفی","نوسازی") 'DtoAccounting_DocHeader.EumObjOnPrice '"مبلغ کل"
          	 if TmpDocDetailsGarbage.AccountNoComments="صنفی" Then 
          	 	TmpDocDetailsGarbage.AccountNo ="7-14-55-1-1-0-1" 
          	 Else	
          	 	TmpDocDetailsGarbage.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_FicheSub(0).NidFK)
          	 End if
          	  TmpDocDetailsGarbage.AccountNoComments="پسماند"    
              TmpDocDetailsGarbage.Price=Garbage
              TmpDocDetailsGarbage.WrapperAccountNo = 100003   
              TmpDocDetailsGarbage.IncmRow = 3
              TmpAccounting_DocDetailsList.Add(TmpDocDetailsGarbage)
          End if           
          
               
         if Afzodeh<>0 Then 
           	  Dim TmpDocDetailsAfzodeh As New Biz.Communication.DataAccess.Accounting_DocDetails  
          	  TmpDocDetailsAfzodeh.PaymentDate = ChangeDate(TmpDate) 
          	 
          	 
          	  Try
                    TmpDocDetailsAfzodeh.BankCode = CStr(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ConfirmBankCode)
                    if CStr(TmpDocDetailsAfzodeh.BankCode)=""  Then  TmpDocDetailsAfzodeh.BankCode= 18
     			   
               
                Catch ex As Exception
                    TmpDocDetailsAfzodeh.BankCode = 18 ' 395467 0 '20
                End Try
               
          	 
          	 TmpDocDetailsAfzodeh.BillID = BBB(0)'Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID
          	  
             TmpDocDetailsAfzodeh.PaymentID = PPP(0)
             
          	 TmpDocDetailsAfzodeh.FicheNo = FF	 
          	 
          	 TmpDocDetailsAfzodeh.AccountNoComments = iif(DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.senfi),"صنفی","نوسازی") 'DtoAccounting_DocHeader.EumObjOnPrice '"مبلغ کل"
          	 if TmpDocDetailsAfzodeh.AccountNoComments="صنفی" Then 
          	 	TmpDocDetailsAfzodeh.AccountNo ="7-14-55-1-1-0-1" 
          	 Else	
          	 	TmpDocDetailsAfzodeh.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_FicheSub(0).NidFK)
          	 End if
          	  TmpDocDetailsAfzodeh.AccountNoComments="مالیات برارزش افزوده"    
              TmpDocDetailsAfzodeh.Price=Afzodeh
              TmpDocDetailsAfzodeh.WrapperAccountNo = 206098003   
              TmpDocDetailsAfzodeh.IncmRow = 4
              TmpAccounting_DocDetailsList.Add(TmpDocDetailsAfzodeh)
          End if                 
               
                Dim RefNo As New BIZ.Communication.RefParameetrs
                RefNo.Name = "RefReconstructionNo"
                RefNo.Value = ""  '93883 TmpDate
                ListRefP.add(RefNo)
                
                 Dim RefRDD As New BIZ.Communication.RefParameetrs
                 RefRDD.Name = "RefownrDsc"
                 RefRDD.Value = FF
                ListRefP.add(RefRDD)
                		
                Dim Refcenter As New BIZ.Communication.RefParameetrs
                Refcenter.Name = "Center1"
                Refcenter.Value = 0   '99436 TmpDate
                ListRefP.add(Refcenter)
                		
                Dim RefP As New BIZ.Communication.RefParameetrs
                RefP.Name = "DocDate"
                RefP.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
                ListRefP.add(RefP)
                Dim RefPR As New BIZ.Communication.RefParameetrs
                RefPR.Name = "RowDate"
                RefPR.Value = ChangeDate(TmpDate)
                ListRefP.add(RefPR)
                Dim RefPRD As New BIZ.Communication.RefParameetrs
                RefPRD.Name = "RowDocNo"
                RefPRD.Value = FF
                ListRefP.add(RefPRD)

                Dim RefFund As New BIZ.Communication.RefParameetrs
                RefFund.Name = "Fund"
                If TmpDocDetails.BankCode = 1 Then '153818
                	if DistrickBranch = 201 Then
                		RefFund.Value = 200201009 
                	ElseIf DistrickBranch = 202 Then
                		RefFund.Value = 200202007 
                	ElseIf DistrickBranch = 203 Then
                		RefFund.Value = 200203009 
                	ElseIf DistrickBranch = 204 Then
                		RefFund.Value = 200204005
                	ElseIf DistrickBranch = 205 Then
                		RefFund.Value = 200205004   
                	ElseIf DistrickBranch = 206 Then
                		RefFund.Value = 256222008
                	ElseIf DistrickBranch = 207 Then
                		RefFund.Value = 200207006
                 	ElseIf DistrickBranch = 208 Then
                 		RefFund.Value = 200208007
                 	ElseIf DistrickBranch = 209 Then
                 		RefFund.Value = 200209004
                 	ElseIf DistrickBranch = 210 Then
                 		RefFund.Value = 200210005
                 	ElseIf DistrickBranch = 211 Then
                 		RefFund.Value = 200211004 
                 	ElseIf DistrickBranch = 212 Then
                 		RefFund.Value = 200212004 
                 '	ElseIf DistrickBranch = 218 Then
                 	'	RefFund.Value =200218028	 		 	 	 	 	 	 	   		   		 	
                	Else
                    	RefFund.Value = 1200
                    End if 	
                Else
                	if DistrickBranch = 201 Then
                		RefFund.Value = 200201012 
                	ElseIf DistrickBranch = 202 Then
                		RefFund.Value = 200202012 
                	ElseIf DistrickBranch = 203 Then
                		RefFund.Value = 200203013 
                	ElseIf DistrickBranch = 204 Then
                		RefFund.Value = 200204017 
                	ElseIf DistrickBranch = 205 Then
                		RefFund.Value = 200205008 
                	ElseIf DistrickBranch = 206 Then
                		RefFund.Value = 200206006 	
                	ElseIf DistrickBranch = 207 Then
                		RefFund.Value = 200207009
                 	ElseIf DistrickBranch = 208 Then
                	 	RefFund.Value = 200208010	
                	ElseIf DistrickBranch = 209 Then
                		RefFund.Value = 200209008
                	ElseIf DistrickBranch = 210 Then
                		RefFund.Value = 200210020
                	ElseIf DistrickBranch = 211 Then
                 		RefFund.Value = 200211007
                 	ElseIf DistrickBranch = 212 Then
                 		RefFund.Value = 212210016 
                 	ElseIf DistrickBranch = 218 Then
                 		RefFund.Value = 200218011 			 		 	 	 			 	 	 		 		 				 		
                	Else
                    	RefFund.Value = 1300
                    End if 	
                    
                End If
               
                ListRefP.add(RefFund)
				
				Dim RefP0 As New BIZ.Communication.RefParameetrs
                RefP0.Name = "Ref"
                RefP0.Value = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.ficheno
                ListRefP.add(RefP0)
				
				
				Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
                Refvchrtyp.Name = "vchrtyp"
                Refvchrtyp.Value = 0
                ListRefP.add(Refvchrtyp)
				
				Dim RefDUE  As New BIZ.Communication.RefParameetrs
                RefDUE.Name = "DUE"
                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
                ListRefP.add(RefDUE)
                
                Dim RefQTY   As New BIZ.Communication.RefParameetrs
                RefQTY.Name = "QTY"
                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PayablePrice)
                ListRefP.add(RefQTY)
                
                Dim RefP2 As New BIZ.Communication.RefParameetrs
                RefP2.Name = "Ref2"
                RefP2.Value = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID
                ListRefP.add(RefP2)
                Dim RefP3 As New BIZ.Communication.RefParameetrs
                RefP3.Name = "Ref3"
                RefP3.Value = Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentID
                ListRefP.add(RefP3)


                DtoAccounting_DocHeader.DocRow = 1
                TmpAcc.Accounting_DocHeader = DtoAccounting_DocHeader

                TmpAcc.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                TmpAcc.Accounting_DocDetailList = TmpAccounting_DocDetailsList
                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
                
                Mess.ActTyp = 3
                Mess.DocTyp = iif(DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.senfi),2,1) 'DtoAccounting_DocHeader.EumObjOnPrice
                Mess.IncmMkrTyp = 1
                Mess.RefParameterList = ListRefP
                Mess.District = DistrickBranch
                Mess.DocTypDsc = "عوارض سرا"
     			Mess.vchrtyp=0
                Mess.docdsc=iif(DtoAccounting_DocHeader.EumObjOnPrice = CByte(Biz.SA.ClsEnum.EumObjOnPrice.senfi),"اسناد صنفی","اسناد نوسازی") 'DtoAccounting_DocHeader.EumObjOnPrice   
             
                TmpAcc.RayvarzMessage =Mess
                ListAcc.Add(TmpAcc)
 				
 				Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto

		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.FicheNo
		        FicheInfo.NosaziCodeStr=TmpDocDetails.AccountNo
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo
 				
 				
                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)

                TmpDocument.Accounting_Doc = ListAcc


                tmpstr = TmpDocument.Save(Info8.GetAccountingDocCreateParameter.DutyFicheResultList(0).Duty_Fiche.NidFiche.tostring )
                 
     '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, "tmpstr",tmpstr)
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
       

            End If

        End If ' عدم تکرای
   ' Catch ex As Exception
   '    Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه", ex.tostring())
   ' End Try


End Function

<DisplayName("درآمد")> Public Function iNcOME()
 
'    Try
      
        if   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo ="030132823378"   Then   Call FnSMS("sara10" ) :Exit Function
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                If PtmpDistrict = "051" Then
                    DistrickBranch = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentId.Substring(10, 2)
                    If DistrickBranch > 12 And DistrickBranch <> 80 And DistrickBranch <> 218  Then DistrickBranch = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentId.Substring(10, 1)
                End If

                


                Select Case PtmpDistrict
                    Case "511"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "512"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "513"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case "514"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case "515"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "516"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "517"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "518"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "519"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "520"
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case "521"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "522"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "523"
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select
               if  DistrickBranch=0 Then 
               		Select Case PtmpDistrict
                    Case "401"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "402"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "403"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                    Case "404"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case "405"
                      	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
	                    	DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "406"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "407"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "408"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "409"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "410"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
	                     	DistrickBranch =210
	                     Else
	        				DistrickBranch = 10
		                 End if	
                    Case "411"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "412"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "400"
                    
                     if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                	End Select
               
               End if 
                 Dim ExistRayvarz As Boolean =True
      ''   or (Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup>129 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup<143) _
	''	   or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=123 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=124
         if DistrickBranch<> 80 And DistrickBranch<> 218 Then 
       	   If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =1 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=8 or _
           Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =15 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=22 or _
		   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =29 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=36 or _
		   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =43 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=50 or _
		   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =57 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=64 or _
		   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =71 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=78 or _
		   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =126 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=125 or _
		   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =150 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=152 or _
		   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=161 or _
		   (Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup >89 And  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup<>102 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup <117 ) _ 
		   Then  ExistRayvarz = False
		Else
			if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=1 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=7 or _
			Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=10 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=11 or _
			Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =126 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=125 or _
		    Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =150 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =152 or _ 
		    Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=161 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =162  Then ExistRayvarz = False
		End if
		
''		if ExistRayvarz = False Then  	ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
        
'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
	'aaaa	if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus=3 Then  ExistRayvarz=True

                 
              If ExistRayvarz = False Then
               Call GetSara8Workflow()
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
               ' Dim BedeHiTmp As Decimal = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
              ' if  ucase(Info8.User.UserGuid.tostring)=ucase("ca742134-44bb-4ba6-b0c4-e5e186600a0a") or ucase(Info8.User.UserGuid.tostring)=ucase("6F99C240-C92B-4FB3-99DB-6760750167EB")  Then 
                   Dim BedeHiTmp As Decimal=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
             '   End if 
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
				Dim  BedahiFAdd as Double=0
				BedahiFAdd=BedeHi(DistrickBranch, Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo)
              '  if 1>2 Then
             

                If BedahiFAdd > 0 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup<> 125 _
                 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup<> 126 Then
 				
                    Dim TotalP As Decimal

                    For Tj = 0 To LstIncmDet.count - 1

                        If LstIncmDet(Tj).CI_IncomeCalculation = 100036  Or LstIncmDet(Tj).CI_IncomeCalculation = 100041 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100042 Or LstIncmDet(Tj).CI_IncomeCalculation = 100043 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100047 Or LstIncmDet(Tj).CI_IncomeCalculation = 100048 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100049 Or LstIncmDet(Tj).CI_IncomeCalculation = 100050 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100052 Or LstIncmDet(Tj).CI_IncomeCalculation = 100028 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100016 Or LstIncmDet(Tj).CI_IncomeCalculation = 100009 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100002 Or LstIncmDet(Tj).CI_IncomeCalculation = 1091 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 1101   Or LstIncmDet(Tj).CI_IncomeCalculation = 100061 _ 
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100055 Or LstIncmDet(Tj).CI_IncomeCalculation = 100057 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100060 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100200 Or LstIncmDet(Tj).CI_IncomeCalculation = 100075 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100067 Or LstIncmDet(Tj).CI_IncomeCalculation = 100068 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100087 Or LstIncmDet(Tj).CI_IncomeCalculation = 999999 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 120 Or LstIncmDet(Tj).CI_IncomeCalculation = 100006 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100072 Or LstIncmDet(Tj).CI_IncomeCalculation = 100032 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100080 Or LstIncmDet(Tj).CI_IncomeCalculation = 100101 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100045 Or LstIncmDet(Tj).CI_IncomeCalculation = 100102 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100103 Or LstIncmDet(Tj).CI_IncomeCalculation = 100104 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100105 Or LstIncmDet(Tj).CI_IncomeCalculation = 100097 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100098 Or LstIncmDet(Tj).CI_IncomeCalculation = 100099 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100109 Or LstIncmDet(Tj).CI_IncomeCalculation = 100081 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100114 Or LstIncmDet(Tj).CI_IncomeCalculation = 100082 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100053 Or LstIncmDet(Tj).CI_IncomeCalculation = 100029 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 1301 Or LstIncmDet(Tj).CI_IncomeCalculation = 100202 Then 

                        Else
                        	if IsDBNull(LstIncmDet(Tj).SysValue) or LstIncmDet(Tj).SysValue=0 Then 
                        		TotalP +=  LstIncmDet(Tj).Value
                        	Else
                        		TotalP += (IIf(IsDBNull(LstIncmDet(Tj).SysValue), LstIncmDet(Tj).Value, LstIncmDet(Tj).SysValue))
                        	End if	
                            
                        End If
                    Next
				'	YY=1
			
				Dim bbb as Double 
				bbb =  BedahiFAdd
		
                    For Tj = 0 To LstIncmDet.count - 1
                        Dim TmpDocDetailsBeD As New BIZ.Communication.DataAccess.Accounting_DocDetails

                        TmpDocDetailsBeD.Price = 0
                        If LstIncmDet(Tj).CI_IncomeCalculation = 100036 Or LstIncmDet(Tj).CI_IncomeCalculation = 100041 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100042 Or LstIncmDet(Tj).CI_IncomeCalculation = 100043 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100047 Or LstIncmDet(Tj).CI_IncomeCalculation = 100048 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100049 Or LstIncmDet(Tj).CI_IncomeCalculation = 100050 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100052 Or LstIncmDet(Tj).CI_IncomeCalculation = 100028 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100016 Or LstIncmDet(Tj).CI_IncomeCalculation = 100009 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100002 Or LstIncmDet(Tj).CI_IncomeCalculation = 1091 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 1101   Or LstIncmDet(Tj).CI_IncomeCalculation = 100061 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100055 Or LstIncmDet(Tj).CI_IncomeCalculation = 100057 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100060 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100200 Or LstIncmDet(Tj).CI_IncomeCalculation = 100075 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100067 Or LstIncmDet(Tj).CI_IncomeCalculation = 100068 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100087 or LstIncmDet(Tj).CI_IncomeCalculation = 999999 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 120 or LstIncmDet(Tj).CI_IncomeCalculation = 100006 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100072 or LstIncmDet(Tj).CI_IncomeCalculation = 100032 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100080 or LstIncmDet(Tj).CI_IncomeCalculation =100101 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100045 Or LstIncmDet(Tj).CI_IncomeCalculation = 100102 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100103 Or LstIncmDet(Tj).CI_IncomeCalculation = 100104 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100105 Or LstIncmDet(Tj).CI_IncomeCalculation = 100097 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100098 Or LstIncmDet(Tj).CI_IncomeCalculation = 100099 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100109 Or LstIncmDet(Tj).CI_IncomeCalculation = 100081 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation =100114 Or LstIncmDet(Tj).CI_IncomeCalculation = 100082 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation =100053 Or LstIncmDet(Tj).CI_IncomeCalculation =  100029 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 1301 Or LstIncmDet(Tj).CI_IncomeCalculation = 100202 Then  
                            TmpDocDetailsBeD.Price = 0
                        Else
                            TmpDocDetailsBeD.Price = (IIf(IsDBNull(LstIncmDet(Tj).SysValue), LstIncmDet(Tj).Value, LstIncmDet(Tj).SysValue))
                         
                        End If
						if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then TmpDocDetailsBeD.FileNo=1
                        TmpDocDetailsBeD.Price = ((TmpDocDetailsBeD.Price * BedahiFAdd) / TotalP) * (-1)
                      
                        TmpDocDetailsBeD.Price = Math.Round(convert.toDecimal(TmpDocDetailsBeD.Price), 0)
                        Dim TmpIncomeCalculationDesc =  Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstIncmDet(Tj).CI_IncomeCalculation)

                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpDocDetailsBeD.AccountNoComments = ""
                        Else
                            TmpDocDetailsBeD.AccountNoComments =  IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If

                        TmpDocDetailsBeD.WrapperAccountNo = LstIncmDet(Tj).CI_IncomeCalculation
                        TmpDocDetailsBeD.FicheNo = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo

                        TmpDocDetailsBeD.BillID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
                        TmpDocDetailsBeD.PaymentID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
                        
                        'TmpDocDetailsBeD.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
                        'if TmpDocDetailsBeD.BankCode="" or TmpDocDetailsBeD.BankCode is Nothing Then  TmpDocDetailsBeD.BankCode= 18
                         TmpDocDetailsBeD.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                         if CStr(TmpDocDetailsBeD.BankCode)=""  Then  TmpDocDetailsBeD.BankCode= 18
     					TmpChekNo= CStr(TmpDocDetailsBeD.BankCode)
                       'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                         Dim tmpdatenew As String = ""
						If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
	                    	tmpdatenew = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
	                	Else
	                    	tmpdatenew = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
	                	End If
	 
                  
                        TmpDocDetailsBeD.PaymentDate =ChangeDate(tmpdatenew)


                        
                        TmpDocDetailsBeD.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                        TmpDocDetailsBeD.IncmRow = YY
                        
                        If TmpDocDetailsBeD.Price <> 0 Then
                        
                            bbb=bbb-TmpDocDetailsBeD.Price
                            TmpDocDetailsBeD.Price=Math.Min(convert.toDecimal(bbb),convert.toDecimal(TmpDocDetailsBeD.Price))
                           
                            TmpAccounting_DocDetailsListTotal.Add(TmpDocDetailsBeD)
                           
                            yy += 1
                        End If

                    Next

                End If

				

                
                ''''''''''''''''''new 

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                				               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If TmpInComeCode.ToString = DBNull.Value.ToString or TmpInComeCode.ToString=0 Or TmpDT(Ti).CI_IncomeCalculation = 100036 Or TmpDT(Ti).CI_IncomeCalculation = 100041 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100042 Or TmpDT(Ti).CI_IncomeCalculation = 100043 Or TmpDT(Ti).CI_IncomeCalculation = 100047 Or TmpDT(Ti).CI_IncomeCalculation = 100048 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100049 Or TmpDT(Ti).CI_IncomeCalculation = 100050 Or TmpDT(Ti).CI_IncomeCalculation = 100052 Or TmpDT(Ti).CI_IncomeCalculation = 100028 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100016 Or TmpDT(Ti).CI_IncomeCalculation = 100009 Or TmpDT(Ti).CI_IncomeCalculation = 100002 Or TmpDT(Ti).CI_IncomeCalculation = 1091 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 1101   Or TmpDT(Ti).CI_IncomeCalculation = 100055 Or TmpDT(Ti).CI_IncomeCalculation = 100057 Or TmpDT(Ti).CI_IncomeCalculation = 100061 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100060 Or TmpDT(Ti).CI_IncomeCalculation =100200 Or TmpDT(Ti).CI_IncomeCalculation =100075 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100067 Or TmpDT(Ti).CI_IncomeCalculation = 100068 Or TmpDT(Ti).CI_IncomeCalculation = 100087 Or TmpDT(Ti).CI_IncomeCalculation =  999999 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 120 or TmpDT(Ti).CI_IncomeCalculation = 100006 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100072 or TmpDT(Ti).CI_IncomeCalculation = 100032 _
                        or TmpDT(Ti).CI_IncomeCalculation = 100080 or TmpDT(Ti).CI_IncomeCalculation =100101 or TmpDT(Ti).CI_IncomeCalculation = 100045 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100102 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100103 Or TmpDT(Ti).CI_IncomeCalculation = 100104 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100105 Or TmpDT(Ti).CI_IncomeCalculation = 100097 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100098 Or TmpDT(Ti).CI_IncomeCalculation = 100099 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100109 Or TmpDT(Ti).CI_IncomeCalculation = 100081 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100114 Or TmpDT(Ti).CI_IncomeCalculation = 100082 or TmpDT(Ti).CI_IncomeCalculation =100053 or TmpDT(Ti).CI_IncomeCalculation =100029 _
                        Or TmpDT(Ti).CI_IncomeCalculation =1301 Or TmpDT(Ti).CI_IncomeCalculation =100202 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                            Dim LstOdd As New List(Of Global.DtoSC.Income_OddmentAccount)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 2 or f.CI_OddmentType = 3 or f.CI_OddmentType = 6 or f.CI_OddmentType=7) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price - LstOdd.Sum(Function(f) f.Value)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 8 or f.CI_OddmentType =1 or f.CI_OddmentType = 4) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price + LstOdd.Sum(Function(f) f.Value)
			                TmpOne.WrapperAccountNo = IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

               
						if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then TmpOne.FileNo=1 
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                     
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
            
				Dim LstOdd_1 As New List(Of DtoSC.Income_OddmentAccount)
                LstOdd_1 = Info8.GetIncome.GetIncome_OddmentAccount
                Dim ChechOdd as Integer=0
                Dim Ti_1 as Integer
				For Ti=0 to LstOdd_1.count -1
					ChechOdd=0
					For Ti_1=0 to TmpAccounting_DocDetailsList.count -1 
						if LstOdd_1(Ti).CI_IncomeCalculation=TmpAccounting_DocDetailsList(Ti_1).WrapperAccountNo Then	ChechOdd=1
						If LstOdd_1(Ti).CI_IncomeCalculation =0 or LstOdd_1(Ti).CI_IncomeCalculation = 100036 Or LstOdd_1(Ti).CI_IncomeCalculation = 100041 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100042 Or LstOdd_1(Ti).CI_IncomeCalculation = 100043 Or LstOdd_1(Ti).CI_IncomeCalculation = 100047 Or LstOdd_1(Ti).CI_IncomeCalculation = 100048 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100049 Or LstOdd_1(Ti).CI_IncomeCalculation = 100050 Or LstOdd_1(Ti).CI_IncomeCalculation = 100052 Or LstOdd_1(Ti).CI_IncomeCalculation = 100028 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100016 Or LstOdd_1(Ti).CI_IncomeCalculation = 100009 Or LstOdd_1(Ti).CI_IncomeCalculation = 100002 Or LstOdd_1(Ti).CI_IncomeCalculation = 1091 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 1101   Or LstOdd_1(Ti).CI_IncomeCalculation = 100055 Or LstOdd_1(Ti).CI_IncomeCalculation = 100057 Or LstOdd_1(Ti).CI_IncomeCalculation = 100061 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100060 Or LstOdd_1(Ti).CI_IncomeCalculation = 100200 Or LstOdd_1(Ti).CI_IncomeCalculation = 100075 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100067 Or LstOdd_1(Ti).CI_IncomeCalculation = 100068 or LstOdd_1(Ti).CI_IncomeCalculation = 100029 Or LstOdd_1(Ti).CI_IncomeCalculation = 100087 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 999999 Or LstOdd_1(Ti).CI_IncomeCalculation = 120 or LstOdd_1(Ti).CI_IncomeCalculation = 100006 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100072 or LstOdd_1(Ti).CI_IncomeCalculation = 100032  or LstOdd_1(Ti).CI_IncomeCalculation =100080 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100101 Or LstOdd_1(Ti).CI_IncomeCalculation = 100045  Or LstOdd_1(Ti).CI_IncomeCalculation = 100102 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100103 Or LstOdd_1(Ti).CI_IncomeCalculation = 100104 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100105 Or LstOdd_1(Ti).CI_IncomeCalculation = 100097 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100098 Or LstOdd_1(Ti).CI_IncomeCalculation = 100099 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100109 Or LstOdd_1(Ti).CI_IncomeCalculation = 100081 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100114 Or LstOdd_1(Ti).CI_IncomeCalculation = 100082 Or LstOdd_1(Ti).CI_IncomeCalculation =100053 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 1301 Or LstOdd_1(Ti).CI_IncomeCalculation = 100201 Or LstOdd_1(Ti).CI_IncomeCalculation = 100202   Then   ChechOdd=1
                        if ChechOdd=0 Then if Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="0" or Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="1" Then  ChechOdd=1 
					Next
					 
					if ChechOdd=0 Then 
						 Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
						 if LstOdd_1(Ti).CI_OddmentType = 2 or LstOdd_1(Ti).CI_OddmentType = 3 or LstOdd_1(Ti).CI_OddmentType = 6 or LstOdd_1(Ti).CI_OddmentType=7  Then
	                     	TmpOne.Price = LstOdd_1(Ti).Value * (-1)
	                     Else
	                     	TmpOne.Price = LstOdd_1(Ti).Value
	                     End if 
	                     if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then TmpOne.FileNo=1 	
						 TmpOne.WrapperAccountNo= LstOdd_1(Ti).CI_IncomeCalculation
						 Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstOdd_1(Ti).CI_IncomeCalculation)
						 If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
	                        TmpOne.AccountNoComments = ""
	                     Else
	                        TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
	                     End If
	                     a +=TmpOne.Price
	                     TmpAccounting_DocDetailsList.Add(TmpOne)
	                      
	                End if     
                     
				Next
                '--------------------------------------------'---------------------
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
    
              
                Dim TmpChek As Integer = 0
                

				TmpChek=0

                Dim TakhfifRound As Decimal = 0
                Dim TakhfifRound_1 As Decimal = 0
                Dim TakhfifRound_Cash As Decimal = 0
                Dim i As Integer = 0
                Dim jjjj As Integer = 0
               
                Dim test As Integer = 1
                Dim tmpdate As String = ""


                TakhfifRound_1 = TakhfifRound - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue

                '---------------------------------------------------------------------------
                '-------------------------------------------------------------------------------        
                TakhfifRound = 0

                
                Dim TTj As Integer = 0
                
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                BedeHiTmp=BedeHiTmp+BedahiFAdd
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = 0
                    
                    If a <> 0 Then
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal((Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price) * Convert.ToDecimal(BedeHiTmp)) / Convert.ToDecimal(a)),0) ' (Math.Round( (TmpAccounting_DocDetailsList(TTj).Price*BedeHiTmp)/a,2))
                    Else
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price),0)
                    End If
					if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then TmpDocDetails.FileNo=1 	
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
                  '  if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
                    TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
                       'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                       
                    
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    TakhfifRound += TmpDocDetails.Price
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                    
                Next
                   
 ' if  ucase(Info8.User.UserGuid.tostring)<>ucase("ca742134-44bb-4ba6-b0c4-e5e186600a0a") And ucase(Info8.User.UserGuid.tostring)<>ucase("6F99C240-C92B-4FB3-99DB-6760750167EB")  Then 	                       
if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers>0  And  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue=0 And 1=2 Then

	
	Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
	   
    TmpDocDetails.Price = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers.tostring
    
    TmpDocDetails.WrapperAccountNo = 110171
    TmpDocDetails.AccountNoComments = "کارگزاری"
    
    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
   
    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                   
   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    'if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
    TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
    TmpChekNo= CStr(TmpDocDetails.BankCode)
    'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

   
	If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
    Else
      	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
    End If
 
                   
    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
    TakhfifRound += TmpDocDetails.Price
    TmpDocDetails.IncmRow = YY
    TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

    If TmpDocDetails.Price <> 0 Then
    
    	TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
        yy += 1
   End If

End if
 'End if               
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
                If DtoAccounting_DocHeaderTotal.SaraPrice <> TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price) Then
                    Dim gg As Integer = 0
                    Dim PriceTmp As Decimal = 0
                    
                    if TmpAccounting_DocDetailsListTotal.count>0 Then 
	                    For gg = 1 To TmpAccounting_DocDetailsListTotal.count - 1
	                        PriceTmp += TmpAccounting_DocDetailsListTotal(gg).Price
	                    Next
	                 
                    TmpAccounting_DocDetailsListTotal(0).Price = DtoAccounting_DocHeaderTotal.SaraPrice - PriceTmp
					End if   
                End If
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then
                			Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit   	
                		Else
                			Refcenter.Value = 0   '99436 TmpDate
                		End if	
                		ListRefP.add(Refcenter)
                        
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                If TmpChekNo = 1 Then
		                    '153818
		                    
		                	if DistrickBranch = 201 Then
		                		RefFund.Value = 200201009 
		                	ElseIf DistrickBranch = 202 Then
		                		RefFund.Value = 200202007 
		                	ElseIf DistrickBranch = 203 Then
		                		RefFund.Value = 200203009
		                	ElseIf DistrickBranch = 204 Then
		                		RefFund.Value = 200204005  	  	
		                	ElseIf DistrickBranch = 205 Then
		                		RefFund.Value = 200205004   	   		 	
		                	ElseIf DistrickBranch = 206 Then
		                		RefFund.Value = 256222008
		                	ElseIf DistrickBranch = 207 Then
		                		RefFund.Value = 200207006 
		                 	ElseIf DistrickBranch = 208 Then
		                 		RefFund.Value = 200208007   
		                 	ElseIf DistrickBranch = 209 Then
                 				RefFund.Value = 200209004 
                 			ElseIf DistrickBranch = 210 Then
                 				RefFund.Value = 200210005 
                 			ElseIf DistrickBranch = 211 Then
                 				RefFund.Value = 200211004 
                 			ElseIf DistrickBranch = 212 Then
                 				RefFund.Value = 200212004 
                 			ElseIf DistrickBranch = 218 Then
                				if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then 
                					RefFund.Value = 200218028 
                				Else	
                					RefFund.Value = 1200
                				End if 				 		 			 		 		  	   		   		 	
		                	Else
		                    	RefFund.Value = 1200
		                    End if 	
		                Else
		                	if DistrickBranch = 201 Then
		                		RefFund.Value = 200201012 
		                	ElseIf DistrickBranch = 202 Then
		                		RefFund.Value = 200202012 
		                	ElseIf DistrickBranch = 203 Then
		                		RefFund.Value = 200203013 
		                	ElseIf DistrickBranch = 204 Then
		                		RefFund.Value = 200204017 
		                	ElseIf DistrickBranch = 205 Then
		                		RefFund.Value = 200205008 
		                	ElseIf DistrickBranch = 206 Then
		                		RefFund.Value = 200206006 
		                	ElseIf DistrickBranch = 207 Then
		                		RefFund.Value = 200207009 
		                 	ElseIf DistrickBranch = 208 Then
		                 		RefFund.Value = 200208010 	
		                 	ElseIf DistrickBranch = 209 Then
                				RefFund.Value = 200209008
                			ElseIf DistrickBranch = 210 Then
                				RefFund.Value = 200210020	
                			ElseIf DistrickBranch = 211 Then
                				RefFund.Value = 200211007
                			ElseIf DistrickBranch = 212 Then
                				RefFund.Value = 212210016
                			ElseIf DistrickBranch = 218 Then
                				RefFund.Value = 200218011										 		 				 		
		                	Else
		                    	RefFund.Value = 1300
		                    End if 	
		                End If
		                
		                ListRefP.add(RefFund)
		
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
						
						
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                 Refvchrtyp.Value = 0
		               ' if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then  Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
						
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
						
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		               '308718  
		               if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150
					   		Dim Refcen As New BIZ.Communication.RefParameetrs
			                Refcen.Name = "Center"
			               
			                
			                
					   		if DistrickBranch = 201 Then
		                		Refcen.Value = 200201021 
		                	ElseIf DistrickBranch = 202 Then
		                		Refcen.Value = 200202017 
		                	ElseIf DistrickBranch = 203 Then
		                		Refcen.Value = 200203021 
		                	ElseIf DistrickBranch = 204 Then
		                		Refcen.Value = 200204018 
		                	ElseIf DistrickBranch = 205 Then
		                		Refcen.Value = 200205016 
		                	ElseIf DistrickBranch = 206 Then
		                		Refcen.Value = 200206016 
		                	ElseIf DistrickBranch = 207 Then
		                		Refcen.Value = 200207017 
		                 	ElseIf DistrickBranch = 208 Then
		                 		Refcen.Value = 200208017 	
		                 	ElseIf DistrickBranch = 209 Then
                				Refcen.Value = 200209016
                			ElseIf DistrickBranch = 210 Then
                				Refcen.Value = 200210022	
                			ElseIf DistrickBranch = 211 Then
                				Refcen.Value = 200211015
                			ElseIf DistrickBranch = 212 Then
                				Refcen.Value = 200212016
                			ElseIf DistrickBranch = 218 Then
                				Refcen.Value = 200218028										 		 				 		
		                	Else
		                    	Refcen.Value = 1300
		                    End if 	
					   		ListRefP.add(Refcen)
					   End if 	
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		                Mess.ActTyp = 3
		                Mess.DocTyp = 3
		                Mess.vchrtyp=0
		        '308718
		               if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then Mess.DocTyp = 11
		               
		               
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "عوارض سرا"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
             '   Info8.AddError(BIZ.SA.EumErrorAction.Stop, "a", "a")
             
             
             
             	Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto

		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)				   
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo
             

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc
         

                Dim tmpstr As String = ""
					
                            '  if   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo ="030132823378"   Then   Call FnSMS("NidF" & NidF )
                           '   Try
                tmpstr = TmpDocument.Save(NidF)
                '  Catch ex As Exception
                 ' if   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo ="030132823378"   Then   Call FnSMS("tmpstr" & ex.Message )
        'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
   ' End Try
                
               '  if   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo ="030132823378"   Then   Call FnSMS("tmpstr" & tmpstr )

                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری                               
  '  Catch ex As Exception
    '    Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
  '  End Try
End Function

<DisplayName("درآمد اوراق بهادار خزانه ")> Public Function iNcOMEOragh()
 
    Try
    
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

              
              if  DistrickBranch=0 Then 
		             
		             PtmpDistrict=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno.Substring(2,2)

               		Select Case PtmpDistrict
                    Case "01"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "02"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "03"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if	
                    Case "04"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if	
                    Case "05"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
	                    	DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "06"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "07"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "08"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "09"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "10"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
	                     	DistrickBranch =210
	                     Else
	        				DistrickBranch = 10
		                 End if	
                    Case "11"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "12"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "80"
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                	End Select
               
               End if   
               
                 Dim ExistRayvarz As Boolean =True
     
			if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=154  Then ExistRayvarz = False
	
		
''		if ExistRayvarz = False Then  	ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
                 
              If ExistRayvarz = False Then
               Call GetSara8Workflow()
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
              '  Dim BedeHiTmp As Decimal = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
               '  if  ucase(Info8.User.UserGuid.tostring)=ucase("ca742134-44bb-4ba6-b0c4-e5e186600a0a") or ucase(Info8.User.UserGuid.tostring)=ucase("6F99C240-C92B-4FB3-99DB-6760750167EB")  Then 
                    Dim BedeHiTmp As Decimal= Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 
             '   End if

                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
		Dim  BedahiFAdd as Double=0
		BedahiFAdd=BedeHi(DistrickBranch, Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo)
              '  if 1>2 Then
              
                If BedahiFAdd > 0 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=154 Then
 				
                    Dim TotalP As Decimal

                    For Tj = 0 To LstIncmDet.count - 1

                         If LstIncmDet(Tj).CI_IncomeCalculation = 100036  Or LstIncmDet(Tj).CI_IncomeCalculation = 100041 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100042 Or LstIncmDet(Tj).CI_IncomeCalculation = 100043 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100047 Or LstIncmDet(Tj).CI_IncomeCalculation = 100048 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100049 Or LstIncmDet(Tj).CI_IncomeCalculation = 100050 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100052 Or LstIncmDet(Tj).CI_IncomeCalculation = 100028 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100016 Or LstIncmDet(Tj).CI_IncomeCalculation = 100009 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100002 Or LstIncmDet(Tj).CI_IncomeCalculation = 1091 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 1101   Or LstIncmDet(Tj).CI_IncomeCalculation = 100061 _ 
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100055 Or LstIncmDet(Tj).CI_IncomeCalculation = 100057 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100060 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100200 Or LstIncmDet(Tj).CI_IncomeCalculation = 100075 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100067 Or LstIncmDet(Tj).CI_IncomeCalculation = 100068 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100087 or LstIncmDet(Tj).CI_IncomeCalculation = 999999 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 120 or LstIncmDet(Tj).CI_IncomeCalculation = 100006 _
                         or LstIncmDet(Tj).CI_IncomeCalculation = 100072 or LstIncmDet(Tj).CI_IncomeCalculation = 100032 _
                         or LstIncmDet(Tj).CI_IncomeCalculation = 100080 or LstIncmDet(Tj).CI_IncomeCalculation = 100101 _
                         or LstIncmDet(Tj).CI_IncomeCalculation = 100045 Or LstIncmDet(Tj).CI_IncomeCalculation = 100102 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100103 Or LstIncmDet(Tj).CI_IncomeCalculation = 100104 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100105 Or LstIncmDet(Tj).CI_IncomeCalculation = 100097 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100099 Or LstIncmDet(Tj).CI_IncomeCalculation = 100109 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100081 Or LstIncmDet(Tj).CI_IncomeCalculation = 100082 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation =100114 Or LstIncmDet(Tj).CI_IncomeCalculation = 100029 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation =100053 Or LstIncmDet(Tj).CI_IncomeCalculation =1301 Or LstIncmDet(Tj).CI_IncomeCalculation =100202 Then 

                        Else
                        	if IsDBNull(LstIncmDet(Tj).SysValue) or LstIncmDet(Tj).SysValue=0 Then 
                        		TotalP +=  LstIncmDet(Tj).Value
                        	Else
                        		TotalP += (IIf(IsDBNull(LstIncmDet(Tj).SysValue), LstIncmDet(Tj).Value, LstIncmDet(Tj).SysValue))
                        	End if	
                            
                        End If
                    Next
				'	YY=1
			     
				Dim bbb as Double 
				bbb =  BedahiFAdd

                    For Tj = 0 To LstIncmDet.count - 1
                        Dim TmpDocDetailsBeD As New BIZ.Communication.DataAccess.Accounting_DocDetails

                        TmpDocDetailsBeD.Price = 0
                        If LstIncmDet(Tj).CI_IncomeCalculation = 100036 Or LstIncmDet(Tj).CI_IncomeCalculation = 100041 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100042 Or LstIncmDet(Tj).CI_IncomeCalculation = 100043 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100047 Or LstIncmDet(Tj).CI_IncomeCalculation = 100048 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100049 Or LstIncmDet(Tj).CI_IncomeCalculation = 100050 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100052 Or LstIncmDet(Tj).CI_IncomeCalculation = 100028 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100016 Or LstIncmDet(Tj).CI_IncomeCalculation = 100009 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100002 Or LstIncmDet(Tj).CI_IncomeCalculation = 1091 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 1101   Or LstIncmDet(Tj).CI_IncomeCalculation = 100061 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100055 Or LstIncmDet(Tj).CI_IncomeCalculation = 100057 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100060 Or LstIncmDet(Tj).CI_IncomeCalculation = 100029 _ 
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100200 Or LstIncmDet(Tj).CI_IncomeCalculation = 100075 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100067 Or LstIncmDet(Tj).CI_IncomeCalculation = 100068 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100087 or LstIncmDet(Tj).CI_IncomeCalculation = 999999 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 120 or LstIncmDet(Tj).CI_IncomeCalculation = 100006 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100072 or LstIncmDet(Tj).CI_IncomeCalculation = 100032 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100080 or LstIncmDet(Tj).CI_IncomeCalculation = 100101 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100045 Or LstIncmDet(Tj).CI_IncomeCalculation = 100102 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100103 Or LstIncmDet(Tj).CI_IncomeCalculation = 100104 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100105 Or LstIncmDet(Tj).CI_IncomeCalculation = 100097 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100099 Or LstIncmDet(Tj).CI_IncomeCalculation = 100109 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation =100114 Or LstIncmDet(Tj).CI_IncomeCalculation = 100081 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100082 Or LstIncmDet(Tj).CI_IncomeCalculation = 100053 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 1301  Or LstIncmDet(Tj).CI_IncomeCalculation = 100202 Then  
                            TmpDocDetailsBeD.Price = 0
                        Else
                            TmpDocDetailsBeD.Price = (IIf(IsDBNull(LstIncmDet(Tj).SysValue), LstIncmDet(Tj).Value, LstIncmDet(Tj).SysValue))
                        End If
						
                        TmpDocDetailsBeD.Price = ((TmpDocDetailsBeD.Price * BedahiFAdd) / TotalP) * (-1)
                      
                        TmpDocDetailsBeD.Price = Math.Round(convert.toDecimal(TmpDocDetailsBeD.Price), 0)
                        Dim TmpIncomeCalculationDesc =  Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstIncmDet(Tj).CI_IncomeCalculation)

                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpDocDetailsBeD.AccountNoComments = ""
                        Else
                            TmpDocDetailsBeD.AccountNoComments =  IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If

                        TmpDocDetailsBeD.WrapperAccountNo = LstIncmDet(Tj).CI_IncomeCalculation
                        TmpDocDetailsBeD.FicheNo = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo

                        TmpDocDetailsBeD.BillID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
                        TmpDocDetailsBeD.PaymentID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
                        
                        TmpDocDetailsBeD.BankCode =CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                        'TmpDocDetailsBeD.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    				'	if TmpDocDetailsBeD.BankCode="" or TmpDocDetailsBeD.BankCode is Nothing Then  TmpDocDetailsBeD.BankCode= 18
     				 	
                        if CStr(TmpDocDetailsBeD.BankCode)=""  Then  TmpDocDetailsBeD.BankCode= 18
     					TmpChekNo= CStr(TmpDocDetailsBeD.BankCode)
    					'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                         Dim tmpdatenew As String = ""
						If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
	                    	tmpdatenew = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
	                	Else
	                    	tmpdatenew = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
	                	End If
	 
                  
                        TmpDocDetailsBeD.PaymentDate =ChangeDate(tmpdatenew)


                        
                        TmpDocDetailsBeD.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                        TmpDocDetailsBeD.IncmRow = YY
                        
                        If TmpDocDetailsBeD.Price <> 0 Then
                        
                            bbb=bbb-TmpDocDetailsBeD.Price
                            TmpDocDetailsBeD.Price=Math.Min(convert.toDecimal(bbb),convert.toDecimal(TmpDocDetailsBeD.Price))
                           
                            TmpAccounting_DocDetailsListTotal.Add(TmpDocDetailsBeD)
                           
                            yy += 1
                        End If

                    Next

                End If

		
		                    
                ''''''''''''''''''new 

               TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                		               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If TmpInComeCode.ToString = DBNull.Value.ToString or TmpInComeCode.ToString=0 Or TmpDT(Ti).CI_IncomeCalculation = 100036 Or TmpDT(Ti).CI_IncomeCalculation = 100041 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100042 Or TmpDT(Ti).CI_IncomeCalculation = 100043 Or TmpDT(Ti).CI_IncomeCalculation = 100047 Or TmpDT(Ti).CI_IncomeCalculation = 100048 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100049 Or TmpDT(Ti).CI_IncomeCalculation = 100050 Or TmpDT(Ti).CI_IncomeCalculation = 100052 Or TmpDT(Ti).CI_IncomeCalculation = 100028 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100016 Or TmpDT(Ti).CI_IncomeCalculation = 100009 Or TmpDT(Ti).CI_IncomeCalculation = 100002 Or TmpDT(Ti).CI_IncomeCalculation = 1091 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 1101   Or TmpDT(Ti).CI_IncomeCalculation = 100055 Or TmpDT(Ti).CI_IncomeCalculation = 100057 Or TmpDT(Ti).CI_IncomeCalculation = 100061 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100060 Or TmpDT(Ti).CI_IncomeCalculation =100200 Or TmpDT(Ti).CI_IncomeCalculation =100075 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100067 Or TmpDT(Ti).CI_IncomeCalculation = 100068 Or TmpDT(Ti).CI_IncomeCalculation = 100087 Or TmpDT(Ti).CI_IncomeCalculation =  999999 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 120 or TmpDT(Ti).CI_IncomeCalculation = 100006 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100072 or TmpDT(Ti).CI_IncomeCalculation = 100032 _
                        or TmpDT(Ti).CI_IncomeCalculation = 100080 or TmpDT(Ti).CI_IncomeCalculation =100101 or TmpDT(Ti).CI_IncomeCalculation = 100045 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100102 Or TmpDT(Ti).CI_IncomeCalculation = 100029 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100103 Or TmpDT(Ti).CI_IncomeCalculation = 100104 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100105 Or TmpDT(Ti).CI_IncomeCalculation = 100097 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100099 Or TmpDT(Ti).CI_IncomeCalculation = 100109 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100114 Or TmpDT(Ti).CI_IncomeCalculation = 100081 Or TmpDT(Ti).CI_IncomeCalculation = 100082 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100053 Or TmpDT(Ti).CI_IncomeCalculation =1301 Or TmpDT(Ti).CI_IncomeCalculation =100202 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                        
                            Dim LstOdd As New List(Of Global.DtoSC.Income_OddmentAccount)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 2 or f.CI_OddmentType = 3 or f.CI_OddmentType = 6 or f.CI_OddmentType=7) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price - LstOdd.Sum(Function(f) f.Value)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 8 or f.CI_OddmentType =1 or f.CI_OddmentType = 4) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price + LstOdd.Sum(Function(f) f.Value)
			                TmpOne.WrapperAccountNo = IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

                     
						if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=154 Then TmpOne.FileNo=4
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
           
				Dim LstOdd_1 As New List(Of DtoSC.Income_OddmentAccount)
                LstOdd_1 = Info8.GetIncome.GetIncome_OddmentAccount
                Dim ChechOdd as Integer=0
                Dim Ti_1 as Integer
				For Ti=0 to LstOdd_1.count -1
					ChechOdd=0
					For Ti_1=0 to TmpAccounting_DocDetailsList.count -1 
						if LstOdd_1(Ti).CI_IncomeCalculation=TmpAccounting_DocDetailsList(Ti_1).WrapperAccountNo Then	ChechOdd=1
						If LstOdd_1(Ti).CI_IncomeCalculation =0 or LstOdd_1(Ti).CI_IncomeCalculation = 100036 Or LstOdd_1(Ti).CI_IncomeCalculation = 100041 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100042 Or LstOdd_1(Ti).CI_IncomeCalculation = 100043 Or LstOdd_1(Ti).CI_IncomeCalculation = 100047 Or LstOdd_1(Ti).CI_IncomeCalculation = 100048 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100049 Or LstOdd_1(Ti).CI_IncomeCalculation = 100050 Or LstOdd_1(Ti).CI_IncomeCalculation = 100052 Or LstOdd_1(Ti).CI_IncomeCalculation = 100028 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100016 Or LstOdd_1(Ti).CI_IncomeCalculation = 100009 Or LstOdd_1(Ti).CI_IncomeCalculation = 100002 Or LstOdd_1(Ti).CI_IncomeCalculation = 1091 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 1101   Or LstOdd_1(Ti).CI_IncomeCalculation = 100055 Or LstOdd_1(Ti).CI_IncomeCalculation = 100057 Or LstOdd_1(Ti).CI_IncomeCalculation = 100061 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100060 Or LstOdd_1(Ti).CI_IncomeCalculation = 100200 Or LstOdd_1(Ti).CI_IncomeCalculation = 100075 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100067 Or LstOdd_1(Ti).CI_IncomeCalculation = 100068 or LstOdd_1(Ti).CI_IncomeCalculation = 100029 Or LstOdd_1(Ti).CI_IncomeCalculation = 100087 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =  999999 Or LstOdd_1(Ti).CI_IncomeCalculation = 120 or LstOdd_1(Ti).CI_IncomeCalculation = 100006 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100072 or LstOdd_1(Ti).CI_IncomeCalculation = 100032  or LstOdd_1(Ti).CI_IncomeCalculation =100080 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100101 or LstOdd_1(Ti).CI_IncomeCalculation = 100045  Or LstOdd_1(Ti).CI_IncomeCalculation = 100102 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100103 Or LstOdd_1(Ti).CI_IncomeCalculation = 100104 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100105 Or LstOdd_1(Ti).CI_IncomeCalculation = 100097 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100099 Or LstOdd_1(Ti).CI_IncomeCalculation = 100109 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100114 Or LstOdd_1(Ti).CI_IncomeCalculation = 100081 Or LstOdd_1(Ti).CI_IncomeCalculation = 100082 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100053 Or LstOdd_1(Ti).CI_IncomeCalculation =1301 Or LstOdd_1(Ti).CI_IncomeCalculation =100201 Or LstOdd_1(Ti).CI_IncomeCalculation =100202 Then   ChechOdd=1
                        if ChechOdd=0 Then if Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="0" or Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="1" Then  ChechOdd=1 
					Next
					  
					if ChechOdd=0 Then 
						 Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
						 if LstOdd_1(Ti).CI_OddmentType = 2 or LstOdd_1(Ti).CI_OddmentType = 3 or LstOdd_1(Ti).CI_OddmentType = 6 or LstOdd_1(Ti).CI_OddmentType=7  Then
	                     	TmpOne.Price = LstOdd_1(Ti).Value * (-1)
	                     Else
	                     	TmpOne.Price = LstOdd_1(Ti).Value
	                     End if 
	                     if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=154 Then TmpOne.FileNo=4	
						 TmpOne.WrapperAccountNo= LstOdd_1(Ti).CI_IncomeCalculation
						 Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstOdd_1(Ti).CI_IncomeCalculation)
						 If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
	                        TmpOne.AccountNoComments = ""
	                     Else
	                        TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
	                     End If
	                     a +=TmpOne.Price
	                     TmpAccounting_DocDetailsList.Add(TmpOne)
	                End if     
                     
				Next
                '--------------------------------------------'---------------------
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
   
              
                Dim TmpChek As Integer = 0
                

				TmpChek=0

                Dim TakhfifRound As Decimal = 0
                Dim TakhfifRound_1 As Decimal = 0
                Dim TakhfifRound_Cash As Decimal = 0
                Dim i As Integer = 0
                Dim jjjj As Integer = 0
               
                Dim test As Integer = 1
                Dim tmpdate As String = ""


                TakhfifRound_1 = TakhfifRound - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue

                '---------------------------------------------------------------------------
                '-------------------------------------------------------------------------------        
                TakhfifRound = 0

                	
                Dim TTj As Integer = 0
                
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                BedeHiTmp=BedeHiTmp+BedahiFAdd
                		
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = 0
                    
                    If a <> 0 Then
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal((Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price) * Convert.ToDecimal(BedeHiTmp)) / Convert.ToDecimal(a)),0) ' (Math.Round( (TmpAccounting_DocDetailsList(TTj).Price*BedeHiTmp)/a,2))
                    Else
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price),0)
                    End If
					if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=154 Then TmpDocDetails.FileNo=4 	
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                  '  TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    				'if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
    				'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                   ' TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    TakhfifRound += TmpDocDetails.Price
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
 

                
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 5
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
                If DtoAccounting_DocHeaderTotal.SaraPrice <> TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price) Then
                    Dim gg As Integer = 0
                    Dim PriceTmp As Decimal = 0
                    
                    if TmpAccounting_DocDetailsListTotal.count>0 Then 
	                    For gg = 1 To TmpAccounting_DocDetailsListTotal.count - 1
	                        PriceTmp += TmpAccounting_DocDetailsListTotal(gg).Price
	                    Next
	                 
                    TmpAccounting_DocDetailsListTotal(0).Price = DtoAccounting_DocHeaderTotal.SaraPrice - PriceTmp
					End if   
                End If
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit   	
                		ListRefP.add(Refcenter)
                        
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                RefFund.Value = 120 
		                ListRefP.add(RefFund)
						
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
						
						
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
				
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
						
						Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
						
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               	
		               
		                Mess.ActTyp = 3
		                Mess.DocTyp = 3
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد اوراق بهادار خزانه"  
		                Mess.DocTypDsc = "عوارض اوراق بهادار خزانه"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		         FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""
					
                 
                tmpstr = TmpDocument.Save(NidF)
                
                

                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری                               
    Catch ex As Exception
        Info8.AddError(BIZ.SA.EumErrorAction.Stop, "اوراق بهادار", "اشکال در ارسال به رایورز" + ex.Message)
    End Try
End Function

<DisplayName("سپرده درآمد")> Public Function iNcOMESeprdeh()
 
'    Try
     
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                 Dim ExistRayvarz As Boolean =True
   
        'sp 360242
           If (Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup > 129 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup < 143) or   Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=155  Then  ExistRayvarz = False
	
''		if ExistRayvarz = False Then  	ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
     '   
		if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus=3 Then  ExistRayvarz=True

           
         
              
              If ExistRayvarz = False Then
               
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                Dim BedeHiTmp As Decimal = 0 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
				Dim  BedahiFAdd as Double=0
				BedahiFAdd=0 'BedeHi(DistrickBranch, Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo)
              '                
                ''''''''''''''''''new 

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               	
                        
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If  TmpDT(Ti).CI_IncomeCalculation <> 120 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                            TmpOne.Price= Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable ' 270919 TmpOne.Price
			                TmpOne.WrapperAccountNo = 209021000 ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

                     
						 
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
         
		
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		        DistrickBranch=tmpDistrict
		    	Select Case DistrickBranch
                    Case 1
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case 2
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case 3
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case 4
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case 5
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case 6
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case 7
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case 8
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case 9
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case 10
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case 11
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case 12
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case 80
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select       
		      
		    
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                 		
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                	
                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = a
                    
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                    'TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    				'if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				 TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                     if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				 TmpChekNo= CStr(TmpDocDetails.BankCode)
    				'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                    'TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  	
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
                   
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
                'Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
                
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
          	
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit  '99436 TmpDate
                		ListRefP.add(Refcenter)
                        'sp 308718
                      '  Dim RefcenterA As New BIZ.Communication.RefParameetrs
                	'	RefcenterA.Name = "Center"
                '			if tmpDistrict = 1 or tmpDistrict = 201  Then
		            '    		RefcenterA.Value = 200201021 
		           '     	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		           '     		RefcenterA.Value = 200202017 
		           '     	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		           '     		RefcenterA.Value = 200203021
		           '     	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		           '     		RefcenterA.Value = 200204018  	  	
		           '     	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		           '     		RefcenterA.Value = 200205016   	   		 	
		            '    	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		            '    		RefcenterA.Value = 200206016
		            '    	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		           '     		RefcenterA.Value = 200207017 
		            '     	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		            '     		RefcenterA.Value = 200208017   
		             '    	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 	'			RefcenterA.Value = 200209016 
                 	'		ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 	'			RefcenterA.Value = 200210022 
                 	'		ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 	'			RefcenterA.Value = 200211015 
                 	'		ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 	''			RefcenterA.Value = 200212016 
                 	''		ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 	'			RefcenterA.Value = 200218028  	 		 			 		 			 		 		  	   		   		 	
		            '    	Else
		            ''        	RefcenterA.Value = 1200
		            '        End if 	
		           '     
                '		ListRefP.add(RefcenterA)
                        
                         
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
	  
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
	
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                
		                    '153818
		                    
		                	if tmpDistrict = 1 or tmpDistrict = 201  Then
		                		RefFund.Value = 200201021 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		RefFund.Value = 200202017 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		RefFund.Value = 200203021
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		RefFund.Value = 200204018  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		RefFund.Value = 200205016   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		RefFund.Value = 200206016
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		                		RefFund.Value = 200207017 
		                 	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                 		RefFund.Value = 200208017   
		                 	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				RefFund.Value = 200209016 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				RefFund.Value = 200210022 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				RefFund.Value = 200211015 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				RefFund.Value = 200212016 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				RefFund.Value = 200218028  	 		 			 		 			 		 		  	   		   		 	
		                	Else
		                    	RefFund.Value = 1200
		                    End if 	
		                
		                
		                
		                ListRefP.add(RefFund)
						
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
						
						
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
					
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
                		
                		Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
                		
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		              
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                Mess.ActTyp = 3  
		                Mess.DocTyp = 3
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "عوارض سرا"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""

               
                tmpstr = TmpDocument.Save(NidF)
                
                

                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری  
                               
  '  Catch ex As Exception
    '    Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
  '  End Try
End Function

<DisplayName("اشغال معابر درآمد")> Public Function iNcOMEEshghal()
 
'    Try
        
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                Dim ExistRayvarz As Boolean =True
   				
        		Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		    	
       	  
		
           ''if ExistRayvarz = False Then  	ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
        
		   if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus=3 Then  ExistRayvarz=True

           
                 
           If tmpDistrict=80 Then 
       	   	 if  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =124  Then  ExistRayvarz = False
		  Else
		  	if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =7 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =14 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =19 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =21 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =28 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =35 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =42 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =49 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =46 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =63 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =70 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =77 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =84 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =85 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =102 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =120 _
       	   	 or Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =124  Then  ExistRayvarz = False

		  End if 
           
          Select Case tmpDistrict
                    Case 1
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case 2
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case 3
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case 4
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case 5
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case 6
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case 7
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case 8
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case 9
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case 10
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case 11
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case 12
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case 80
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select       
                 
                 
                 
              If ExistRayvarz = False Then
                
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

               
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
			

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                				               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If  TmpDT(Ti).CI_IncomeCalculation <> 100006 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                            TmpOne.Price= Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable '270919 TmpOne.Price
			                TmpOne.WrapperAccountNo = 205071000 ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                
			            End If

                     
						 
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
            
			
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                
		    
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price =TmpAccounting_DocDetailsList(TTj).Price
                    
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                   ' TmpDocDetails.BankCode =  CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                  '' 	TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    			'	if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				 TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                     if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				 TmpChekNo= CStr(TmpDocDetails.BankCode)
    				'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                    'TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
                 
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                 
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
               
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
            
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit '99436 TmpDate
                		ListRefP.add(Refcenter)
                        
                        
                        Dim Refcenter2 As New BIZ.Communication.RefParameetrs
                		Refcenter2.Name = "Center2"
                			if tmpDistrict = 1 or tmpDistrict = 201 Then
		                		Refcenter2.Value = 5519510 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		Refcenter2.Value = 5519520 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		Refcenter2.Value = 5519530
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		Refcenter2.Value = 5519540  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		Refcenter2.Value = 5519550   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		Refcenter2.Value = 5519560
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		               			Refcenter2.Value = 5519570 
		                 	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                 		Refcenter2.Value = 5519580   
		                	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				Refcenter2.Value = 5519590 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				Refcenter2.Value = 5519600 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				Refcenter2.Value = 5519610 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				Refcenter2.Value = 5519630 	
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				Refcenter2.Value = 5519620 	 		 		 			 		 		  	   		   		 	
		                	Else
		                    	Refcenter2.Value = 1200
		                    End if 	
                		ListRefP.add(Refcenter2)
                       
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                
		                    '153818
		                    
		                	if tmpDistrict = 1 or tmpDistrict = 201 Then
		                		RefFund.Value = 200201021 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		RefFund.Value = 200202017 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		RefFund.Value = 200203021
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		RefFund.Value = 200204018  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		RefFund.Value = 200205016   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		RefFund.Value = 200206016
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		                		RefFund.Value = 200207017 
		                 	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                 		RefFund.Value = 200208017   
		                 	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				RefFund.Value = 200209016 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				RefFund.Value = 200210022 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				RefFund.Value = 200211015 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				RefFund.Value = 200212016 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				RefFund.Value = 200218028 	 		 		 			 		 		  	   		   		 	
		                	Else
		                    	RefFund.Value = 1200
		                    End if 	
		                
		                
		                
		                ListRefP.add(RefFund)
		                
		                
		                
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
		                
		                
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs										   
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
						
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
		
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                Mess.ActTyp = 3
		                Mess.DocTyp = 3
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "عوارض سرا"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""

              
                tmpstr = TmpDocument.Save(NidF)
                
                 
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری                               
  '  Catch ex As Exception
    '    Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
  '  End Try
End Function


<DisplayName(" قطار شهری درآمد")> Public Function iNcOMEGhatar_Shahri()
 
'    Try
    
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                 Dim ExistRayvarz As Boolean =True
   
        
       	   
		 
           If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =153 Then ExistRayvarz = False
		
''		if ExistRayvarz = False Then  	ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
        
	'	if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus=3 Then  ExistRayvarz=True

           
          
              
              If ExistRayvarz = False Then
               
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                Dim BedeHiTmp As Decimal = 0 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
				Dim  BedahiFAdd as Double=0
				BedahiFAdd=0 'BedeHi(DistrickBranch, Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo)
              '                
                ''''''''''''''''''new 

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                				               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If  TmpDT(Ti).CI_IncomeCalculation <> 100101 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                            TmpOne.Price= Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable '270919  TmpOne.Price
			                TmpOne.WrapperAccountNo = 401130800 ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

                     
						 
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
            
			
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		    	DistrickBranch = 150 '260988  21
		    	
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                Dim T_Payable as Double
                T_Payable=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    if T_Payable-a<0 Then 
                    	TmpDocDetails.Price = T_Payable
                    Else	
                    	TmpDocDetails.Price = a
                    End if 
                    T_Payable=Math.Min (T_Payable-a	,0)
                    
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                 '   TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    			'	if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
    				'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                    TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
                 
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
                
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
             
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                		Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit  '99436 TmpDate
                		ListRefP.add(Refcenter)
                        
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                RefFund.Value = 265325013 '''260988    1300 
		                		                
		                ListRefP.add(RefFund)
		                
		                
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
						
						
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
		                
		                Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
				
						Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
                
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                Mess.ActTyp = 3
		                Mess.DocTyp = 3
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "عوارض قطار شهری"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""

                
                tmpstr = TmpDocument.Save(NidF)
                
                

                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری  
                               
  '  Catch ex As Exception
    '    Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
  '  End Try
End Function


<DisplayName("برگشت از سپرده درآمد")> Public Function iNcOMEBackSeprdeh()
 
'    Try
        
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                Dim ExistRayvarz As Boolean =True
   				
        		Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		    	
       	  
		
           ''if ExistRayvarz = False Then  	ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
        
		  ' if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus=3 Then  ExistRayvarz=True

           
                 
           if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =151  Then  ExistRayvarz = False

		 
           
          Select Case tmpDistrict
                    Case 1
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case 2
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case 3
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case 4
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case 5
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case 6
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case 7
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case 8
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case 9
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case 10
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case 11
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case 12
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case 80
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select       
                 
                 
                 
              If ExistRayvarz = False Then
                
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

               
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
			

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
                Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                				               
                TmpOne.Price = (-1)*Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable   '309337   '308718
                TmpOne.WrapperAccountNo = 229091300 '''308718  229091300  ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                
			    Dim TmpIncomeCalculationDesc = "برگشت از سپرده"
                TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                If TmpOne.WrapperAccountNo <> 0 Then
                   TmpAccounting_DocDetailsList.Add(TmpOne)
               End if  

            
			
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                
		    
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = TmpAccounting_DocDetailsList(TTj).Price  '309337   '308718
                    TmpDocDetails.FileNo=3
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                   ' TmpDocDetails.BankCode =  CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    			'	if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
    				'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                   'TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
                 
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice = (-1)* Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable  '309337
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                 
                DtoAccounting_DocHeaderTotal.PhasType = 2 '309337
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
               
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
            
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit '99436 TmpDate
                		ListRefP.add(Refcenter)
                        
                        
                        Dim Refcenter2 As New BIZ.Communication.RefParameetrs
                		Refcenter2.Name = "Center2"
                			if tmpDistrict = 1 or tmpDistrict = 201 Then
		                		Refcenter2.Value = 5519510 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		Refcenter2.Value = 5519520 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		Refcenter2.Value = 5519530
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		Refcenter2.Value = 5519540  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		Refcenter2.Value = 5519550   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		Refcenter2.Value = 5519560
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		               			Refcenter2.Value = 5519570 
		                 	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                 		Refcenter2.Value = 5519580   
		                	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				Refcenter2.Value = 5519590 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				Refcenter2.Value = 5519600 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				Refcenter2.Value = 5519610 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				Refcenter2.Value = 5519630 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				Refcenter2.Value = 5519620 	 			 		 			 		 		  	   		   		 	
		                	Else
		                    	Refcenter2.Value = 1200
		                    End if 	
                		ListRefP.add(Refcenter2)
                       
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                
		                    '153818
		                    
		                	if tmpDistrict = 1 or tmpDistrict = 201 Then
		                		RefFund.Value = 200201021 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		RefFund.Value = 200202017 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		RefFund.Value = 200203021
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		RefFund.Value = 200204018  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		RefFund.Value = 200205016   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		RefFund.Value = 200206016
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		                		RefFund.Value = 200207017 
		                 	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                 		RefFund.Value = 200208017   
		                 	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				RefFund.Value = 200209016 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				RefFund.Value = 200210022 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				RefFund.Value = 200211015 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				RefFund.Value = 200212016 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				RefFund.Value = 200218028 	 		 		 			 		 		  	   		   		 	
		                	Else
		                    	RefFund.Value = 1200
		                    End if 	
		                
		                
		                
		                ListRefP.add(RefFund)
			
						
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
						
								
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 1
		                ListRefP.add(Refvchrtyp)
				
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
						
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                Mess.ActTyp = 1 '309337'3
		                Mess.DocTyp = 10 'sp 308718     3
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "عوارض برگشت از سپرده درآمد"
		                Mess.vchrtyp=1
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		         FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""

              
                tmpstr = TmpDocument.Save(NidF)
                
                 
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری                               
  '  Catch ex As Exception
    '    Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
  '  End Try
End Function

<DisplayName("درآمد حواله تقسیط ")> Public Function iNcOMEHavaleT()
 
    Try
    
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                If PtmpDistrict = "051" Then
                    DistrickBranch = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentId.Substring(10, 2)
                    If DistrickBranch > 12 And DistrickBranch <> 80 And DistrickBranch <> 218  Then DistrickBranch = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentId.Substring(10, 1)
                End If

                


                Select Case PtmpDistrict
                    Case "511"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "512"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "513"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case "514"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case "515"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "516"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "517"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "518"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "519"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "520"
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case "521"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "522"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "523"
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select
               if  DistrickBranch=0 Then 
               		Select Case PtmpDistrict
                    Case "401"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "402"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "403"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                    Case "404"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case "405"
                      	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
	                    	DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "406"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "407"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "408"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "409"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "410"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
	                     	DistrickBranch =210
	                     Else
	        				DistrickBranch = 10
		                 End if	
                    Case "411"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "412"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "400"
                    
                     if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                	End Select
               
               End if 
              
              if  DistrickBranch=0 Then 
		             
		             PtmpDistrict=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno.Substring(2,2)

               		Select Case PtmpDistrict
                    Case "01"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "02"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "03"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if	
                    Case "04"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if	
                    Case "05"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
	                    	DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "06"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "07"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "08"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "09"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "10"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
	                     	DistrickBranch =210
	                     Else
	        				DistrickBranch = 10
		                 End if	
                    Case "11"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "12"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "80"
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                	End Select
               
               End if   
               
               Dim ExistRayvarz As Boolean =True
     
			if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=152  Then ExistRayvarz = False
	
		
''		if ExistRayvarz = False Then  	ExistRayvarz= Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
        

                 
              If ExistRayvarz = False Then
               Call GetSara8Workflow()
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
               ' Dim BedeHiTmp As Decimal = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
               '  if  ucase(Info8.User.UserGuid.tostring)=ucase("ca742134-44bb-4ba6-b0c4-e5e186600a0a") or ucase(Info8.User.UserGuid.tostring)=ucase("6F99C240-C92B-4FB3-99DB-6760750167EB")  Then 
                   Dim BedeHiTmp As Decimal = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 
               ' End if

                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
		Dim  BedahiFAdd as Double=0
		BedahiFAdd=BedeHi(DistrickBranch, Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo)
              '  if 1>2 Then
              
                If BedahiFAdd > 0 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=152 Then
 				
                    Dim TotalP As Decimal

                    For Tj = 0 To LstIncmDet.count - 1

                         If LstIncmDet(Tj).CI_IncomeCalculation = 100036  Or LstIncmDet(Tj).CI_IncomeCalculation = 100041 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100042 Or LstIncmDet(Tj).CI_IncomeCalculation = 100043 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100047 Or LstIncmDet(Tj).CI_IncomeCalculation = 100048 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100049 Or LstIncmDet(Tj).CI_IncomeCalculation = 100050 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100052 Or LstIncmDet(Tj).CI_IncomeCalculation = 100028 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100016 Or LstIncmDet(Tj).CI_IncomeCalculation = 100009 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100002 Or LstIncmDet(Tj).CI_IncomeCalculation = 1091 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 1101   Or LstIncmDet(Tj).CI_IncomeCalculation = 100061 _ 
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100055 Or LstIncmDet(Tj).CI_IncomeCalculation = 100057 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100060 Or LstIncmDet(Tj).CI_IncomeCalculation = 100029 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100200 Or LstIncmDet(Tj).CI_IncomeCalculation = 100075 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100067 Or LstIncmDet(Tj).CI_IncomeCalculation = 100068 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100087 or LstIncmDet(Tj).CI_IncomeCalculation = 999999 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 120 or LstIncmDet(Tj).CI_IncomeCalculation = 100006 _
                         or LstIncmDet(Tj).CI_IncomeCalculation = 100072 or LstIncmDet(Tj).CI_IncomeCalculation = 100032 _
                         or LstIncmDet(Tj).CI_IncomeCalculation = 100080 or LstIncmDet(Tj).CI_IncomeCalculation = 100101 _
                         or LstIncmDet(Tj).CI_IncomeCalculation = 100045 Or LstIncmDet(Tj).CI_IncomeCalculation = 100102 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100103 Or LstIncmDet(Tj).CI_IncomeCalculation = 100104 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation = 100105 Or LstIncmDet(Tj).CI_IncomeCalculation = 100099 _
                         or LstIncmDet(Tj).CI_IncomeCalculation = 100109 Or LstIncmDet(Tj).CI_IncomeCalculation = 100081 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation =100114 Or LstIncmDet(Tj).CI_IncomeCalculation = 100082 _
                         Or LstIncmDet(Tj).CI_IncomeCalculation =100053 Or LstIncmDet(Tj).CI_IncomeCalculation = 1301 Or LstIncmDet(Tj).CI_IncomeCalculation = 100202  Then 

                        Else
                        	if IsDBNull(LstIncmDet(Tj).SysValue) or LstIncmDet(Tj).SysValue=0 Then 
                        		TotalP +=  LstIncmDet(Tj).Value
                        	Else
                        		TotalP += (IIf(IsDBNull(LstIncmDet(Tj).SysValue), LstIncmDet(Tj).Value, LstIncmDet(Tj).SysValue))
                        	End if	
                            
                        End If
                    Next
				'	YY=1
			     
				Dim bbb as Double 
				bbb =  BedahiFAdd

                    For Tj = 0 To LstIncmDet.count - 1
                        Dim TmpDocDetailsBeD As New BIZ.Communication.DataAccess.Accounting_DocDetails

                        TmpDocDetailsBeD.Price = 0
                        If LstIncmDet(Tj).CI_IncomeCalculation = 100036 Or LstIncmDet(Tj).CI_IncomeCalculation = 100041 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100042 Or LstIncmDet(Tj).CI_IncomeCalculation = 100043 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100047 Or LstIncmDet(Tj).CI_IncomeCalculation = 100048 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100049 Or LstIncmDet(Tj).CI_IncomeCalculation = 100050 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100052 Or LstIncmDet(Tj).CI_IncomeCalculation = 100028 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100016 Or LstIncmDet(Tj).CI_IncomeCalculation = 100009 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100002 Or LstIncmDet(Tj).CI_IncomeCalculation = 1091 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 1101   Or LstIncmDet(Tj).CI_IncomeCalculation = 100061 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100055 Or LstIncmDet(Tj).CI_IncomeCalculation = 100057 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100060 Or LstIncmDet(Tj).CI_IncomeCalculation = 100029 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100200 Or LstIncmDet(Tj).CI_IncomeCalculation = 100075 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100067 Or LstIncmDet(Tj).CI_IncomeCalculation = 100068 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 100087 or LstIncmDet(Tj).CI_IncomeCalculation = 999999 _
			               Or LstIncmDet(Tj).CI_IncomeCalculation = 120 or LstIncmDet(Tj).CI_IncomeCalculation = 100006 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100072 or LstIncmDet(Tj).CI_IncomeCalculation = 100032 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100080 or LstIncmDet(Tj).CI_IncomeCalculation = 100101 _
			               or LstIncmDet(Tj).CI_IncomeCalculation = 100045 Or LstIncmDet(Tj).CI_IncomeCalculation = 100102 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100103 Or LstIncmDet(Tj).CI_IncomeCalculation = 100104 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100105 Or LstIncmDet(Tj).CI_IncomeCalculation = 100109 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation = 100099 Or LstIncmDet(Tj).CI_IncomeCalculation = 100081 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation =100114 Or LstIncmDet(Tj).CI_IncomeCalculation = 100082 _
                           Or LstIncmDet(Tj).CI_IncomeCalculation =100053 Or LstIncmDet(Tj).CI_IncomeCalculation =1301 Or LstIncmDet(Tj).CI_IncomeCalculation =100202 Then  
                            TmpDocDetailsBeD.Price = 0
                        Else
                            TmpDocDetailsBeD.Price = (IIf(IsDBNull(LstIncmDet(Tj).SysValue), LstIncmDet(Tj).Value, LstIncmDet(Tj).SysValue))
                        End If
						
                        TmpDocDetailsBeD.Price = ((TmpDocDetailsBeD.Price * BedahiFAdd) / TotalP) * (-1)
                      
                        TmpDocDetailsBeD.Price = Math.Round(convert.toDecimal(TmpDocDetailsBeD.Price), 0)
                        Dim TmpIncomeCalculationDesc =  Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstIncmDet(Tj).CI_IncomeCalculation)

                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpDocDetailsBeD.AccountNoComments = ""
                        Else
                            TmpDocDetailsBeD.AccountNoComments =  IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If

                        TmpDocDetailsBeD.WrapperAccountNo = LstIncmDet(Tj).CI_IncomeCalculation
                        TmpDocDetailsBeD.FicheNo = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo

                        TmpDocDetailsBeD.BillID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
                        TmpDocDetailsBeD.PaymentID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
                        
                       ' TmpDocDetailsBeD.BankCode =CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                      '  TmpDocDetailsBeD.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    				'	if TmpDocDetailsBeD.BankCode="" or TmpDocDetailsBeD.BankCode is Nothing Then  TmpDocDetailsBeD.BankCode= 18
     					TmpDocDetailsBeD.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                        if CStr(TmpDocDetailsBeD.BankCode)=""  Then  TmpDocDetailsBeD.BankCode= 18
     					TmpChekNo= CStr(TmpDocDetailsBeD.BankCode)
    					'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                       ' TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                         Dim tmpdatenew As String = ""
						If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
	                    	tmpdatenew = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
	                	Else
	                    	tmpdatenew = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
	                	End If
	 
                  
                        TmpDocDetailsBeD.PaymentDate =ChangeDate(tmpdatenew)


                        
                        TmpDocDetailsBeD.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                        TmpDocDetailsBeD.IncmRow = YY
                        
                        If TmpDocDetailsBeD.Price <> 0 Then
                        
                            bbb=bbb-TmpDocDetailsBeD.Price
                            TmpDocDetailsBeD.Price=Math.Min(convert.toDecimal(bbb),convert.toDecimal(TmpDocDetailsBeD.Price))
                           
                            TmpAccounting_DocDetailsListTotal.Add(TmpDocDetailsBeD)
                           
                            yy += 1
                        End If

                    Next

                End If

		
		                    
                ''''''''''''''''''new 

               TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                		               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If TmpInComeCode.ToString = DBNull.Value.ToString or TmpInComeCode.ToString=0 Or TmpDT(Ti).CI_IncomeCalculation = 100036 Or TmpDT(Ti).CI_IncomeCalculation = 100041 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100042 Or TmpDT(Ti).CI_IncomeCalculation = 100043 Or TmpDT(Ti).CI_IncomeCalculation = 100047 Or TmpDT(Ti).CI_IncomeCalculation = 100048 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100049 Or TmpDT(Ti).CI_IncomeCalculation = 100050 Or TmpDT(Ti).CI_IncomeCalculation = 100052 Or TmpDT(Ti).CI_IncomeCalculation = 100028 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100016 Or TmpDT(Ti).CI_IncomeCalculation = 100009 Or TmpDT(Ti).CI_IncomeCalculation = 100002 Or TmpDT(Ti).CI_IncomeCalculation = 1091 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 1101   Or TmpDT(Ti).CI_IncomeCalculation = 100055 Or TmpDT(Ti).CI_IncomeCalculation = 100057 Or TmpDT(Ti).CI_IncomeCalculation = 100061 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100060 Or TmpDT(Ti).CI_IncomeCalculation =100200 Or TmpDT(Ti).CI_IncomeCalculation =100075 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100067 Or TmpDT(Ti).CI_IncomeCalculation = 100068 Or TmpDT(Ti).CI_IncomeCalculation = 100087 Or TmpDT(Ti).CI_IncomeCalculation =  999999 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 120 or TmpDT(Ti).CI_IncomeCalculation = 100006 Or LstIncmDet(Tj).CI_IncomeCalculation = 100029 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100072 or TmpDT(Ti).CI_IncomeCalculation = 100032 _
                        or TmpDT(Ti).CI_IncomeCalculation = 100080 or TmpDT(Ti).CI_IncomeCalculation =100101 or TmpDT(Ti).CI_IncomeCalculation = 100045 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100102 Or TmpDT(Ti).CI_IncomeCalculation = 100099 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100103 Or TmpDT(Ti).CI_IncomeCalculation = 100104 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100105 Or TmpDT(Ti).CI_IncomeCalculation = 100109 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100114 Or TmpDT(Ti).CI_IncomeCalculation = 100081 Or TmpDT(Ti).CI_IncomeCalculation = 100082 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100053 Or TmpDT(Ti).CI_IncomeCalculation =1301 Or TmpDT(Ti).CI_IncomeCalculation =100202 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                        
                            Dim LstOdd As New List(Of Global.DtoSC.Income_OddmentAccount)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 2 or f.CI_OddmentType = 3 or f.CI_OddmentType = 6 or f.CI_OddmentType=7) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price - LstOdd.Sum(Function(f) f.Value)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 8 or f.CI_OddmentType =1 or f.CI_OddmentType = 4) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price + LstOdd.Sum(Function(f) f.Value)
			                TmpOne.WrapperAccountNo = IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

                     
						if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=152 Then TmpOne.FileNo=2
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
           
				Dim LstOdd_1 As New List(Of DtoSC.Income_OddmentAccount)
                LstOdd_1 = Info8.GetIncome.GetIncome_OddmentAccount
                Dim ChechOdd as Integer=0
                Dim Ti_1 as Integer
				For Ti=0 to LstOdd_1.count -1
					ChechOdd=0
					For Ti_1=0 to TmpAccounting_DocDetailsList.count -1 
						if LstOdd_1(Ti).CI_IncomeCalculation=TmpAccounting_DocDetailsList(Ti_1).WrapperAccountNo Then	ChechOdd=1
						If LstOdd_1(Ti).CI_IncomeCalculation =0 or LstOdd_1(Ti).CI_IncomeCalculation = 100036 Or LstOdd_1(Ti).CI_IncomeCalculation = 100041 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100042 Or LstOdd_1(Ti).CI_IncomeCalculation = 100043 Or LstOdd_1(Ti).CI_IncomeCalculation = 100047 Or LstOdd_1(Ti).CI_IncomeCalculation = 100048 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100049 Or LstOdd_1(Ti).CI_IncomeCalculation = 100050 Or LstOdd_1(Ti).CI_IncomeCalculation = 100052 Or LstOdd_1(Ti).CI_IncomeCalculation = 100028 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100016 Or LstOdd_1(Ti).CI_IncomeCalculation = 100009 Or LstOdd_1(Ti).CI_IncomeCalculation = 100002 Or LstOdd_1(Ti).CI_IncomeCalculation = 1091 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 1101   Or LstOdd_1(Ti).CI_IncomeCalculation = 100055 Or LstOdd_1(Ti).CI_IncomeCalculation = 100057 Or LstOdd_1(Ti).CI_IncomeCalculation = 100061 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100060 Or LstOdd_1(Ti).CI_IncomeCalculation = 100200 Or LstOdd_1(Ti).CI_IncomeCalculation = 100075 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100067 Or LstOdd_1(Ti).CI_IncomeCalculation = 100068 or LstOdd_1(Ti).CI_IncomeCalculation = 100029 Or LstOdd_1(Ti).CI_IncomeCalculation = 100087 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =  999999 Or LstOdd_1(Ti).CI_IncomeCalculation = 120 or LstOdd_1(Ti).CI_IncomeCalculation = 100006 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100072 or LstOdd_1(Ti).CI_IncomeCalculation = 100032  or LstOdd_1(Ti).CI_IncomeCalculation =100080 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100101  or LstOdd_1(Ti).CI_IncomeCalculation = 100045  Or LstOdd_1(Ti).CI_IncomeCalculation = 100102 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100103 Or LstOdd_1(Ti).CI_IncomeCalculation = 100104 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100105 Or LstOdd_1(Ti).CI_IncomeCalculation = 100099 Or LstOdd_1(Ti).CI_IncomeCalculation = 100109 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100114 Or LstOdd_1(Ti).CI_IncomeCalculation = 100081 Or LstOdd_1(Ti).CI_IncomeCalculation = 100082 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100053 Or LstOdd_1(Ti).CI_IncomeCalculation = 1301  Or LstOdd_1(Ti).CI_IncomeCalculation = 100201 Or LstOdd_1(Ti).CI_IncomeCalculation = 100202 Then   ChechOdd=1
                        if ChechOdd=0 Then if Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="0" or Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="1" Then  ChechOdd=1 
					Next
					  
					if ChechOdd=0 Then 
						 Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
						 if LstOdd_1(Ti).CI_OddmentType = 2 or LstOdd_1(Ti).CI_OddmentType = 3 or LstOdd_1(Ti).CI_OddmentType = 6 or LstOdd_1(Ti).CI_OddmentType=7  Then
	                     	TmpOne.Price = LstOdd_1(Ti).Value * (-1)
	                     Else
	                     	TmpOne.Price = LstOdd_1(Ti).Value
	                     End if 
	                     if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=152 Then TmpOne.FileNo=2	
						 TmpOne.WrapperAccountNo= LstOdd_1(Ti).CI_IncomeCalculation
						 Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstOdd_1(Ti).CI_IncomeCalculation)
						 If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
	                        TmpOne.AccountNoComments = ""
	                     Else
	                        TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
	                     End If
	                     a +=TmpOne.Price
	                     TmpAccounting_DocDetailsList.Add(TmpOne)
	                End if     
                     
				Next
                '--------------------------------------------'---------------------
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
   
              
                Dim TmpChek As Integer = 0
                

				TmpChek=0

                Dim TakhfifRound As Decimal = 0
                Dim TakhfifRound_1 As Decimal = 0
                Dim TakhfifRound_Cash As Decimal = 0
                Dim i As Integer = 0
                Dim jjjj As Integer = 0
               
                Dim test As Integer = 1
                Dim tmpdate As String = ""


                TakhfifRound_1 = TakhfifRound - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue

                '---------------------------------------------------------------------------
                '-------------------------------------------------------------------------------        
                TakhfifRound = 0

                	
                Dim TTj As Integer = 0
                
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
               ' Info8.AddError(BIZ.SA.EumErrorAction.Stop,BedeHiTmp, "BedeHiTmp")		
                BedeHiTmp=BedeHiTmp+BedahiFAdd
               ' Info8.AddError(BIZ.SA.EumErrorAction.Stop,BedahiFAdd, "BedahiFAdd")	
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = 0
                    'Info8.AddError(BIZ.SA.EumErrorAction.Stop, Convert.ToDecimal(BedeHiTmp), "a" & Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup)	
                    If a <> 0 Then
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal((Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price) * Convert.ToDecimal(BedeHiTmp)) / Convert.ToDecimal(a)),0) ' (Math.Round( (TmpAccounting_DocDetailsList(TTj).Price*BedeHiTmp)/a,2))
                    Else
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price),0)
                    End If
                    
					if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=152 Then TmpDocDetails.FileNo=2	
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                    'TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    			'	if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
    				'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                    'TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    TakhfifRound += TmpDocDetails.Price
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
 

                
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
                If DtoAccounting_DocHeaderTotal.SaraPrice <> TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price) Then
                    Dim gg As Integer = 0
                    Dim PriceTmp As Decimal = 0
                    
                    if TmpAccounting_DocDetailsListTotal.count>0 Then 
	                    For gg = 1 To TmpAccounting_DocDetailsListTotal.count - 1
	                        PriceTmp += TmpAccounting_DocDetailsListTotal(gg).Price
	                    Next
	                 
                    TmpAccounting_DocDetailsListTotal(0).Price = DtoAccounting_DocHeaderTotal.SaraPrice - PriceTmp
					End if   
                End If
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit   	
                		ListRefP.add(Refcenter)
                        
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                RefFund.Value = 120 
		                ListRefP.add(RefFund)
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
		                
		                
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
						
		                Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
                		
                		Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
                		
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               	
		               
		                Mess.ActTyp = 3
		                Mess.DocTyp = 3
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد حواله تقسیط"  
		                Mess.DocTypDsc = "عوارض حواله تقسیط"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                   	 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""
					
                 
                tmpstr = TmpDocument.Save(NidF)
                
                

                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری                               
    Catch ex As Exception
        Info8.AddError(BIZ.SA.EumErrorAction.Stop, "اوراق بهادار", "اشکال در ارسال به رایورز" + ex.Message)
    End Try
End Function
<DisplayName("بدهی قبلی")> Public Function BedeHi(ByVal M_Districk As Integer, ByVal FicheNo As String) As Decimal
   
    Dim Str_Income As String

                
    Dim i As Integer = 0
    If M_Districk <> 80 And M_Districk<> 218  Then
        Str_Income = "64,78,1,8,15,22,29,36,90,91,92,93,94,95,96,97,98,99,100,43,50,71,100,101,105,106,107,108,109,110,111,112,113,114,115,116"
    Else
        Str_Income = "1,7,10"
    End If

    Dim TmpArr() As String
    Dim intList_Income As New list(Of Integer)

    TmpArr = Str_Income.Split(",")
    For i = 0 To TmpArr.Count - 1
        intList_Income.Add(TmpArr(i))
    Next i

    Dim M_AllFiche As List(Of DtoSc.Income_Fiche)


    M_AllFiche = Info8.GetIncome_Fiche.GetAll_Fiche(Guid.Parse(Info8.FindParameter("NidProc")))
    
    M_AllFiche = M_AllFiche.Distinct().Tolist()

    If M_AllFiche.Any Then M_AllFiche = M_AllFiche.Where(Function(f) (f.EumFicheStatus = 7 Or f.EumFicheStatus = 5) And F.ficheno <> FicheNo).ToList()



    If M_AllFiche.Any Then
        M_AllFiche = (From A In M_AllFiche Join B In intList_Income On A.CI_IncomeAccountGroup Equals B Select A).ToList
    End If
    M_AllFiche = M_AllFiche.Distinct().ToList()
	 
	For i=0 to M_AllFiche.count-1 
	    If M_AllFiche(i).PaymentDate = "" Then M_AllFiche(i).PaymentDate = "1394/12/29"
        If M_AllFiche(i).BankPaymentDate = "" Then M_AllFiche(i).BankPaymentDate = "1394/12/12"
	Next
   

    M_AllFiche = M_AllFiche.OrderByDescending(Function(f) f.BankPaymentDate).ToList
    If M_AllFiche.count > 0 Then

        '254442
        If M_AllFiche(0).PaymentDate < "1399/01/01" Or M_AllFiche(0).BankPaymentDate < "1399/01/01" Then

            Return 0
        Else

            LstIncmDet = Info8.GetIncome.GetIncome_Calculation_InNidIncome(M_AllFiche(0).NidIncome)
           
            Return (M_AllFiche(0).Payable-M_AllFiche(0).Brokers)
           
        End If
    End If

End Function
Public Sub Logfile (ByVal N1 As String, ByVal N2 As String)
    Dim tmpFileStream As New System.IO.FileStream("C:\log\" + N1 + ".txt", System.IO.FileMode.Create, System.IO.FileAccess.ReadWrite)
    Dim tmpBinaryWriter As New System.IO.BinaryWriter(tmpFileStream)
    tmpBinaryWriter.Write(N2)
    tmpFileStream.Close()

End Sub

Private sub logfilefj(ByVal A as String,ByVal B as String)
 if  ucase(Info8.User.UserGuid.ToString()) = ucase("ca742134-44bb-4ba6-b0c4-e5e186600a0a") or ucase(Info8.User.UserGuid.tostring)=ucase("6F99C240-C92B-4FB3-99DB-6760750167EB")  Then
 	  Info8.AddError(BIZ.SA.EumErrorAction.warning,A,B) 
   End if
End sub   

<DisplayName(" چک درآمد")> Public Function iNcOMECheck()
    Try
         
		Dim NidF as String 
        Dim TmpChekNo As Integer = 0 '20

        Dim ExistRayvarz As Boolean = Info8.GetFunctions.ExistInRayvarz(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche, CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice))
    '  
        If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup < 90 Then ExistRayvarz = True
	'	if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus=3 Then  ExistRayvarz=True

		ExistRayvarz = False
        If ExistRayvarz = False Then
        
            Try
                Info8.ParameterList.Add("NidProc", Info8.GetFunctions.GetNidProcFromNidFicheIncome(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche).ToString)
            Catch
            End Try
            Info8.ParameterList.Remove("NidIncome")
            Info8.ParameterList.Add("NidIncome", Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome.tostring)
                            
         '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, "D" &  Info8.GetIncome.GetIncome_OddmentAccount.count, Info8.GetFunctions.GetNidProcFromNidFicheIncome(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche).ToString)
			if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus <5 And Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).EumFicheStatus <>3  Then  
				Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه", "فیش تایید نشده است اطلاعات به رایورز ارسال نمیشود")
				Exit Function
			End if	
			if Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate="" And Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).Payable>0 Then 
				Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه", "فیش تایید بانک نشده است اطلاعات به رایورز ارسال نمیشود")
				Exit Function
			ElseIf Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate="" Then
				Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate=	 BIZ.SA.ClsCommon.CurrentShamsiDateString
				Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentDate=	 BIZ.SA.ClsCommon.CurrentShamsiDateString
			End if 
            Dim NidIns As String
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)
 
               Call GetSara8Workflow()			    

                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)
              

                If PtmpDistrict = "051" Then
                    DistrickBranch = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentId.Substring(10, 2)
                    If DistrickBranch > 12 And DistrickBranch <> 80 And DistrickBranch<> 218  Then DistrickBranch = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentId.Substring(10, 1)
                End If
                
				'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "c",Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate)
			'	Info8.AddError(BIZ.SA.EumErrorAction.Stop, "aaa+", Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate)  :  Exit Function 
                if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable>0 Then 
                	if (Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).ExportPermanentDate>"1399/10/22" And Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).ExportPermanentDate<"1399/12/11" ) Then 
                		if  AddDateForHolidays(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).ExportPermanentDate, 10,1) <Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate Then  
							Info8.AddError(BIZ.SA.EumErrorAction.Stop, "اعتبارسنجی+", "با توجه به اینکه فیش نقد خارج از مهلت پرداخت شده است امکان ارسال  اطلاعات تقسیط به سامانه مالی وجود ندارد ")  :  Exit Function 
						End if 	
					Else	
			
			
						
			            if Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).EumFicheStatus=5 Then
			             	    'sp 408382
			             	    
			                    Dim Molat as String=Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).PaymentBreakDate
			                    Dim pardakhtbank as String=Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate
			                   if String.IsNullOrEmpty(Molat)=True Then Molat=AddDateForHolidays(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).ExportPermanentDate, 10,1)
			                    if pardakhtbank > Molat Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "اعتبارسنجی+", "با توجه به اینکه فیش نقد خارج از مهلت پرداخت شده است امکان ارسال  اطلاعات تقسیط به سامانه مالی وجود ندارد ")  :  Exit Function 
						ElseIf GetDiffDate(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).ExportPermanentDate,Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BankPaymentDate,3)>10 Then 
						   Info8.AddError(BIZ.SA.EumErrorAction.Stop, "اعتبارسنجی+", "با توجه به اینکه فیش نقد خارج از مهلت پرداخت شده است امکان ارسال  اطلاعات تقسیط به سامانه مالی وجود ندارد ")  :  Exit Function 
						End if
						
						
						
						
					End if 	
				End if
				

                Select Case PtmpDistrict
                    Case "511"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "512"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
                    Case "513"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if	
                    Case "514"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if	
                    Case "515"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
	                    	DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "516"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "517"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "518"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "519"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "520"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
	                     	DistrickBranch =210
	                     Else
	        				DistrickBranch = 10
		                 End if	
                    Case "521"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "522"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "523"
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select
               
                if  DistrickBranch=0 Then 
               		Select Case PtmpDistrict
                    Case "401"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "402"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "403"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if	
                    Case "404"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if	
                    Case "405"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
	                    	DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "406"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "407"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "408"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "409"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "410"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
	                     	DistrickBranch =210
	                     Else
	        				DistrickBranch = 10
		                 End if	
                    Case "411"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "412"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "400"
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                	End Select
               
               End if 
                
               if  DistrickBranch=0 or Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).Payable=0 Then
               		 PtmpDistrict=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		             PtmpDistrict=RTrim(LTrim(PtmpDistrict))
		  
		             PtmpDistrict=PtmpDistrict.Substring(2,2)
		            
					 
               		Select Case PtmpDistrict
                    Case "01"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case "02"
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case "03"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if	
                    Case "04"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if	
                    Case "05"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
	                    	DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case "06"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case "07"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case "08"
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case "09"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case "10"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
	                     	DistrickBranch =210
	                     Else
	        				DistrickBranch = 10
		                 End if	
                    Case "11"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case "12"
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case "80"
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                	End Select
               
               End if  
               	
               '	Info8.AddError(BIZ.SA.EumErrorAction.Stop, "DistrickBranch", DistrickBranch)
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 
               ' Dim BedeHiTmp As Decimal = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable -  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers
               '  if  ucase(Info8.User.UserGuid.tostring)=ucase("ca742134-44bb-4ba6-b0c4-e5e186600a0a") or ucase(Info8.User.UserGuid.tostring)=ucase("6F99C240-C92B-4FB3-99DB-6760750167EB") Then 
                   Dim BedeHiTmp As Decimal=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
              '  End if

				Dim TmpBrokersNew AS Decimal=0
				TmpBrokersNew=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers
				

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                Dim Ti As Integer
        
                If TmpDT.any() Then
                
       				Ti=0
                    For Ti = 0 To TmpDT.count - 1
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        '    Info8.AddError(BIZ.SA.EumErrorAction.Stop, "TmpDT(Ti).CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                            
                        
                        If TmpInComeCode.ToString = DBNull.Value.ToString or TmpInComeCode.ToString=0 Or TmpDT(Ti).CI_IncomeCalculation = 100036 Or TmpDT(Ti).CI_IncomeCalculation = 100041 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100042 Or TmpDT(Ti).CI_IncomeCalculation = 100043 Or TmpDT(Ti).CI_IncomeCalculation = 100047 Or TmpDT(Ti).CI_IncomeCalculation = 100048 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100049 Or TmpDT(Ti).CI_IncomeCalculation = 100050 Or TmpDT(Ti).CI_IncomeCalculation = 100052 Or TmpDT(Ti).CI_IncomeCalculation = 100028 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100016 Or TmpDT(Ti).CI_IncomeCalculation = 100009 Or TmpDT(Ti).CI_IncomeCalculation = 100002 Or TmpDT(Ti).CI_IncomeCalculation = 1091 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 1101   Or TmpDT(Ti).CI_IncomeCalculation = 100055 Or TmpDT(Ti).CI_IncomeCalculation = 100057 Or TmpDT(Ti).CI_IncomeCalculation = 100061 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100060 Or TmpDT(Ti).CI_IncomeCalculation = 100200 Or TmpDT(Ti).CI_IncomeCalculation =100075 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100067 Or TmpDT(Ti).CI_IncomeCalculation = 100068 Or TmpDT(Ti).CI_IncomeCalculation = 100087 Or TmpDT(Ti).CI_IncomeCalculation =  999999 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 120 or TmpDT(Ti).CI_IncomeCalculation = 100006 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100072 or TmpDT(Ti).CI_IncomeCalculation = 100032 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100080 Or TmpDT(Ti).CI_IncomeCalculation = 100101 Or TmpDT(Ti).CI_IncomeCalculation = 100045 Or TmpDT(Ti).CI_IncomeCalculation = 100102 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100103 Or TmpDT(Ti).CI_IncomeCalculation = 100104 Or TmpDT(Ti).CI_IncomeCalculation = 100029 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100105 Or TmpDT(Ti).CI_IncomeCalculation = 100097 Or TmpDT(Ti).CI_IncomeCalculation = 100098 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100099 Or TmpDT(Ti).CI_IncomeCalculation = 100109 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100114 Or TmpDT(Ti).CI_IncomeCalculation = 100081 Or TmpDT(Ti).CI_IncomeCalculation = 100082 _
                        Or TmpDT(Ti).CI_IncomeCalculation=100053 Or TmpDT(Ti).CI_IncomeCalculation=1301 Or TmpDT(Ti).CI_IncomeCalculation=100202  Then 
                        
                        
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                        
                    		Dim LstOdd As New List(Of Global.DtoSC.Income_OddmentAccount)
                    		
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			               
			                
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 2 or f.CI_OddmentType = 3 or f.CI_OddmentType = 6 or f.CI_OddmentType=7) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price - LstOdd.Sum(Function(f) f.Value)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			               ' Info8.AddError(BIZ.SA.EumErrorAction.Stop, "ttt",LstOdd.count)
			                 
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 8 or f.CI_OddmentType =1 or f.CI_OddmentType = 4) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                ' Info8.AddError(BIZ.SA.EumErrorAction.Stop, "wwwwwww" &  TmpDT(Ti).CI_IncomeCalculation ,LstOdd.count)
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price + LstOdd.Sum(Function(f) f.Value)
			                TmpOne.WrapperAccountNo = IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			               ' if TmpDT(Ti).CI_IncomeCalculation=1102 Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "Teeee",TmpOne.Price)
			                a +=TmpOne.Price
			
                         End If
                        
                         'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "a" & Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation) ,a)      

                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        If TmpOne.WrapperAccountNo <> 0 Then TmpAccounting_DocDetailsList.Add(TmpOne)

                    Next
                End If
                
				Dim LstOdd_1 As New List(Of DtoSC.Income_OddmentAccount)
                LstOdd_1 = Info8.GetIncome.GetIncome_OddmentAccount
                Dim ChechOdd as Integer=0
                Dim Ti_1 as Integer
                
				For Ti=0 to LstOdd_1.count -1
					ChechOdd=0
				
					For Ti_1=0 to TmpAccounting_DocDetailsList.count -1 
						if LstOdd_1(Ti).CI_IncomeCalculation=TmpAccounting_DocDetailsList(Ti_1).WrapperAccountNo Then	ChechOdd=1
						If LstOdd_1(Ti).CI_IncomeCalculation =0 or LstOdd_1(Ti).CI_IncomeCalculation = 100036 Or LstOdd_1(Ti).CI_IncomeCalculation = 100041 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100042 Or LstOdd_1(Ti).CI_IncomeCalculation = 100043 Or LstOdd_1(Ti).CI_IncomeCalculation = 100047 Or LstOdd_1(Ti).CI_IncomeCalculation = 100048 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100049 Or LstOdd_1(Ti).CI_IncomeCalculation = 100050 Or LstOdd_1(Ti).CI_IncomeCalculation = 100052 Or LstOdd_1(Ti).CI_IncomeCalculation = 100028 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100016 Or LstOdd_1(Ti).CI_IncomeCalculation = 100009 Or LstOdd_1(Ti).CI_IncomeCalculation = 100002 Or LstOdd_1(Ti).CI_IncomeCalculation = 1091 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 1101   Or LstOdd_1(Ti).CI_IncomeCalculation = 100055 Or LstOdd_1(Ti).CI_IncomeCalculation = 100057 Or LstOdd_1(Ti).CI_IncomeCalculation = 100061 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100060 Or LstOdd_1(Ti).CI_IncomeCalculation = 100200 Or LstOdd_1(Ti).CI_IncomeCalculation = 100075 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100067 Or LstOdd_1(Ti).CI_IncomeCalculation = 100068 Or LstOdd_1(Ti).CI_IncomeCalculation = 100029 Or LstOdd_1(Ti).CI_IncomeCalculation = 100087 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 999999 Or LstOdd_1(Ti).CI_IncomeCalculation = 120 or LstOdd_1(Ti).CI_IncomeCalculation = 100006 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100072 or LstOdd_1(Ti).CI_IncomeCalculation = 100032 Or LstOdd_1(Ti).CI_IncomeCalculation =100080 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100101 Or LstOdd_1(Ti).CI_IncomeCalculation = 100045 Or LstOdd_1(Ti).CI_IncomeCalculation = 100102 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100103 Or LstOdd_1(Ti).CI_IncomeCalculation = 100104 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100105 Or LstOdd_1(Ti).CI_IncomeCalculation = 100097 Or LstOdd_1(Ti).CI_IncomeCalculation = 100098 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100099 Or LstOdd_1(Ti).CI_IncomeCalculation = 100109 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100114 Or LstOdd_1(Ti).CI_IncomeCalculation = 100081 Or LstOdd_1(Ti).CI_IncomeCalculation = 100082 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100053 Or LstOdd_1(Ti).CI_IncomeCalculation = 1301  Or LstOdd_1(Ti).CI_IncomeCalculation = 100201 Or LstOdd_1(Ti).CI_IncomeCalculation = 100202  Then    ChechOdd=1
                        if ChechOdd =0 Then if Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="0" or Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="1" Then  ChechOdd=1 
					Next
					
'	Info8.AddError(BIZ.SA.EumErrorAction.Stop, "bbbb"  ,a)  
					if ChechOdd=0 Then 
						  Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
						 if LstOdd_1(Ti).CI_OddmentType = 2 or LstOdd_1(Ti).CI_OddmentType = 3 or LstOdd_1(Ti).CI_OddmentType = 6 or LstOdd_1(Ti).CI_OddmentType=7  Then
	                     	TmpOne.Price = LstOdd_1(Ti).Value * (-1)
	                     Else
	                     	TmpOne.Price = LstOdd_1(Ti).Value
	                     End if 	
						 TmpOne.WrapperAccountNo= LstOdd_1(Ti).CI_IncomeCalculation
						 Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstOdd_1(Ti).CI_IncomeCalculation)
						 If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
	                        TmpOne.AccountNoComments = ""
	                     Else
	                        TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
	                     End If
	                     a +=TmpOne.Price
	                     TmpAccounting_DocDetailsList.Add(TmpOne)
	                End if     
                    ' Info8.AddError(BIZ.SA.EumErrorAction.Stop, "aaaaa" & Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation) ,a)      
				Next
                '--------------------------------------------'---------------------
                '--------------------------------------------'---------------------
                 
                Dim TmpDocument As New BIZ.Communication.ClsAccounting

                Info8.GetInstallment().LoadObj(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidFiche, Info8.GetAccountingDocCreateParameter.ObjOnPrice)

                Dim TmpChek As Integer = 0
                Dim Tm As Decimal = convert.todecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue)
				Dim TmpLstOfInstal As New List(Of Global.DtoSC.Installment_List)
            	TmpLstOfInstal = Info8.GetInstallment().Installment_List
            	TmpLstOfInstal = TmpLstOfInstal.Where(Function(f) f.CI_InstallmentStatus <19  ).ToList
				Dim TmpBrokers As Decimal =0
				Dim TmpNerkhe As Decimal =0
				Dim lstf As New List(Of Global.DtoSC.Income_FicheSub)
				lstf = Info8.GetIncome.GetFiche.GetIncomeFicheSub(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).nidfiche)
				if lstf.count>0 Then lstf= lstf.where(Function (f) f.CI_IncomeFormulaFiche=10 ).tolist
				if lstf.count>0 Then TmpNerkhe=lstf.sum(Function (f) f.price)
			'	if  ucase(Info8.User.UserGuid.tostring)<>ucase("ca742134-44bb-4ba6-b0c4-e5e186600a0a") And ucase(Info8.User.UserGuid.tostring)<>ucase("6F99C240-C92B-4FB3-99DB-6760750167EB") Then 
			'	if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers>0 And TmpLstOfInstal.count>0 Then 
				'	TmpBrokers=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Math.Round (Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers/TmpLstOfInstal.count)
			'	End if	
'End if
                If Tm > 0 Then TmpChek = Info8.GetInstallment().Installment_List.Count

				NidF=Info8.GetInstallment.Installment.NidInstallment.tostring
                Dim TakhfifRound As Decimal = 0
                Dim TakhfifRound_1 As Decimal = 0
                Dim TakhfifRound_Cash As Decimal = 0
                Dim i As Integer = 0
                Dim jjjj As Integer = 0
                Dim Tj As Integer = 0
                Dim test As Integer = 1
                Dim tmpdate As String = ""
 
                If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                Else
                    tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                End If
                
                Dim kk As Integer = 0
                Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                Dim lstW As New List(Of DtoSC.Installment_List)
                lstW=Info8.GetInstallment().Installment_List
			    lstW=lstW.OrderByDescending(Function(f) f.ChequeSheetDate).tolist
			    Info8.GetInstallment().Installment_List=lstW
			   
                If TmpChek > 0 Then

                    For kk = 0 To TmpChek - 1
                    TakhfifRound=0
                        Next_of_for: 
						if Info8.GetInstallment().Installment_List(kk).CI_InstallmentStatus >18 Then 
						Else
						
	                    	if Info8.GetInstallment().Installment_List(kk).EndStateCode = 0 Then ' 1396/03/07
	                    		Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه * ", "وضعیت چک ها نامشخص است اطلاعات به رایورز ارسال نمیشود*")
								Exit Function		
	                    	End if
	                    End if	
                    	if Info8.GetInstallment().Installment_List(kk).MoadiCode = "0" Then ' 1396/03/07
                    		Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه * ", "کد مودی مشخص نمی باشد")
							Exit Function		
                    	End if 
                    
                        if Info8.GetInstallment().Installment_List(kk).CI_InstallmentStatus >18 Then
	                        kk+=1
	                       
	                        if kk<TmpChek 
	                        	GoTo Next_of_for
	                        Else
	                        	Exit For 
	                        	
	                        End if	
                        End if  

                        Dim TmpAccounting_DocDetailsListAdd As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                        Dim DtoAccounting_DocHeader As New Biz.Communication.DataAccess.Accounting_DocHeader
                        Dim TmpAcc As New Biz.Communication.ClsAccountingDocMessage
						jjjj=0
						 
						Dim TmpP As Decimal = convert.toDecimal(Info8.GetInstallment().Installment_List(kk).PaymentCost)
				
						TmpP=TmpP-TmpBrokers-TmpNerkhe
					 	
                        For Tj = 0 To TmpAccounting_DocDetailsList.count - 1
                        
							                 	
                            Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                            TmpDocDetails.Price = 0
                            TmpDocDetails.Price = TmpAccounting_DocDetailsList(Tj).Price
                            Dim Tmp As Decimal =Math.Max(convert.toDecimal(Info8.GetInstallment().Installment_List(kk).PaymentCost)-TmpBrokers-TmpNerkhe,0)
                        '	Info8.AddError(BIZ.SA.EumErrorAction.Stop, "Insret "  & convert.toDecimal(Tmp),  TmpDocDetails.Price)
                        	
                           if Tmp<0 Then Tmp=0
                        	If a <> 0 Then
                        
		                        TmpDocDetails.Price = Math.Round( convert.toDecimal(Math.Round((convert.toDecimal(TmpDocDetails.Price) * convert.toDecimal(Tmp))/ convert.toDecimal(a), 2)),0) ' convert.toDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).IncomeValue), 2)),0)
		                    Else
		                        TmpDocDetails.Price =0 ' Math.Round(Convert.ToDecimal(TmpDocDetails.Price),0)
		                    End If
                            
                            
                            ' 
                            TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(Tj).WrapperAccountNo
                            TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(Tj).AccountNoComments
                            TmpDocDetails.FicheNo = Info8.GetInstallment().Installment_List(kk).NoDocument
							'if TmpDocDetails.Price >0 Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "Insret "  & TmpDocDetails.AccountNoComments ,  TmpDocDetails.Price)
                            TmpDocDetails.BillID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
                            TmpDocDetails.PaymentID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
                           
                           ' if TmpDocDetails.WrapperAccountNo=100094 Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "convert.toDecimal(Tmp)" & convert.toDecimal(Tmp) &  "#### "  & TmpAccounting_DocDetailsList(Tj).AccountNoComments,"convert.toDecimal(TmpDocDetails.Price)"  & convert.toDecimal(a) & "&&&" & TmpDocDetails.Price)      
                          ' Info8.AddError(BIZ.SA.EumErrorAction.Stop, "vvv",CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) )
                            
     						TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                          	if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     						TmpChekNo= CStr(TmpDocDetails.BankCode)
    						'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                           ' TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)


                            TmpDocDetails.PaymentDate = ChangeDate(Info8.GetInstallment().Installment_List(kk).PaymentDate)
                            TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
                            

                            
							If TmpDocDetails.Price <> 0 Then
                                jjjj += 1
                                TmpDocDetails.IncmRow = jjjj
                               
                                Dim M_Tmp As Decimal=TmpP
                               '  if TmpDocDetails.Price >0 Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "TmpP  "  & TmpP , TmpDocDetails.Price)
                                '  if TmpDocDetails.WrapperAccountNo=100094 Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "TmpP" & TmpP ,"TmpDocDetails.Price" & TmpDocDetails.Price)      
                              'aa  TmpP-=TmpDocDetails.Price
                               
                             'aa  if TmpP<10 Then '0 And Tj= TmpAccounting_DocDetailsList.count - 1
                                 
                                '	if M_Tmp<0 Then M_Tmp=0
                                '	TmpP=TmpP-M_Tmp+TmpDocDetails.Price  
                                '	TmpDocDetails.Price=M_Tmp
                                	
                               ' Else
                               
                            'aa    	TmpDocDetails.Price=convert.toDecimal(TmpP)+ TmpDocDetails.Price  'Math.Min(convert.toDecimal(TmpP),convert.toDecimal(TmpDocDetails.Price))
                                	
                               ' ElseIf TmpP>0 And TmpP<100 Then TmpDocDetails.Price=convert.toDecimal(TmpP)+ TmpDocDetails.Price	
                          'aa      End if	
                                TakhfifRound += TmpDocDetails.Price
                              ' if TmpDocDetails.Price >0 Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "Insret befor  "  & TmpDocDetails.AccountNoComments ,  TmpDocDetails.Price)
                               ' TmpDocDetails.Price=Math.Max(0,convert.toDecimal(TmpDocDetails.Price))
                                TmpAccounting_DocDetailsListAdd.Add(TmpDocDetails)
                           End If
                        Next
				if TmpAccounting_DocDetailsListAdd.count>0 Then
                       if TmpP <> TmpAccounting_DocDetailsListAdd.Sum(Function (f) f.Price ) Then 
                       		TmpAccounting_DocDetailsListAdd(0).price = TmpAccounting_DocDetailsListAdd(0).price +(TmpP-TmpAccounting_DocDetailsListAdd.Sum(Function (f) f.Price ))
                       End if   
				End if 

'''''''''''''''''''''''''''''''
		
		   
			Dim TmpDocDetails_Kar as New BIZ.Communication.DataAccess.Accounting_DocDetails
            TmpDocDetails_Kar.Price = 0
            TmpDocDetails_Kar.Price = Math.MIn(convert.toDecimal(Info8.GetInstallment().Installment_List(kk).PaymentCost),TmpBrokers)      
           
            TmpDocDetails_Kar.WrapperAccountNo = "110171"
            TmpDocDetails_Kar.AccountNoComments = "کارگزاری"
            TmpDocDetails_Kar.FicheNo = Info8.GetInstallment().Installment_List(kk).NoDocument
			TmpDocDetails_Kar.BillID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
            TmpDocDetails_Kar.PaymentID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
           ' TmpDocDetails_Kar.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
           ' TmpDocDetails_Kar.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
            TmpDocDetails_Kar.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
            if CStr(TmpDocDetails_Kar.BankCode)=""  Then  TmpDocDetails_Kar.BankCode= 18
     		
    		'if TmpDocDetails_Kar.BankCode="" or TmpDocDetails_Kar.BankCode is Nothing Then  TmpDocDetails_Kar.BankCode= 18
     	'	TmpChekNo= TmpDocDetails.BankCode
    		'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
	
			TmpDocDetails_Kar.PaymentDate = ChangeDate(Info8.GetInstallment().Installment_List(kk).PaymentDate)
            TmpDocDetails_Kar.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
           'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "TmpDocDetails_Kar.Price"   ,  TmpDocDetails_Kar.Price)
            If TmpDocDetails_Kar.Price <> 0 Then
            	 jjjj += 1
                 TmpDocDetails_Kar.IncmRow = jjjj
                
                 '204259TmpBrokersNew-=TmpDocDetails_Kar.Price
                '204259 if TmpBrokersNew<100 Then   	TmpDocDetails_Kar.Price=convert.toDecimal(TmpBrokersNew)+ TmpDocDetails_Kar.Price  'Math.Min(convert.toDecimal(TmpP),convert.toDecimal(TmpDocDetails.Price))
                 TmpAccounting_DocDetailsListAdd.Add(TmpDocDetails_Kar)
             End If
				
			''''''''''''''''''''''''''''''''''''''
		  '  TmpAccounting_DocDetailsListAdd(0).Price + = convert.toDecimal(Info8.GetInstallment().Installment_List(kk).PaymentCost) - TakhfifRound -TmpDocDetails_Kar.Price 

			  
			
           ' TmpAccounting_DocDetailsListAdd(0).Price + = convert.toDecimal(Info8.GetInstallment().Installment_List(kk).PaymentCost) - TakhfifRound -TmpDocDetails_Nerkh.Price 

                           
		
''''''''''''''''''''''''''''''' نرخ
		
		   
			Dim TmpDocDetails_Nerkh as New BIZ.Communication.DataAccess.Accounting_DocDetails
            TmpDocDetails_Nerkh.Price = 0
            							
            TmpDocDetails_Nerkh.Price = Math.MIn(Math.Max(convert.toDecimal(Info8.GetInstallment().Installment_List(kk).PaymentCost)-convert.toDecimal(TmpDocDetails_Kar.Price),0),TmpNerkhe)      
           
            TmpDocDetails_Nerkh.WrapperAccountNo = "100063"
            TmpDocDetails_Nerkh.AccountNoComments = "درامد حاصل از اجرای ماده 59 قانون رفع موانع تولید"
            TmpDocDetails_Nerkh.FicheNo = Info8.GetInstallment().Installment_List(kk).NoDocument
			TmpDocDetails_Nerkh.BillID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
            TmpDocDetails_Nerkh.PaymentID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
           ' TmpDocDetails_Nerkh.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
            'TmpDocDetails_Nerkh.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
            TmpDocDetails_Nerkh.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
            if CStr(TmpDocDetails_Nerkh.BankCode)=""  Then  TmpDocDetails_Nerkh.BankCode= 18
     		
    	'	if TmpDocDetails_Nerkh.BankCode="" or TmpDocDetails_Nerkh.BankCode is Nothing Then  TmpDocDetails_Nerkh.BankCode= 18
     	'	TmpChekNo= TmpDocDetails.BankCode
    		'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
		
			TmpDocDetails_Nerkh.PaymentDate = ChangeDate(Info8.GetInstallment().Installment_List(kk).PaymentDate)
            TmpDocDetails_Nerkh.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
           'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "TmpDocDetails_Kar.Price"   ,  TmpDocDetails_Kar.Price)
            If TmpDocDetails_Nerkh.Price <> 0 Then
            	 jjjj += 1
                 TmpDocDetails_Nerkh.IncmRow = jjjj
                
                 '204259TmpBrokersNew-=TmpDocDetails_Kar.Price
                '204259 if TmpBrokersNew<100 Then   	TmpDocDetails_Kar.Price=convert.toDecimal(TmpBrokersNew)+ TmpDocDetails_Kar.Price  'Math.Min(convert.toDecimal(TmpP),convert.toDecimal(TmpDocDetails.Price))
                 TmpAccounting_DocDetailsListAdd.Add(TmpDocDetails_Nerkh)
             End If
				
			''''''''''''''''''''''''''''''''''''''		
			TmpNerkhe =Math.Max(TmpNerkhe -convert.toDecimal(TmpDocDetails_Nerkh.Price),0)     	
	        TmpBrokers=Math.Max(TmpBrokers-convert.toDecimal(TmpDocDetails_Kar.Price),0)   
		
			  ''''Math.Max(TmpBrokers-convert.toDecimal(Info8.GetInstallment().Installment_List(kk).PaymentCost),0)      
             
             
                        DtoAccounting_DocHeader.DocRow = kk + 1
                        DtoAccounting_DocHeader.SaraPrice = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                        DtoAccounting_DocHeader.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                        DtoAccounting_DocHeader.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                        DtoAccounting_DocHeader.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                        DtoAccounting_DocHeader.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                        DtoAccounting_DocHeader.PhasType = 4
                        
                        DtoAccounting_DocHeader.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                        DtoAccounting_DocHeader.FicheNo = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                        
                        
                        NidIns = Info8.GetInstallment().Installment_List(kk).NidInstallment.tostring
                        TmpAcc.Accounting_DocHeader = DtoAccounting_DocHeader

                        TmpAcc.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                        TmpAcc.Accounting_DocDetailList = TmpAccounting_DocDetailsListAdd
                        
                        ''''''''''''''''''New 
                        
                        
		                Dim ListRefPChek As New List(Of BIZ.Communication.RefParameetrs)
		                
		                Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefOwnrDsc"
                		Try
                		Dim tmp as String=""
                		tmp=iif(String.IsNullOrEmpty(Info8.GetInstallment().Installment_List(kk).Letter)," ",Info8.GetInstallment().Installment_List(kk).Letter).ToString +"/" + iif(String.IsNullOrEmpty(Info8.GetInstallment().Installment_List(kk).Series),".",Info8.GetInstallment().Installment_List(kk).Series).ToString +"/" + iif(String.IsNullOrEmpty(Info8.GetInstallment().Installment_List(kk).Serial),".",Info8.GetInstallment().Installment_List(kk).Serial).ToString 
                	
                		RefRDD.Value =tmp
                
		                Catch  ex As Exception
		                	Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه #*", "اطلاعات حرف و سری و سریال صحیح نمی باشد" &  ex.Message )
		                	Exit Function
		                End Try
                		' Info8.GetInstallment().Installment_List(kk).NoDocument  '99845 TmpDate
                		ListRefPChek.add(RefRDD)
		                
		                Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = Info8.GetInstallment().Installment_List(kk).MoadiCode   '99436 TmpDate
                		ListRefPChek.add(Refcenter)
		                
		                Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = ""'Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefPChek.add(RefNo)
                			
                		Dim RefPChek As New BIZ.Communication.RefParameetrs
		                RefPChek.Name = "DocDate"
		                RefPChek.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefPChek.add(RefPChek)
		
		                Dim RefPRChek As New BIZ.Communication.RefParameetrs
		                RefPRChek.Name = "RowDate"
		                RefPRChek.Value = ChangeDate(Info8.GetInstallment().Installment_List(kk).PaymentDate)
		                ListRefPChek.add(RefPRChek)
		
		                Dim RefPRDChek As New BIZ.Communication.RefParameetrs
		                RefPRDChek.Name = "RowDocNo"
		               '193559 Dim CodeWD as String=""
		              '193559  Dim TCodeD() as String = Info8.GetInstallment().Installment_List(kk).NoDocument.Split("/")
		              '193559  Dim ttD as Integer
		              '193559  For ttD=0 to TCodeD.count-1
		              '193559  	CodeWD=CodeWD+TCodeD(ttD).tostring 
		              '193559  Next
		                if isdbnull(Info8.GetInstallment().Installment_List(kk).TrackingNo) Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه", "اطلاعات کد پیگیری صحیح نمیباشد ") : Exit Function
		                if Info8.GetInstallment().Installment_List(kk).TrackingNo.tostring="" Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه", "اطلاعات کد پیگیری صحیح نمیباشد ") : Exit Function
		                RefPRDChek.Value = Info8.GetInstallment().Installment_List(kk).TrackingNo '193559 CodeWD
		              '  RefPRDChek.Value =  Info8.GetInstallment().Installment_List(kk).NoDocument 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		               
		                ListRefPChek.add(RefPRDChek)

		                Dim RefFundChek As New BIZ.Communication.RefParameetrs
		                RefFundChek.Name = "Fund"
		                If TmpChekNo = 1 Then
		                    '153818
		                	if DistrickBranch = 201 Then
		                		RefFundChek.Value = 200201009 
		                	ElseIf DistrickBranch = 202 Then
		                		RefFundChek.Value = 200202007 
		                	ElseIf DistrickBranch = 203 Then
		                		RefFundChek.Value = 200203009
		                	ElseIf DistrickBranch = 204 Then
		                		RefFundChek.Value = 200204005 	 	
		                	ElseIf DistrickBranch = 205 Then
		                		RefFundChek.Value = 200205004   	   		 	
		                	ElseIf DistrickBranch = 206 Then
		                		RefFundChek.Value = 256222008
		                	ElseIf DistrickBranch = 207 Then
		                		RefFundChek.Value = 200207006 
		                 	ElseIf DistrickBranch = 208 Then
		                 		RefFundChek.Value = 200208007
		                 	ElseIf DistrickBranch = 209 Then
                 				RefFundChek.Value = 200209004 
                 			ElseIf DistrickBranch = 210 Then
                 				RefFundChek.Value = 200210005 
                 			ElseIf DistrickBranch = 211 Then
                 				RefFundChek.Value = 200211004
                 			ElseIf DistrickBranch = 212 Then
                 				RefFundChek.Value = 200212004 		 		 		 		  	   		   		 	
		                	Else
		                    	RefFundChek.Value = 1200
		                    End if 	
		                Else
		                	if DistrickBranch = 201 Then
		                		RefFundChek.Value = 200201012 
		                	ElseIf DistrickBranch = 202 Then
		                		RefFundChek.Value = 200202012 
		                	ElseIf DistrickBranch = 203 Then
		                		RefFundChek.Value = 200203013 
		                	ElseIf DistrickBranch = 204 Then
		                		RefFundChek.Value = 200204017 
		                	ElseIf DistrickBranch = 205 Then
		                		RefFundChek.Value = 200205008 
		                	ElseIf DistrickBranch = 206 Then
		                		RefFundChek.Value = 200206006 
		                	ElseIf DistrickBranch = 207 Then
		                		RefFundChek.Value = 200207009
		                 	ElseIf DistrickBranch = 208 Then
		                 		RefFundChek.Value = 200208010 
		                 	ElseIf DistrickBranch = 209 Then
                				RefFundChek.Value = 200209008
                			ElseIf DistrickBranch = 210 Then
                				RefFundChek.Value = 200210020
                			ElseIf DistrickBranch = 211 Then
                 				RefFundChek.Value = 200211007
                 			ElseIf DistrickBranch = 212 Then
                 				RefFundChek.Value = 212210016 
                 			ElseIf DistrickBranch = 218 Then
                				RefFundChek.Value = 200218011			 					 		 		 				 		
		                	Else
		                    	RefFundChek.Value = 1300
		                    End if 	
		                End If
		                
		                ListRefPChek.add(RefFundChek)
						
				'''''''''''''rrr
				Dim RefPR2Chekr As New BIZ.Communication.RefParameetrs
		                RefPR2Chekr.Name = "Ref"
		                RefPR2Chekr.Value =  Info8.GetInstallment().Installment_List(kk).TrackingNo  ' Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefPChek.add(RefPR2Chekr)
				'''''''''''''rrr
						
							Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
			                Refvchrtyp.Name = "vchrtyp"
			                Refvchrtyp.Value = 0
			                ListRefPChek.add(Refvchrtyp)
			                
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "Due"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefPChek.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefPChek.add(RefQTY) 	
							
		                Dim RefPR2Chek As New BIZ.Communication.RefParameetrs
		                RefPR2Chek.Name = "Ref2"
		                RefPR2Chek.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefPChek.add(RefPR2Chek)
		                Dim RefPR3Chek As New BIZ.Communication.RefParameetrs
		                RefPR3Chek.Name = "Ref3"
		                RefPR3Chek.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefPChek.add(RefPR3Chek)
		
		                Dim RefP6Chek As New BIZ.Communication.RefParameetrs
		                RefP6Chek.Name = "Ref6"
		                RefP6Chek.Value = NidIns
		                ListRefPChek.add(RefP6Chek)
		               
		                 Dim RefownrDscChek As New BIZ.Communication.RefParameetrs
		                RefownrDscChek.Name = "RefownrDsc"
		               Try
		               	Dim tmp as String=""
                		tmp=iif(String.IsNullOrEmpty(Info8.GetInstallment().Installment_List(kk).Letter)," ",Info8.GetInstallment().Installment_List(kk).Letter).ToString +"/" + iif(String.IsNullOrEmpty(Info8.GetInstallment().Installment_List(kk).Series),".",Info8.GetInstallment().Installment_List(kk).Series).ToString +"/" + iif(String.IsNullOrEmpty(Info8.GetInstallment().Installment_List(kk).Serial),".",Info8.GetInstallment().Installment_List(kk).Serial).ToString 
                	
		                RefownrDscChek.Value = tmp 
		                Catch
		                	Info8.AddError(BIZ.SA.EumErrorAction.Stop, " & توجه", "اطلاعات حرف و سری و سریال صحیح نمی باشد")
		                	Exit Function
		                End Try
		                ListRefPChek.add(RefownrDscChek)
		                
		
		                Dim MessChek As New BIZ.Communication.ClsRayvarzMessageContract
		
		                MessChek.RefParameterList = ListRefPChek
		              
		                
		                MessChek.District = DistrickBranch
		                	               
		                MessChek.ActTyp = 3
		                MessChek.DocTyp = 3
		                MessChek.IncmMkrTyp = 1
		                MessChek.docdsc="اسناد شهرسازی"  
		                MessChek.DocTypDsc = "عوارض سرا"
		                MessChek.vchrtyp=0
                        TmpAcc.RayvarzMessage =MessChek
                        '''''''''''''''''''''''''
                        
                        ListAcc.Add(TmpAcc)
                        i = i + 1

                    Next
                    

if 1=1 Then

''''''''''''''''''''''''''''''''''''   چک ضمانت و خوشحسابی



Dim LstInstallment As List(Of Global.DtoSC.Installment_List)
LstInstallment=Info8.GetInstallment().Installment_List
LstInstallment=LstInstallment.where(Function(f) f.CI_InstallmentStatus=19 or f.CI_InstallmentStatus=20).tolist
Dim TmpDocRow as Integer=TmpChek

'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "LstInstallment.count", LstInstallment.count )
kk=0

 					For kk = 0 To LstInstallment.count - 1

                        Dim TmpAccounting_DocDetailsListAdd_new As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                        Dim DtoAccounting_DocHeader_new As New Biz.Communication.DataAccess.Accounting_DocHeader
                        Dim TmpAcc_new As New Biz.Communication.ClsAccountingDocMessage
						jjjj=0
					
					

                        

                            Dim TmpDocDetails_New As New BIZ.Communication.DataAccess.Accounting_DocDetails
                            TmpDocDetails_New.Price = convert.toDecimal(LstInstallment(kk).PaymentCost)
                          
                                                    
                          if LstInstallment(kk).CI_InstallmentStatus=19   
                            TmpDocDetails_New.WrapperAccountNo = "911010070"  '237105 "911010980 " '"1001"
                            TmpDocDetails_New.AccountNoComments = "چک خوش حسابی"
                          Else   
                            TmpDocDetails_New.WrapperAccountNo = "911010980"  '237105 "911010980 " '"1001"
                            TmpDocDetails_New.AccountNoComments = "چک تضمین"
                          End if  
                            TmpDocDetails_New.FicheNo = LstInstallment(kk).NoDocument
							
                            TmpDocDetails_New.BillID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
                            TmpDocDetails_New.PaymentID = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
                           ' TmpDocDetails_New.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                           
                           ' TmpDocDetails_New.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
                            TmpDocDetails_New.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                          	if CStr(TmpDocDetails_New.BankCode)=""  Then  TmpDocDetails_New.BankCode= 18
     		
                          
    					'	if TmpDocDetails_New.BankCode="" or TmpDocDetails_New.BankCode is Nothing Then  TmpDocDetails_New.BankCode= 18
     						'	TmpChekNo= TmpDocDetails.BankCode
    						'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
		
                            TmpDocDetails_New.PaymentDate = ChangeDate(LstInstallment(kk).PaymentDate)
                       
                            TmpDocDetails_New.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
                         
                            TmpDocDetails_New.IncmRow = 1   
                        	TmpAccounting_DocDetailsListAdd_new.Add(TmpDocDetails_New)
                          
                        
                        DtoAccounting_DocHeader_new.DocRow =TmpChek+ kk + 1
                        DtoAccounting_DocHeader_new.SaraPrice = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                        DtoAccounting_DocHeader_new.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                        DtoAccounting_DocHeader_new.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                        DtoAccounting_DocHeader_new.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                        DtoAccounting_DocHeader_new.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                        DtoAccounting_DocHeader_new.PhasType = 12
                        DtoAccounting_DocHeader_new.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                        DtoAccounting_DocHeader_new.FicheNo = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                        
                        TmpAcc_new.Accounting_DocHeader = DtoAccounting_DocHeader_new

                        TmpAcc_new.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                        TmpAcc_new.Accounting_DocDetailList = TmpAccounting_DocDetailsListAdd_New
                        
                        ''''''''''''''''''New 
                        
                        
		                Dim ListRefPChek_new As New List(Of BIZ.Communication.RefParameetrs)
		                
		                Dim RefRDD_new As New BIZ.Communication.RefParameetrs
                		RefRDD_new.Name = "RefOwnrDsc"
                		Try
                		 Dim tmp as String=""
                		tmp=iif(String.IsNullOrEmpty(LstInstallment(kk).Letter)," ",LstInstallment(kk).Letter).ToString +"/" + iif(String.IsNullOrEmpty(LstInstallment(kk).Series),".",LstInstallment(kk).Series).ToString +"/" + iif(String.IsNullOrEmpty(LstInstallment(kk).Serial),".",LstInstallment(kk).Serial).ToString 
                	
                		RefRDD_new.Value =tmp
                	
		                Catch
		                	Info8.AddError(BIZ.SA.EumErrorAction.Stop, " $ توجه", "اطلاعات حرف و سری و سریال صحیح نمی باشد")
		                	Exit Function
		                End Try
                		' Info8.GetInstallment().Installment_List(kk).NoDocument  '99845 TmpDate
                		ListRefPChek_new.add(RefRDD_new)
		                
		                Dim Refcenter_new As New BIZ.Communication.RefParameetrs
                		Refcenter_new.Name = "Center1"
                		Refcenter_new.Value = LstInstallment(kk).MoadiCode   '99436 TmpDate
                		ListRefPChek_new.add(Refcenter_new)
		                
		                Dim RefNo_new As New BIZ.Communication.RefParameetrs
                		RefNo_new.Name = "RefReconstructionNo"
                		RefNo_new.Value = ""'Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefPChek_new.add(RefNo_new)
                		
                		Dim RefPChek_new As New BIZ.Communication.RefParameetrs
		                RefPChek_new.Name = "DocDate"
		                RefPChek_new.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefPChek_new.add(RefPChek_new)
		
		                Dim RefPRChek_new As New BIZ.Communication.RefParameetrs
		                RefPRChek_new.Name = "RowDate"
		                RefPRChek_new.Value = ChangeDate(LstInstallment(kk).PaymentDate)
		                ListRefPChek_new.add(RefPRChek_new)
		
		                Dim RefPRDChek_new As New BIZ.Communication.RefParameetrs
		                RefPRDChek_new.Name = "RowDocNo"
		               '193559 Dim CodeWD as String=""
		              '193559  Dim TCodeD() as String = Info8.GetInstallment().Installment_List(kk).NoDocument.Split("/")
		              '193559  Dim ttD as Integer
		              '193559  For ttD=0 to TCodeD.count-1
		              '193559  	CodeWD=CodeWD+TCodeD(ttD).tostring 
		              '193559  Next
		              if isdbnull(LstInstallment(kk).TrackingNo) Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه", "اطلاعات کد پیگیری صحیح نمیباشد ") : Exit Function
		              if LstInstallment(kk).TrackingNo.tostring="" Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "توجه", "اطلاعات کد پیگیری صحیح نمیباشد ") : Exit Function

		                RefPRDChek_new.Value = LstInstallment(kk).TrackingNo '193559 CodeWD
		              '  RefPRDChek.Value =  Info8.GetInstallment().Installment_List(kk).NoDocument 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		               
		                ListRefPChek_new.add(RefPRDChek_new)
			
		                Dim RefFundChek_new As New BIZ.Communication.RefParameetrs
		                RefFundChek_new.Name = "Fund"
		                RefFundChek_new.Value = 120 
		                  
		                ListRefPChek_new.add(RefFundChek_new)
	
				'''''''''''''rrr
				Dim RefPR2Chekr_new As New BIZ.Communication.RefParameetrs
		                RefPR2Chekr_new.Name = "Ref"
		                RefPR2Chekr_new.Value =  LstInstallment(kk).NoDocument 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno
		                ListRefPChek_new.add(RefPR2Chekr_new)
				'''''''''''''rrr
				
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefPChek_new.add(Refvchrtyp)
				
				
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "Due"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefPChek_new.add(RefDUE)
                		
                		Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefPChek_new.add(RefQTY)
                		
		                Dim RefPR2Chek_new As New BIZ.Communication.RefParameetrs
		                RefPR2Chek_new.Name = "Ref2"
		                RefPR2Chek_new.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefPChek_new.add(RefPR2Chek_new)
		                Dim RefPR3Chek_new As New BIZ.Communication.RefParameetrs
		                RefPR3Chek_new.Name = "Ref3"
		                RefPR3Chek_new.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefPChek_new.add(RefPR3Chek_new)
		
		                Dim RefP6Chek_new As New BIZ.Communication.RefParameetrs
		                RefP6Chek_new.Name = "Ref6"
		                RefP6Chek_new.Value = NidIns
		                ListRefPChek_new.add(RefP6Chek_new)
		               
		                Dim MessChek_new As New BIZ.Communication.ClsRayvarzMessageContract
		
		                MessChek_new.RefParameterList = ListRefPChek_new
		                
		                MessChek_new.District = DistrickBranch
		                	               
		                MessChek_new.ActTyp = 3
		                MessChek_new.DocTyp = 3
		                MessChek_new.IncmMkrTyp = 1
		                MessChek_new.docdsc="اسناد شهرسازی"  
		                MessChek_new.DocTypDsc = "عوارض سرا"
		                MessChek_new.vchrtyp=0
                        TmpAcc_new.RayvarzMessage =MessChek_new
                        '''''''''''''''''''''''''
                       
                        ListAcc.Add(TmpAcc_new)
                        i = i + 1


Next
End if
'''''''''''''''''''''''''''''''''''' چک ضمانت و خوش حسابی
	
                    Dim kkk As Integer = 0
                    For kkk = 0 To TmpChek - 1
                        TakhfifRound_Cash += Info8.GetInstallment().Installment_List(kkk).PaymentCost
                    Next
                   
                End If

                TakhfifRound_1 = TakhfifRound - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue

                '---------------------------------------------------------------------------
                '-------------------------------------------------------------------------------        
                TakhfifRound = 0

                Dim yy As Integer = 1
                Dim TTj As Integer = 0
                Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc

                Dim tmpstr As String = ""

          ' Info8.AddError(BIZ.SA.EumErrorAction.Stop, "A11",  ListAcc(0).WrapperAccountNo)
		                '	Exit Function
              
            
                tmpstr = TmpDocument.Save(NidIns)
            
               		
               If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            
        End If '  عدم تکراری                               
    Catch ex As Exception
        Info8.AddError(BIZ.SA.EumErrorAction.Stop, "Tچک توجه TT", "اشکال در ارسال به رایورز" + ex.Message)
    End Try
End Function


Function ChangeDate (ByVal D1 As String) as Integer
    
    Dim d As String = D1
    Dim dd As String
   dd = Left(d, 4)
   dd = dd + d.Substring(5, 2)
   dd = dd + d.Substring(8, 2)
   
   Dim TmpD As String
   TmpD = dd
  
   Return TmpD
End Function

Private Function GetSara8Workflow ()
Try 

	    
	Select Case Ucase(Info8.GetFunctions.GetNidProcFromNidFicheIncome(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche).ToString)
 
		Case "53379B94-1411-4DC8-AEE1-012D4A9B43A7","C28A7410-B48A-4199-BA3A-B5254A20C1F5"     'آماده سازي	
			
			M_ShahrsaziArchiveGroup=2
			
		Case "1BEA53F3-426C-4423-AF29-1FCD2AE1AA62" ,"2518B6D1-54BB-4C94-BEAC-2BA4D19BB100","5AEC0F88-6381-41F3-A5B6-636C8941886E","36D59B70-B2BC-4793-932E-7376877025E0"		'گواهي مفاصاحساب	
		
			M_ShahrsaziArchiveGroup=2
																								'گواهي پايانکار بهره برداري 	
		Case "82FBD9BC-EBA4-495C-99FF-22B035FB97FF","B0602DD4-FEF9-4AEB-A14A-251B3E86A6D4","04DF58F1-731B-4371-8D53-47435F681362"
		
			M_ShahrsaziArchiveGroup=2
			
		Case "0BC14A0D-B94A-449D-B7AB-28E42852E120","8445278B-A9E0-47A7-8E5E-D1028FB6DB08"		'استعلام الکترونيک	
		
			M_ShahrsaziArchiveGroup=4
			
		Case "A3B24BD2-4CB2-4011-9900-3070AD088A6F"												'تاييد سابقه مجاز	
			
			M_ShahrsaziArchiveGroup=2
			
		Case "B617A65E-F4BF-4ACC-AEFA-3133D1AA92F1"	,"045BEA33-0A29-4F35-8CC1-672417F49DC1"		'مجوز صدور بهره برداري موقت - صنفي
			
			M_ShahrsaziArchiveGroup=2
			
		Case "9F91A6D9-1E14-43AA-9968-39A99798D463"												'اقامتي موقت	
			
			M_ShahrsaziArchiveGroup=2
			
		Case "B54E1F02-AB96-46D7-AAC0-41691054CC96","8B26053C-5554-48FB-99FB-62431AA06C07","BA5A32EC-C23B-4E0D-8087-7D083D181644"		'اراضي غيرمحصور و رها	
		
			M_ShahrsaziArchiveGroup=2
			
		Case "F5F8B45F-A8D0-4384-9ED2-42DC747A1A20"												'ايجاد کد آپارتمان 	
		
			M_ShahrsaziArchiveGroup=2
			
	'
		Case "8ECF01D4-A93C-44A7-B52B-4685634C54C6"	, "68C87B74-097E-4EC0-83D1-7723C403B1F8","5A659F4C-8DC6-4283-A496-BD20C952A810","A1C05500-1D9F-4CDF-B3C5-D26B115CC2D5","F32B14FF-E1E8-479B-8A9B-979BF74F7579" ,"18313B50-F76D-428A-BAE4-134A918B2600","1A9B0C43-C8C5-4A08-B2F2-E123CD4C370C","D8A215F8-2E28-45A0-A826-5ED886F16CCF","F0D7598B-7692-44B3-BD99-B18B870ACC35","3CA97718-4AFE-4752-A892-8B5EF88F176C" 
		
			M_ShahrsaziArchiveGroup=1
			

		Case "A24A966E-0BCB-432F-8474-4ED76CF93A79" , "D9E55CD5-922B-4D56-80C8-7FE5F7178C95","679C82EB-4227-45D5-966D-A62C7FE580EB","457475B0-E461-475E-89FC-1FB85FD41FEC","938EE557-4E3B-43EE-A9EE-ED12D17351DC","7321AE5D-C65E-48DD-A8D5-3BF4773923E7","307E2C2F-99DC-4AB3-A6A4-AF7A5D731581","D62680B7-5038-4066-B651-73B3F94C225F"	'پروانه توسعه بنا	
		
			M_ShahrsaziArchiveGroup=1
			
		Case "297949D0-9E25-419E-AD7C-62A7034910A1","3EBB3B53-972C-425F-9939-80E76AAB6BFB"		'گواهي پايانکار تفکيکي آپارتمان	
		
			M_ShahrsaziArchiveGroup=2				
			
		Case "7318F0DB-13DD-40E4-BB89-6C4C7A23FF62","1426A8E6-68BC-4B2F-8E82-7C478D5CAB14"	,"CDAA2D6E-1184-4983-A516-A8A2FF92795C"
																	'گواهي انتقال
			M_ShahrsaziArchiveGroup=2
			
		Case "85DF30CD-BE53-466E-AA76-749A40831BA5","62B24930-E3B9-455E-889F-74B32274C320"		'استعلام ادارات	
		
			M_ShahrsaziArchiveGroup=4
			
		Case "9E7565F4-21C3-4497-887F-A751274EDEEF"	,"7FF7C349-A773-4A45-8F52-F8593B467A96","E34D362D-D8F9-4481-B1C2-E9F880A08582","DAACD02A-5B8D-4C40-9FFB-DE24B605D084"	
		
			M_ShahrsaziArchiveGroup=2
			
		Case "DEFFC4C0-D37E-4CC3-94FD-ABA24FAAEAB2","FCA0F71C-6040-46AA-B927-F3ED908BAE80"		'ساير	
		
			M_ShahrsaziArchiveGroup=2
			
	
		Case "88E98ADA-C0F2-48B5-A724-4B455E445303","7D38106F-7362-4283-BDD9-0AC4E4BE2384","5BD4AD80-D3A5-4F87-81CB-652363740C1D","8AEAD964-2A11-4072-9F17-0BAB8E4511C5","CBB8C800-70E6-432B-B338-1F229A365712","16C77278-30A1-4375-80DC-7EE8367B39FD","CB807F34-5A6F-445E-9E7F-C32FC9F1338B"		'تجدید پروانه
		
			M_ShahrsaziArchiveGroup=1
			
		Case "4C1AAC11-CF11-4867-B467-C4B6DF47F972"	,"FFF07F64-7B35-43BA-B363-95332389273B"		'مجوز خدماتي	
		
			M_ShahrsaziArchiveGroup=3
			
	
		Case "0B53D213-CB83-4E5C-9319-C551CCB187E9"	,"0C2B0730-504F-44AD-A067-6AF8AA1A3132","3DBF0B9B-7A1A-4459-81F2-6FC6FC208FCF","AA2E5691-CD31-452C-A019-ADE4494EC258","CB2A1920-7B97-4D20-9BBE-12D50F40BB5A","AA2E5691-CD31-452C-A019-ADE4494EC258","B956EA48-27DC-4B8F-893D-9BC6289EFB16","27CFF1AD-5936-407E-A420-5B8B71F94566","CC1FBC44-7EDD-41E7-A64B-3D6DF21E855E" '1939010 tel hesami		'تجديد  اصلاح پروانه	
		
			M_ShahrsaziArchiveGroup=1
			
		Case "72A5E955-CC6D-43E9-811B-C6FF410CA009","8EBA8AAB-A256-4EEC-B1E5-DA115686A9B0"		'تعيين بروکف	
		
			M_ShahrsaziArchiveGroup=2
			
		Case "2CA83747-919F-4FC2-B3DB-D37BA6272320"												'گواهي تجميع 	
		
			M_ShahrsaziArchiveGroup=2
																								'بهره برداري موقت	
		Case "B825F591-1E4E-4FD0-A9B7-D437C56C9BE4","66B37DC0-8081-4745-ADEA-6514AB47DE6F","3D4A5DB8-13C1-47A4-BA37-D49E042A1E5F"
			
			M_ShahrsaziArchiveGroup=2
			
	
		Case "F57C96A0-697F-410C-AA37-DFDE36A29C47","710510E5-D8B3-459D-9CAC-DBE13C7DB8DE","F5B285CC-8792-498C-A6C0-0D1571EEB793" ,"E0B7EF-E10C-4727-BF96-4399B6A37196"	,"50E0B7EF-E10C-4727-BF96-4399B6A37196","27F2E6C5-498B-47F4-8E1A-B83EFDD2EAA7"	'پروانه ديوارکشي	
		
			M_ShahrsaziArchiveGroup=1
			
		Case "5CB085FB-C9CB-4D1E-A98F-DFF8E76A618A","994AD909-C2B7-476B-9BE2-8821EA1C9841"		'مجوز تعميرات	
			
			M_ShahrsaziArchiveGroup=2
		Case "676E0202-F41E-44E9-98C7-E586072F8C17","577CB127-0C16-4F4D-B645-A7B4D0EC713B","5482C28A-025D-40FB-A928-B62EAD670ACE"
																								'گواهي افراز	
		
			M_ShahrsaziArchiveGroup=2
																								'گواهي عدم خلاف	
		Case "80134AAF-F070-4706-AC6A-E82778B7029C","5F07A635-B569-47F7-A97F-2AA2C36AFE37","FBE3AD14-934C-4F8F-8BA2-5C07BFB4696D"
		
			M_ShahrsaziArchiveGroup=2
			
		Case "9A15158D-0369-452C-B73D-E8AC3295FE10","D84FA3D1-54FD-4D24-8000-758A300B2441"		'گواهي مفاصا بهره برداري صنفي	
		
			M_ShahrsaziArchiveGroup=2
							

		Case "214CE534-3326-4C0F-9CF5-F6EC3844B847","9660D3B0-B41A-4B2A-BA3F-75F0E5B78085","22F8F7D9-71D9-4FBA-90F5-E43AD0EDC746","102D761E-C698-4C9B-A5A9-C6D1B57EBBCC","86D5016B-AB5D-4577-B318-791A083AFC5F","1A9B0C43-C8C5-4A08-B2F2-E123CD4C370C","26ADD6E3-9EEF-4757-87F2-2E9091AB730C","3411EFED-3AEF-4619-8DED-1C4D845572C1","AA458943-252C-444F-802E-F038156A208C","D8F77DFA-ECE9-4F52-9AEE-3458D5D91272","1661EA82-19A6-4ED6-9EE1-63B16C5FDA8D"
																	'پروانه تجديد بنا	
			M_ShahrsaziArchiveGroup=1
			
		Case "08C2BE75-FAF3-457E-9B33-C97681FA419D" 											'پروانه پيشنهادي
		
			M_ShahrsaziArchiveGroup=1
			
		Case "0082452E-08E3-432C-9FCE-3E9915F253D1"												'پايانکار پيشنهادي
		
			M_ShahrsaziArchiveGroup=2
			
	
		Case "20286CC7-9313-4363-8C70-0C7814B79CC9","E33F2C9A-C0A7-46F5-B4A1-6CBDA0FE419D","17FD1A79-AC10-4B37-8D4F-1FAD7550F2C4" ,"30F756C2-2AAF-4543-B98D-FBAB4BC916FD","AB164972-4C84-445E-A8FD-D576578E24B1","C3D8B-4B4E-4837-A7EE-302CB70F5FA3","E1AC3D8B-4B4E-4837-A7EE-302CB70F5FA3","7B60BD7D-5116-4B6A-8B6C-8EE303345AD9","5D7FEE70-04D1-4047-86C8-546BD7618503","C6230C76-3DEB-41E3-8F68-DEEA920763D1"		'اصلاح پروانه 
		
			M_ShahrsaziArchiveGroup=1
			
		Case "CBAD978D-3764-4E51-903C-9A8831B18760"												' گواهي اتحاديه صنفي
		
			M_ShahrsaziArchiveGroup=2
			
	End Select
	
Catch
	Info8.AddError(BIZ.SA.EumErrorAction.Stop,"GetSara8Workflow", "اجرای فرمول درآمد-GetSara8Workflow")
End Try
End Function

Private Function GetDiffDate(ByVal Date1 As String, ByVal Date2 As String, ByVal Mood As Integer) As Integer
    'Mood : 1 ماه .... 2  سال
    Dim D1, D2, M1, M2, Y1, Y2, Out As Integer
    Dim tmpstr(), tmpstr2() As String
    tmpstr = Date1.Split("/")
    D1 = tmpstr(2)
    M1 = tmpstr(1)
    Y1 = tmpstr(0)


    tmpstr2 = Date2.Split("/")
    D2 = tmpstr2(2)
    M2 = tmpstr2(1)
    Y2 = tmpstr2(0)

    If Mood = 1 Then
        If Y2 >= Y1 Then
            If M2 <= M1 And Y2 = Y1 Then
                Return 0
            ElseIf M2 > M1 And Y2 = Y1 Then
                Out = M2 - M1
                '	if D2<D1 Then Out-=1
                If D2 > D1 Then Out += 1
                Return out
            ElseIf Y2 > Y1 Then
                If M2 >= M1 Then
                    Out = (Y2 - Y1) * 12
                    Out += (M2 - M1)
                    '	if D2<D1 Then Out-=1
                    If D2 > D1 Then Out += 1
                    Return out
                ElseIf M2 < M1 Then
                    Out = (Y2 - Y1) * 12
                    Out = ((M2 + Out) - M1)
                    '	if D2<D1 Then Out-=1
                    If D2 > D1 Then Out += 1
                    Return out
                End If
            End If

        End If

    ElseIf Mood = 2 Then
        If Y2 > Y1 Then
            Out = Y2 - Y1
            If M2 <= M1 Then Out -= 1
            Return out
        End If

    ElseIf Mood = 3 Then

        Dim Day1 As Long
        Select Case Y1
            Case 1388
                Day1 = 0
            Case 1389
                Day1 = 365
            Case 1390
                Day1 = 365 * 2
            Case 1391
                Day1 = 365 * 3
            Case 1392
                Day1 = (365 * 3) + 366
            Case 1393
                Day1 = (365 * 4) + 366
            Case 1394
                Day1 = (365 * 5) + 366
            Case 1395
                Day1 = (365 * 6) + 366 
            Case 1396
                Day1 = (365 * 7) + 366 
            Case 1397
                Day1 = (365 * 8) + 366                
        End Select
        If M1 < 7 Then
            Day1 += (M1 - 1) * 31
        Else
            Day1 += (6 * 31) + (M1 - 7) * 30
        End If
        Day1 += D1

        '-----------------
        Dim Day2 As Long
        Select Case Y2
            Case 1388
                Day2 = 0
            Case 1389
                Day2 = 365
            Case 1390
                Day2 = 365 * 2
            Case 1391
                Day2 = 365 * 3
            Case 1392
                Day2 = (365 * 3) + 366
            Case 1393
                Day2 = (365 * 4) + 366
            Case 1394
                Day2 = (365 * 5) + 366
            Case 1395
                Day2 = (365 * 6) + 366 
            Case 1396
                Day1 = (365 * 7) + 366 
            Case 1397
                Day1 = (365 * 8) + 366   
        End Select
        If M2 < 7 Then
            Day2 += (M2 - 1) * 31
        Else
            Day2 += (6 * 31) + (M2 - 7) * 30
        End If
        Day2 += D2

        Return iif(Day2 - Day1 < 0, 0, Day2 - Day1)
    End If
    Return 0


End Function



<DisplayName(" درآمدی تهاتر")> Public Function Tahator()

'    Try
    
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                 Dim ExistRayvarz As Boolean =True
   
       
           If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=158 Then  ExistRayvarz = False
		
           
              
              If ExistRayvarz = False Then
               
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then
               

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                Dim BedeHiTmp As Decimal = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 
                
                ''''''''''''''''''new 
					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
 					
                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                		               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If TmpInComeCode.ToString = DBNull.Value.ToString or TmpInComeCode.ToString=0 Or TmpDT(Ti).CI_IncomeCalculation = 100036 Or TmpDT(Ti).CI_IncomeCalculation = 100041 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100042 Or TmpDT(Ti).CI_IncomeCalculation = 100043 Or TmpDT(Ti).CI_IncomeCalculation = 100047 Or TmpDT(Ti).CI_IncomeCalculation = 100048 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100049 Or TmpDT(Ti).CI_IncomeCalculation = 100050 Or TmpDT(Ti).CI_IncomeCalculation = 100052 Or TmpDT(Ti).CI_IncomeCalculation = 100028 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100016 Or TmpDT(Ti).CI_IncomeCalculation = 100009 Or TmpDT(Ti).CI_IncomeCalculation = 100002 Or TmpDT(Ti).CI_IncomeCalculation = 1091 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 1101   Or TmpDT(Ti).CI_IncomeCalculation = 100055 Or TmpDT(Ti).CI_IncomeCalculation = 100057 Or TmpDT(Ti).CI_IncomeCalculation = 100061 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100060 Or TmpDT(Ti).CI_IncomeCalculation =100200 Or TmpDT(Ti).CI_IncomeCalculation =100075 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100067 Or TmpDT(Ti).CI_IncomeCalculation = 100068 Or TmpDT(Ti).CI_IncomeCalculation = 100087 Or TmpDT(Ti).CI_IncomeCalculation =  999999 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 120 or TmpDT(Ti).CI_IncomeCalculation = 100006 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100072 or TmpDT(Ti).CI_IncomeCalculation = 100032 _
                        or TmpDT(Ti).CI_IncomeCalculation = 100080 or TmpDT(Ti).CI_IncomeCalculation =100101 or TmpDT(Ti).CI_IncomeCalculation = 100045 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100102 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100103 Or TmpDT(Ti).CI_IncomeCalculation = 100104 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100105 Or TmpDT(Ti).CI_IncomeCalculation = 100097 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100098 Or TmpDT(Ti).CI_IncomeCalculation = 100099 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100109 Or TmpDT(Ti).CI_IncomeCalculation = 100029 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100114 Or TmpDT(Ti).CI_IncomeCalculation = 100081 Or TmpDT(Ti).CI_IncomeCalculation = 100082 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100053 Or TmpDT(Ti).CI_IncomeCalculation = 1301 Or TmpDT(Ti).CI_IncomeCalculation = 100202 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                            Dim LstOdd As New List(Of Global.DtoSC.Income_OddmentAccount)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 2 or f.CI_OddmentType = 3 or f.CI_OddmentType = 6 or f.CI_OddmentType=7) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price - LstOdd.Sum(Function(f) f.Value)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 8 or f.CI_OddmentType =1 or f.CI_OddmentType = 4) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price + LstOdd.Sum(Function(f) f.Value)
			                TmpOne.WrapperAccountNo = IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

               
						
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        TmpOne.FileNo=  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
                     
				Dim LstOdd_1 As New List(Of DtoSC.Income_OddmentAccount)
                LstOdd_1 = Info8.GetIncome.GetIncome_OddmentAccount
                Dim ChechOdd as Integer=0
                Dim Ti_1 as Integer
				For Ti=0 to LstOdd_1.count -1
					ChechOdd=0
					For Ti_1=0 to TmpAccounting_DocDetailsList.count -1 
						if LstOdd_1(Ti).CI_IncomeCalculation=TmpAccounting_DocDetailsList(Ti_1).WrapperAccountNo Then	ChechOdd=1
						If LstOdd_1(Ti).CI_IncomeCalculation =0 or LstOdd_1(Ti).CI_IncomeCalculation = 100036 Or LstOdd_1(Ti).CI_IncomeCalculation = 100041 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100042 Or LstOdd_1(Ti).CI_IncomeCalculation = 100043 Or LstOdd_1(Ti).CI_IncomeCalculation = 100047 Or LstOdd_1(Ti).CI_IncomeCalculation = 100048 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100049 Or LstOdd_1(Ti).CI_IncomeCalculation = 100050 Or LstOdd_1(Ti).CI_IncomeCalculation = 100052 Or LstOdd_1(Ti).CI_IncomeCalculation = 100028 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100016 Or LstOdd_1(Ti).CI_IncomeCalculation = 100009 Or LstOdd_1(Ti).CI_IncomeCalculation = 100002 Or LstOdd_1(Ti).CI_IncomeCalculation = 1091 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 1101   Or LstOdd_1(Ti).CI_IncomeCalculation = 100055 Or LstOdd_1(Ti).CI_IncomeCalculation = 100057 Or LstOdd_1(Ti).CI_IncomeCalculation = 100061 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100060 Or LstOdd_1(Ti).CI_IncomeCalculation = 100200 Or LstOdd_1(Ti).CI_IncomeCalculation = 100075 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100067 Or LstOdd_1(Ti).CI_IncomeCalculation = 100068 or LstOdd_1(Ti).CI_IncomeCalculation = 100029 Or LstOdd_1(Ti).CI_IncomeCalculation = 100087 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =  999999 Or LstOdd_1(Ti).CI_IncomeCalculation = 120 or LstOdd_1(Ti).CI_IncomeCalculation = 100006 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100072 or LstOdd_1(Ti).CI_IncomeCalculation = 100032  or LstOdd_1(Ti).CI_IncomeCalculation =100080 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100101 Or LstOdd_1(Ti).CI_IncomeCalculation = 100045  Or LstOdd_1(Ti).CI_IncomeCalculation = 100102 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100103 Or LstOdd_1(Ti).CI_IncomeCalculation = 100104 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100105 Or LstOdd_1(Ti).CI_IncomeCalculation = 100097 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100098 Or LstOdd_1(Ti).CI_IncomeCalculation = 100099 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100109  _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100114 Or LstOdd_1(Ti).CI_IncomeCalculation = 100081 Or LstOdd_1(Ti).CI_IncomeCalculation = 100082 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100053 Or LstOdd_1(Ti).CI_IncomeCalculation = 1301 Or LstOdd_1(Ti).CI_IncomeCalculation = 100201 Or LstOdd_1(Ti).CI_IncomeCalculation = 100202 Then   ChechOdd=1
                        if ChechOdd=0 Then if Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="0" or Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="1" Then  ChechOdd=1 
					Next
					 
					if ChechOdd=0 Then 
						 Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
						 if LstOdd_1(Ti).CI_OddmentType = 2 or LstOdd_1(Ti).CI_OddmentType = 3 or LstOdd_1(Ti).CI_OddmentType = 6 or LstOdd_1(Ti).CI_OddmentType=7  Then
	                     	TmpOne.Price = LstOdd_1(Ti).Value * (-1)
	                     Else
	                     	TmpOne.Price = LstOdd_1(Ti).Value
	                     End if 
	                     if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=150 Then TmpOne.FileNo=1 	
						 TmpOne.WrapperAccountNo= LstOdd_1(Ti).CI_IncomeCalculation
						 Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstOdd_1(Ti).CI_IncomeCalculation)
						 If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
	                        TmpOne.AccountNoComments = ""
	                     Else
	                        TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
	                     End If
	                     a +=TmpOne.Price
	                     TmpOne.FileNo=  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
	                     TmpAccounting_DocDetailsList.Add(TmpOne)
	                      
	                End if     
                     
				Next
                '--------------------------------------------'---------------------
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
     
              
                Dim TmpChek As Integer = 0
                

				TmpChek=0

                Dim TakhfifRound As Decimal = 0
                Dim TakhfifRound_1 As Decimal = 0
                Dim TakhfifRound_Cash As Decimal = 0
                Dim i As Integer = 0
                Dim jjjj As Integer = 0
               
                Dim test As Integer = 1
                Dim tmpdate As String = ""
 

                TakhfifRound_1 =0 ' TakhfifRound - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue

                '---------------------------------------------------------------------------
                '-------------------------------------------------------------------------------        
                TakhfifRound = 0
  Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		        DistrickBranch=tmpDistrict
		    	Select Case DistrickBranch
                    Case 1
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case 2
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case 3
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case 4
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case 5
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case 6
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case 7
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case 8
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case 9
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case 10
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case 11
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case 12
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case 80
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select       
		    
               
                Dim TTj As Integer = 0
                
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
               
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = 0
                    
                    If a <> 0 Then
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal((Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price) * Convert.ToDecimal(BedeHiTmp)) / Convert.ToDecimal(a)),0) ' (Math.Round( (TmpAccounting_DocDetailsList(TTj).Price*BedeHiTmp)/a,2))
                    Else
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price),0)
                    End If
					
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   
                    'TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
                     if String.IsNullOrEmpty(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) Then
     		        TmpDocDetails.BankCode =0
     		    Else
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                End if 
                    
                   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
    				'if TmpDocDetails.BankCode=""  Then  TmpDocDetails.BankCode= 18
     		 
     			
    			    'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)


                   ' TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    TakhfifRound += TmpDocDetails.Price
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
					TmpDocDetails.FileNo=  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                    
                Next
 	               
               Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
               
                If DtoAccounting_DocHeaderTotal.SaraPrice <> TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price) Then
                    Dim gg As Integer = 0
                    Dim PriceTmp As Decimal = 0
                    
                    if TmpAccounting_DocDetailsListTotal.count>0 Then 
	                    For gg = 1 To TmpAccounting_DocDetailsListTotal.count - 1
	                        PriceTmp += TmpAccounting_DocDetailsListTotal(gg).Price
	                    Next
	                 
                    TmpAccounting_DocDetailsListTotal(0).Price = DtoAccounting_DocHeaderTotal.SaraPrice - PriceTmp
					End if   
                End If
                
                
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                
               
                
                ''''''''''''''''''New 
             
                         Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                       
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                 
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                
		                Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center"
                		if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank="2"  Then 
                			Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CreditorPapers.tostring()
                		Else
                			Refcenter.Value ="0"
                		End if			 		 			 		 		  	   		   		 	
		                ListRefP.add(Refcenter)
                        
                       
                        
                        Dim Refcenter1 As New BIZ.Communication.RefParameetrs
                		Refcenter1.Name = "Center1"
                		Refcenter1.Value = "335000181" 'sp 376651 "353390000"	 			 		 		  	   		   		 	
		               	ListRefP.add(Refcenter1)
		                	
		                	
						Dim RefPRN As New BIZ.Communication.RefParameetrs
		                RefPRN.Name = "Ref"
		                RefPRN.Value = iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,4,2)  
		                ListRefP.add(RefPRN)
						
						
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
						
		                Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		               
		               ' Dim RefQTY   As New BIZ.Communication.RefParameetrs
		               ' RefQTY.Name = "QTY"
		               ' RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		               ' ListRefP.add(RefQTY)
                
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		               		if DistrickBranch = 201 Then
		                		RefFund.Value = 31 
		                	ElseIf DistrickBranch = 202 Then
		                		RefFund.Value = 32 
		                	ElseIf DistrickBranch = 203 Then
		                		RefFund.Value = 33
		                	ElseIf DistrickBranch = 204 Then
		                		RefFund.Value = 34  	  	
		                	ElseIf DistrickBranch = 205 Then
		                		RefFund.Value = 35   	   		 	
		                	ElseIf DistrickBranch = 206 Then
		                		RefFund.Value = 36
		                	ElseIf DistrickBranch = 207 Then
		                		RefFund.Value = 37 
		                 	ElseIf DistrickBranch = 208 Then
		                 		RefFund.Value = 38   
		                 	ElseIf DistrickBranch = 209 Then
                 				RefFund.Value = 39 
                 			ElseIf DistrickBranch = 210 Then
                 				RefFund.Value = 40 
                 			ElseIf DistrickBranch = 211 Then
                 				RefFund.Value = 41 
                 			ElseIf DistrickBranch = 212 Then
                 				RefFund.Value = 42 
                 			ElseIf DistrickBranch = 218 Then
                				RefFund.Value = 43
		                    End if 	
		                ListRefP.add(RefFund) 
		              '  Dim RefNum As New BIZ.Communication.RefParameetrs
		              '  RefNum.Name = "Num"
		               ' RefNum.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
		              '  ListRefP.add(RefNum)
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                Mess.ActTyp = 1
		                Mess.DocTyp = iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,17,18) 
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد تهاتر درامد"  
		                Mess.DocTypDsc = "عوارض تهاتر درامد"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo
               
                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc
         

                Dim tmpstr As String = ""
					
                Try
                tmpstr = TmpDocument.Save(NidF)
                 Catch ex As Exception
        Info8.AddError(BIZ.SA.EumErrorAction.Stop, "aaa توجه", "NidF" + NidF.tostring + ex.Message)
   End Try
               
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "tmpstr", tmpstr.tostring)
            End If
        End If
End Function


<DisplayName("باز افرینی")> Public Function BazAfarine()

'    Try
    
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                 Dim ExistRayvarz As Boolean =True
   
       
           If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=156 Then  ExistRayvarz = False
		
           
              
              If ExistRayvarz = False Then
               
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then
               

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                Dim BedeHiTmp As Decimal = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 
                
                ''''''''''''''''''new 
					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
 					
                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                		               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If TmpInComeCode.ToString = DBNull.Value.ToString or TmpInComeCode.ToString=0 Or TmpDT(Ti).CI_IncomeCalculation = 100036 Or TmpDT(Ti).CI_IncomeCalculation = 100041 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100042 Or TmpDT(Ti).CI_IncomeCalculation = 100043 Or TmpDT(Ti).CI_IncomeCalculation = 100047 Or TmpDT(Ti).CI_IncomeCalculation = 100048 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100049 Or TmpDT(Ti).CI_IncomeCalculation = 100050 Or TmpDT(Ti).CI_IncomeCalculation = 100052 Or TmpDT(Ti).CI_IncomeCalculation = 100028 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100016 Or TmpDT(Ti).CI_IncomeCalculation = 100009 Or TmpDT(Ti).CI_IncomeCalculation = 100002 Or TmpDT(Ti).CI_IncomeCalculation = 1091 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 1101   Or TmpDT(Ti).CI_IncomeCalculation = 100055 Or TmpDT(Ti).CI_IncomeCalculation = 100057 Or TmpDT(Ti).CI_IncomeCalculation = 100061 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100060 Or TmpDT(Ti).CI_IncomeCalculation =100200 Or TmpDT(Ti).CI_IncomeCalculation =100075 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100067 Or TmpDT(Ti).CI_IncomeCalculation = 100068 Or TmpDT(Ti).CI_IncomeCalculation = 100087 Or TmpDT(Ti).CI_IncomeCalculation =  999999 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 120 or TmpDT(Ti).CI_IncomeCalculation = 100006 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100072 or TmpDT(Ti).CI_IncomeCalculation = 100032 _
                        or TmpDT(Ti).CI_IncomeCalculation = 100080 or TmpDT(Ti).CI_IncomeCalculation =100101 or TmpDT(Ti).CI_IncomeCalculation = 100045 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100102 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100103 Or TmpDT(Ti).CI_IncomeCalculation = 100104 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100105 Or TmpDT(Ti).CI_IncomeCalculation = 100097 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100098 Or TmpDT(Ti).CI_IncomeCalculation = 100099 _
                        Or TmpDT(Ti).CI_IncomeCalculation = 100109 Or TmpDT(Ti).CI_IncomeCalculation = 100029 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100114 Or TmpDT(Ti).CI_IncomeCalculation = 100081 Or TmpDT(Ti).CI_IncomeCalculation = 100082 _
                        Or TmpDT(Ti).CI_IncomeCalculation =100053 Or TmpDT(Ti).CI_IncomeCalculation = 1301 Or TmpDT(Ti).CI_IncomeCalculation = 100202 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                            Dim LstOdd As New List(Of Global.DtoSC.Income_OddmentAccount)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 2 or f.CI_OddmentType = 3 or f.CI_OddmentType = 6 or f.CI_OddmentType=7) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price - LstOdd.Sum(Function(f) f.Value)
			                LstOdd = Info8.GetIncome.GetIncome_OddmentAccount
			                if LstOdd.any() Then LstOdd=LstOdd.Where(Function(f) f.NidIncome= Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome And (f.CI_OddmentType = 8 or f.CI_OddmentType =1 or f.CI_OddmentType = 4) And f.CI_IncomeCalculation = TmpDT(Ti).CI_IncomeCalculation).tolist
			                if LstOdd.Any Then TmpOne.Price= TmpOne.Price + LstOdd.Sum(Function(f) f.Value)
			                TmpOne.WrapperAccountNo = IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

               
						
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        TmpOne.FileNo=  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
                     
				Dim LstOdd_1 As New List(Of DtoSC.Income_OddmentAccount)
                LstOdd_1 = Info8.GetIncome.GetIncome_OddmentAccount
                Dim ChechOdd as Integer=0
                Dim Ti_1 as Integer
				For Ti=0 to LstOdd_1.count -1
					ChechOdd=0
					For Ti_1=0 to TmpAccounting_DocDetailsList.count -1 
						if LstOdd_1(Ti).CI_IncomeCalculation=TmpAccounting_DocDetailsList(Ti_1).WrapperAccountNo Then	ChechOdd=1
						If LstOdd_1(Ti).CI_IncomeCalculation =0 or LstOdd_1(Ti).CI_IncomeCalculation = 100036 Or LstOdd_1(Ti).CI_IncomeCalculation = 100041 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100042 Or LstOdd_1(Ti).CI_IncomeCalculation = 100043 Or LstOdd_1(Ti).CI_IncomeCalculation = 100047 Or LstOdd_1(Ti).CI_IncomeCalculation = 100048 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100049 Or LstOdd_1(Ti).CI_IncomeCalculation = 100050 Or LstOdd_1(Ti).CI_IncomeCalculation = 100052 Or LstOdd_1(Ti).CI_IncomeCalculation = 100028 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100016 Or LstOdd_1(Ti).CI_IncomeCalculation = 100009 Or LstOdd_1(Ti).CI_IncomeCalculation = 100002 Or LstOdd_1(Ti).CI_IncomeCalculation = 1091 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 1101   Or LstOdd_1(Ti).CI_IncomeCalculation = 100055 Or LstOdd_1(Ti).CI_IncomeCalculation = 100057 Or LstOdd_1(Ti).CI_IncomeCalculation = 100061 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100060 Or LstOdd_1(Ti).CI_IncomeCalculation = 100200 Or LstOdd_1(Ti).CI_IncomeCalculation = 100075 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100067 Or LstOdd_1(Ti).CI_IncomeCalculation = 100068 or LstOdd_1(Ti).CI_IncomeCalculation = 100029 Or LstOdd_1(Ti).CI_IncomeCalculation = 100087 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =  999999 Or LstOdd_1(Ti).CI_IncomeCalculation = 120 or LstOdd_1(Ti).CI_IncomeCalculation = 100006 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100072 or LstOdd_1(Ti).CI_IncomeCalculation = 100032  or LstOdd_1(Ti).CI_IncomeCalculation =100080 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100101 Or LstOdd_1(Ti).CI_IncomeCalculation = 100045  Or LstOdd_1(Ti).CI_IncomeCalculation = 100102 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100103 Or LstOdd_1(Ti).CI_IncomeCalculation = 100104 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100105 Or LstOdd_1(Ti).CI_IncomeCalculation = 100097 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation = 100098 Or LstOdd_1(Ti).CI_IncomeCalculation = 100099 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100114 Or LstOdd_1(Ti).CI_IncomeCalculation = 100109 Or LstOdd_1(Ti).CI_IncomeCalculation = 100081 Or LstOdd_1(Ti).CI_IncomeCalculation = 100082 _
                        Or LstOdd_1(Ti).CI_IncomeCalculation =100053 Or LstOdd_1(Ti).CI_IncomeCalculation = 1301 Or LstOdd_1(Ti).CI_IncomeCalculation = 100201 Or LstOdd_1(Ti).CI_IncomeCalculation = 100202 Then   ChechOdd=1
                        if ChechOdd=0 Then if Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="0" or Info8.GetFunctions.GetCI_IncomeCalculation (LstOdd_1(Ti).CI_IncomeCalculation).IncomeCode="1" Then  ChechOdd=1 
					Next
					 
					if ChechOdd=0 Then 
						 Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
						 if LstOdd_1(Ti).CI_OddmentType = 2 or LstOdd_1(Ti).CI_OddmentType = 3 or LstOdd_1(Ti).CI_OddmentType = 6 or LstOdd_1(Ti).CI_OddmentType=7  Then
	                     	TmpOne.Price = LstOdd_1(Ti).Value * (-1)
	                     Else
	                     	TmpOne.Price = LstOdd_1(Ti).Value
	                     End if 
	                    
						 TmpOne.WrapperAccountNo= LstOdd_1(Ti).CI_IncomeCalculation
						 Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", LstOdd_1(Ti).CI_IncomeCalculation)
						 If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
	                        TmpOne.AccountNoComments = ""
	                     Else
	                        TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
	                     End If
	                     a +=TmpOne.Price
	                     TmpOne.FileNo=  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
	                     TmpAccounting_DocDetailsList.Add(TmpOne)
	                      
	                End if     
                     
				Next
                '--------------------------------------------'---------------------
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
     
              
                Dim TmpChek As Integer = 0
                

				TmpChek=0

                Dim TakhfifRound As Decimal = 0
                Dim TakhfifRound_1 As Decimal = 0
                Dim TakhfifRound_Cash As Decimal = 0
                Dim i As Integer = 0
                Dim jjjj As Integer = 0
               
                Dim test As Integer = 1
                Dim tmpdate As String = ""


                TakhfifRound_1 =0 ' TakhfifRound - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).InsatllmentValue

                '---------------------------------------------------------------------------
                '-------------------------------------------------------------------------------        
                TakhfifRound = 0
  Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		        DistrickBranch=tmpDistrict
		    	Select Case DistrickBranch
                    Case 1
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case 2
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case 3
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case 4
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case 5
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case 6
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case 7
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case 8
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case 9
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case 10
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case 11
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case 12
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case 80
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select       
		    
               
                Dim TTj As Integer = 0
                
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
               
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = 0
                    
                    If a <> 0 Then
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal((Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price) * Convert.ToDecimal(BedeHiTmp)) / Convert.ToDecimal(a)),0) ' (Math.Round( (TmpAccounting_DocDetailsList(TTj).Price*BedeHiTmp)/a,2))
                    Else
                        TmpDocDetails.Price = Math.Round(Convert.ToDecimal(TmpAccounting_DocDetailsList(TTj).Price),0)
                    End If
					
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    			'	if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
    			    'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                   ' TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    TakhfifRound += TmpDocDetails.Price
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
					TmpDocDetails.FileNo=  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                    
                Next
 	               
               Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
               
                If DtoAccounting_DocHeaderTotal.SaraPrice <> TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price) Then
                    Dim gg As Integer = 0
                    Dim PriceTmp As Decimal = 0
                    
                    if TmpAccounting_DocDetailsListTotal.count>0 Then 
	                    For gg = 1 To TmpAccounting_DocDetailsListTotal.count - 1
	                        PriceTmp += TmpAccounting_DocDetailsListTotal(gg).Price
	                    Next
	                 
                    	TmpAccounting_DocDetailsListTotal(0).Price = DtoAccounting_DocHeaderTotal.SaraPrice - PriceTmp
					End if   
                End If
                
                
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                
                
                
                ''''''''''''''''''New 
             
                       Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center"
                		
                			if tmpDistrict = 1 or tmpDistrict = 201  Then
		                		Refcenter.Value = 910100001 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		Refcenter.Value = 910200001 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		Refcenter.Value = 910300001
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		Refcenter.Value = 910400001  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		Refcenter.Value = 910500001   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		Refcenter.Value = 910600001
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		                		Refcenter.Value = 910700001 
		                 	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                 		Refcenter.Value = 910800001   
		                 	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				Refcenter.Value = 910900001 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				Refcenter.Value = 911000001 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				Refcenter.Value = 911100001 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				Refcenter.Value = 911200001 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				Refcenter.Value = 911300001  	 		 			 		 			 		 		  	   		   		 	
		                	End if 	
                	
                		ListRefP.add(Refcenter)
                        
                        
                        
                        Dim Refcenter1 As New BIZ.Communication.RefParameetrs
                		Refcenter1.Name = "Center1"
                		Refcenter1.Value = 335000046  	 		 			 		 			 		 		  	   		   		 	
		               	ListRefP.add(Refcenter1)
                		
                		Dim Refcenter2 As New BIZ.Communication.RefParameetrs
                		Refcenter2.Name = "Center2"
                		Refcenter2.Value = 800800007  	 		 			 		 			 		 		  	   		   		 	
		              	ListRefP.add(Refcenter2)
                		
                		Dim Refcenter3 As New BIZ.Communication.RefParameetrs
                		Refcenter3.Name = "Center3"
                		
                			if tmpDistrict = 1 or tmpDistrict = 201  Then
		                		Refcenter3.Value = 910100001 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		Refcenter3.Value = 910200001 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		Refcenter3.Value = 910300001
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		Refcenter3.Value = 910400001  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		Refcenter3.Value = 910500001   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		Refcenter3.Value = 910600001
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		                		Refcenter3.Value = 910700001 
		                	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                		Refcenter3.Value = 910800001   
		                	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				Refcenter3.Value = 910900001 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				Refcenter3.Value = 911000001 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				Refcenter3.Value = 911100001 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				Refcenter3.Value = 911200001 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				Refcenter3.Value = 911300001  	 		 			 		 			 		 		  	   		   		 	
		                	End if 	
                	       	ListRefP.add(Refcenter3)
                        
                        
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		               	RefFund.Value = 200888 
		                ListRefP.add(RefFund)
						
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
		                
		                
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
				
		                Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
                
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                Mess.ActTyp = 3
		                Mess.DocTyp = 12
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "باز افرینی"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		       FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc
         

                Dim tmpstr As String = ""
					
                Try
                tmpstr = TmpDocument.Save(NidF)
                 Catch ex As Exception
        Info8.AddError(BIZ.SA.EumErrorAction.Stop, "bbb توجه", "NidF" + NidF.tostring + ex.Message)
   End Try
               
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If
End Function

<DisplayName("قدیم باز افرینی")> Public Function BazAfarineOld()
 
'    Try
    
        
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                 Dim ExistRayvarz As Boolean =True
   
       
           If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=156    Then  ExistRayvarz = False
		
           
              
              If ExistRayvarz = False Then
               
               
               
               
               
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                Dim BedeHiTmp As Decimal = 0 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
				Dim  BedahiFAdd as Double=0
				BedahiFAdd=0 'BedeHi(DistrickBranch, Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo)
              '                
                ''''''''''''''''''new 

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
               
                		               
                If TmpDT.any() Then
                	
                	
                    For Ti = 0 To TmpDT.count - 1
                    
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                        TmpOne.Price = IIf(IsDBNull(TmpDT(Ti).SysValue), TmpDT(Ti).Value, TmpDT(Ti).SysValue)
                        TmpOne.Price = IIf(TmpOne.Price.tostring<TmpDT(Ti).Value.tostring, TmpDT(Ti).Value, TmpOne.Price)
                        Dim TmpInComeCode = TmpDT(Ti).CI_IncomeCalculation
                        
                        TmpImcomeAccontGroup = ImcomeAccontGroup.Where(Function(f) f.CI_IncomeCalculation = TmpInComeCode).ToList
                        If  TmpDT(Ti).CI_IncomeCalculation <> 100098 And TmpDT(Ti).CI_IncomeCalculation <> 100107 And TmpDT(Ti).CI_IncomeCalculation <> 100108 Then
                            TmpOne.WrapperAccountNo = 0
                            TmpOne.Price=0
                        Else
                            TmpOne.Price= Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable ' 270919 TmpOne.Price
			                TmpOne.WrapperAccountNo = TmpDT(Ti).CI_IncomeCalculation 'sp 315188 100098 ' sp 317030 103001901 ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
			                a +=TmpOne.Price
			            End If

                     
						 
                        Dim TmpIncomeCalculationDesc = Info8.GetFunctions.GetCodeTitle("CI_IncomeCalculation", TmpDT(Ti).CI_IncomeCalculation)
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                    Next
                End If
            
			 
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		        DistrickBranch=tmpDistrict
		    	Select Case DistrickBranch
                    Case 1
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case 2
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case 3
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case 4
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case 5
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case 6
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case 7
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case 8
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case 9
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case 10
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case 11
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case 12
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case 80
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select       
		    
		   
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
               
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = a
                    
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    
                    'TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    			'	if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     				 TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                     if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				 TmpChekNo= CStr(TmpDocDetails.BankCode)
    			    'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                  ' TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
                 
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                
                DtoAccounting_DocHeaderTotal.PhasType = 7
             
               
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
               
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
                       
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center"
                		
                			if tmpDistrict = 1 or tmpDistrict = 201  Then
		                		Refcenter.Value = 910100001 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		Refcenter.Value = 910200001 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		Refcenter.Value = 910300001
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		Refcenter.Value = 910400001  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		Refcenter.Value = 910500001   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		Refcenter.Value = 910600001
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		                		Refcenter.Value = 910700001 
		                 	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                 		Refcenter.Value = 910800001   
		                 	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				Refcenter.Value = 910900001 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				Refcenter.Value = 911000001 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				Refcenter.Value = 911100001 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				Refcenter.Value = 911200001 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				Refcenter.Value = 911300001  	 		 			 		 			 		 		  	   		   		 	
		                	End if 	
                	
                		ListRefP.add(Refcenter)
                        
                        
                        
                        Dim Refcenter1 As New BIZ.Communication.RefParameetrs
                		Refcenter1.Name = "Center1"
                		Refcenter1.Value = 335000046  	 		 			 		 			 		 		  	   		   		 	
		               	ListRefP.add(Refcenter1)
                		
                		Dim Refcenter2 As New BIZ.Communication.RefParameetrs
                		Refcenter2.Name = "Center2"
                		Refcenter2.Value = 800800007  	 		 			 		 			 		 		  	   		   		 	
		              	ListRefP.add(Refcenter2)
                		
                		Dim Refcenter3 As New BIZ.Communication.RefParameetrs
                		Refcenter3.Name = "Center3"
                		
                			if tmpDistrict = 1 or tmpDistrict = 201  Then
		                		Refcenter3.Value = 910100001 
		                	ElseIf tmpDistrict = 2 or tmpDistrict = 202 Then
		                		Refcenter3.Value = 910200001 
		                	ElseIf tmpDistrict = 3 or tmpDistrict = 203 Then
		                		Refcenter3.Value = 910300001
		                	ElseIf tmpDistrict = 4 or tmpDistrict = 204 Then
		                		Refcenter3.Value = 910400001  	  	
		                	ElseIf tmpDistrict = 5 or tmpDistrict = 205 Then
		                		Refcenter3.Value = 910500001   	   		 	
		                	ElseIf tmpDistrict = 6 or tmpDistrict = 206 Then
		                		Refcenter3.Value = 910600001
		                	ElseIf tmpDistrict = 7 or tmpDistrict = 207 Then
		                		Refcenter3.Value = 910700001 
		                	ElseIf tmpDistrict = 8 or tmpDistrict = 208 Then
		                		Refcenter3.Value = 910800001   
		                	ElseIf tmpDistrict = 9 or tmpDistrict = 209 Then
                 				Refcenter3.Value = 910900001 
                 			ElseIf tmpDistrict = 10 or tmpDistrict = 210 Then
                 				Refcenter3.Value = 911000001 
                 			ElseIf tmpDistrict = 11 or tmpDistrict = 211 Then
                 				Refcenter3.Value = 911100001 
                 			ElseIf tmpDistrict = 12 or tmpDistrict = 212 Then
                 				Refcenter3.Value = 911200001 
                 			ElseIf tmpDistrict = 80 or tmpDistrict = 218 Then
                 				Refcenter3.Value = 911300001  	 		 			 		 			 		 		  	   		   		 	
		                	End if 	
                	       	ListRefP.add(Refcenter3)
                        
                        
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		               	RefFund.Value = 200888 
		                ListRefP.add(RefFund)
						
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
		                
		                
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
				
		                Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
                
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		              
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                Mess.ActTyp = 3
		                Mess.DocTyp = 12
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "باز افرینی"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			 
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""

               
                tmpstr = TmpDocument.Save(NidF)
                
               

              '  If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری  
                               
   ' Catch ex As Exception
 '       Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
  
  '  End Try
End Function

<DisplayName("تهاتر تک مبلغی")> Public Function Tahator1()
 
  '  Try
    
        
	
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                 Dim ExistRayvarz As Boolean =True
   
       
           If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup=157    Then  ExistRayvarz = False
		
           
              
              If ExistRayvarz = False Then
               
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                Dim a As Decimal = 0 ' = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                Dim BedeHiTmp As Decimal = 0 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable - Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Brokers 'Convert.ToDecimal(Info8.GetInstallment.Installment.CashPayment)
                
                
                '''''''''''''''''''New
                
               
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
				Dim  BedahiFAdd as Double=0
				BedahiFAdd=0 'BedeHi(DistrickBranch, Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo)
              '                
                ''''''''''''''''''new 

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
               
                Dim Ti As Integer
              
                		               
                If TmpDT.any() Then
                	
                
                        Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
                       
                        TmpOne.Price =(-1)* Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                        Dim TmpInComeCode = iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,200098,200099) 
                       
                        TmpOne.Price= (-1)* Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable ' 270919 TmpOne.Price
			         
			            TmpOne.WrapperAccountNo =TmpInComeCode.tostring ' iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,"200098","200099") 
			             Dim fileN = iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,4,2) 	
			            TmpOne.fileNo=fileN
			                a +=TmpOne.Price
			           
						 
                        Dim TmpIncomeCalculationDesc = "مبلغ تهاتر"
                        If TmpIncomeCalculationDesc = DBNull.Value.ToString Then
                            TmpOne.AccountNoComments = ""
                        Else
                            TmpOne.AccountNoComments = IIf(IsDBNull(TmpIncomeCalculationDesc), 0, TmpIncomeCalculationDesc)
                        End If
                        
                        If TmpOne.WrapperAccountNo <> 0 Then
                        
                         TmpAccounting_DocDetailsList.Add(TmpOne)
                        End if  

                End If
            
		
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		        DistrickBranch=tmpDistrict
		    	Select Case DistrickBranch
                    Case 1
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/08/26" Then 
	                		DistrickBranch = 201
	                	Else
	                    	DistrickBranch = 1
	                    End if	
                    Case 2
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1396/10/15" Then 
	                		DistrickBranch = 202
	                	Else
	                    	DistrickBranch = 2
	                    End if	
	                    
                    Case 3
                    	if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/04" Then 
	                		DistrickBranch = 203
	                	Else
	                    	DistrickBranch = 3
	                    End if
                        
                    Case 4
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/13" Then 
	                		DistrickBranch = 204
	                	Else
	                    	DistrickBranch = 4
	                    End if
                    Case 5
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/22" Then 
                    		DistrickBranch =205
	                    Else
	        				DistrickBranch = 5
		                End if	
                    Case 6
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/27" Then 
	                    	DistrickBranch =206
	                    Else
	        				DistrickBranch = 6
		                End if	
                    Case 7
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/03/31" Then 
	                    	DistrickBranch =207
	                    Else
	        				DistrickBranch = 7
		                End if	
                    Case 8
                         if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/07" Then 
	                     	DistrickBranch =208
	                     Else
	        				DistrickBranch = 8
		                 End if	
                    Case 9
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/04/28" Then 
	                     	DistrickBranch =209
	                     Else
	        				DistrickBranch = 9
		                 End if	
                    Case 10
                      if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/03" Then 
                     	DistrickBranch =210
                     Else
        				DistrickBranch = 10
	                 End if	
                    Case 11
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/07" Then 
	                     	DistrickBranch =211
	                     Else
	        				DistrickBranch = 11
		                 End if	
                    Case 12
                        if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/15" Then 
	                     	DistrickBranch =212
	                     Else
	        				DistrickBranch = 12
		                 End if	
                    Case 80
                       if BIZ.SA.ClsCommon.CurrentShamsiDateString>"1397/05/20" Then 
	                   	DistrickBranch =218
	                 Else
	        			DistrickBranch = 80
		             End if	
                End Select       
		    
		    
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
              
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = a
                    
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
                    Dim fileN = iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,4,2) 	
			        TmpDocDetails.fileNo=fileN
                   ' TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                   ' TmpDocDetails.BankCode =iif (CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)="",18 , CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) ) 
    			'	if TmpDocDetails.BankCode="" or TmpDocDetails.BankCode is Nothing Then  TmpDocDetails.BankCode= 18
     			
     			'SP 476244 -fj1403/09
     		
     		    if String.IsNullOrEmpty(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch) Then
     		        TmpDocDetails.BankCode =0
     		    Else
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                End if 
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
    			    'sp 395467  TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)

                   ' TmpChekNo = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
                 
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
			
                
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
               
                DtoAccounting_DocHeaderTotal.PhasType = 2
             
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
               ' Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &amp;  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
                
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
           
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                	'	logfilefj("RefRDD",RefRDD.Value)
                		ListRefP.add(RefRDD)
                  
                        
                        
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		     
						
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		                Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                'sp 441598
		                	'RefFund.Value = 44
		               		if DistrickBranch = 201 Then
		                		RefFund.Value = 51 '31 
		                	ElseIf DistrickBranch = 202 Then
		                		RefFund.Value = 52 
		                	ElseIf DistrickBranch = 203 Then
		                		RefFund.Value = 53
		                	ElseIf DistrickBranch = 204 Then
		                		RefFund.Value = 54  	  	
		                	ElseIf DistrickBranch = 205 Then
		                		RefFund.Value = 55   	   		 	
		                	ElseIf DistrickBranch = 206 Then
		                		RefFund.Value = 56
		                	ElseIf DistrickBranch = 207 Then
		                		RefFund.Value = 57 
		                 	ElseIf DistrickBranch = 208 Then
		                 		RefFund.Value = 58   
		                 	ElseIf DistrickBranch = 209 Then
                 				RefFund.Value = 59 
                 			ElseIf DistrickBranch = 210 Then
                 				RefFund.Value = 60 
                 			ElseIf DistrickBranch = 211 Then
                 				RefFund.Value = 61 
                 			ElseIf DistrickBranch = 212 Then
                 				RefFund.Value = 62 
                 			ElseIf DistrickBranch = 218 Then
                				RefFund.Value = 63
		                    End if 	
		         '           	logfilefj("RefFund",RefFund.Value)	
		                ListRefP.add(RefFund)
		                
						Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center"
                		if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank="2"  Then 
                			Refcenter.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CreditorPapers.tostring()
                		Else
                			Refcenter.Value ="0"
                		End if		
                	'	logfilefj("Refcenter",Refcenter.Value)	 		 			 		 		  	   		   		 	
		                ListRefP.add(Refcenter)
                        
                       
                         Dim Refcenter1 As New BIZ.Communication.RefParameetrs
                		Refcenter1.Name = "Center1"
                		Refcenter1.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).deposit			 		 		  	   		   		 	
		             '  	logfilefj("Refcenter1",Refcenter1.Value)
		               	ListRefP.add(Refcenter1)
                		
                	
                		
                	    Dim Refcenter3 As New BIZ.Communication.RefParameetrs
                		if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CheckNo="5" Then
                			Refcenter3.Name = "Center3"
                			Refcenter3.Value = "700100002" 
                		Else
                		
                			Refcenter3.Name = "Center3"
                			Refcenter3.Value = "700100001" 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Deposit   	
                		End if 
                		'	logfilefj("RefPRNRefcenter3Value",Refcenter3.Value)
                		ListRefP.add(Refcenter3)
						
						Dim RefPRN As New BIZ.Communication.RefParameetrs
		                RefPRN.Name = "Ref"
		                RefPRN.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).DepositID
		        '        logfilefj("RefPRN.Value",RefPRN.Value)
		                ListRefP.add(RefPRN) 
		                 
		                 
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 1
		                ListRefP.add(Refvchrtyp)
				
		                Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		         '       logfilefj("RefDUE.Value",RefDUE.Value)
		                ListRefP.add(RefDUE)
		                
		               ' Dim RefQTY   As New BIZ.Communication.RefParameetrs
		               ' RefQTY.Name = "QTY"
		               ' RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		               ' ListRefP.add(RefQTY)
		                
		               ' Dim RefNum As New BIZ.Communication.RefParameetrs
		               ' RefNum.Name = "Num"
		                'RefNum.Value = iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,4,2) 
		                'ListRefP.add(RefNum)
		                
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                 
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = 102 ' DistrickBranch
		               
		                Mess.ActTyp = 1
		                Mess.DocTyp = iif(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_Bank=4,14,15) 
		                Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد تهاتر مبلغ"  
		                Mess.DocTypDsc = "تهاتر مبلغ"
		                Mess.vchrtyp=1
                        TmpAccTotal.RayvarzMessage =Mess
                        '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)

                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		         FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)					
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""
                
                tmpstr = TmpDocument.Save(NidF)
                
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.Stop, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری  
 '  Catch ex As Exception
        'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message )
  '  End Try
End Function


 Public Function FnSMS(paramText As String)   ' ,totalPrice As Double
        Try
      

            ' SMS Content
            Dim tmpSMS As New BIZ.SC.SrvSMSService.ClsParameters
            tmpSMS.BizCode = "1-2-3-4"
            tmpSMS.Number = "09155193570"
            tmpSMS.ScheduleSendDate = "test"
            tmpSMS.SMSType = "TeSt"
            tmpSMS.Text = paramText
            tmpSMS.UserID = ""
            tmpSMS.UserName = ""

		'	Dim smsErrorResult as String
          Dim smsErrorResult As New BIZ.SA.ClsErrorResult      
                smsErrorResult = Info8.GetFunctions.SendSMS(tmpSMS)
             


        Catch ex As Exception
            Info8.AddError(BIZ.SA.EumErrorAction.Stop, "sms", ex.Message)
            Throw ex
        End Try
    End Function




'ExportPermanentDate>"1399/10/22" And ExportPermanentDate<"1399/12/11" ) And AddDateForHolidays(ExportPermanentDate, 10,1) >=bankPaymentdate 


Public Function AddDateForHolidays(ByVal DateTime As String, ByVal day As Integer,Optional ByVal aa As Integer = 0) As String


        Dim i As Integer = 0
        Dim RDate As String()
        Dim tmpday As String
        Dim tmpMonth As String
        Dim tmpYear As String
        Dim TmpD As String
        TmpD = DateTime

        Do While i < day
            RDate = TmpD.Split("/")
            tmpYear = RDate(0)
            tmpMonth = RDate(1)
            tmpday = RDate(2)

            if Convert.ToInt32(tmpday) + 1 > 31 And Convert.ToInt32(tmpMonth) < 7 Then
                tmpMonth = Convert.ToInt32(tmpMonth) + 1
                tmpday = Convert.ToInt32(tmpday) + 1 - 31
            ElseIf Convert.ToInt32(tmpday) + 1 > 30 And Convert.ToInt32(tmpMonth) > 6 And Convert.ToInt32(tmpMonth) <> 12 Then
                tmpMonth = Convert.ToInt32(tmpMonth) + 1
                tmpday = Convert.ToInt32(tmpday) + 1 - 30
            ElseIf Convert.ToInt32(tmpday) + 1 > 29 And Convert.ToInt32(tmpMonth) = 12 Then
                tmpMonth = 1
                tmpYear = Convert.ToInt32(tmpYear) + 1
                tmpday = Convert.ToInt32(tmpday) + 1 - 29
            Else

                tmpday = Convert.ToInt32(tmpday) + 1

            End If
            If tmpMonth.Length < 2 Then tmpMonth = "0" & tmpMonth.ToString

            If tmpday.Length < 2 Then tmpday = "0" & tmpday.ToString
             TmpD = tmpYear + "/" + tmpMonth + "/" + tmpday
            
            Dim LstHoliday As New List(Of Global.Biz.SA.SrvESUPService.HolidaysAndEvents)
          
          ' LstHoliday = Info8.GetFunctions.GetHolidays()

          
            'LstHoliday = LstHoliday.where(Function(f) f.HDate = TmpD).tolist
           ' If LstHoliday.Count =0 Then
             If Not  Info8.GetFunctions.GetHolidays_ByDate(TmpD) Then  i = i + 1
        Loop
        
'''''تبدیل به میلادی
		Dim RDateMilady As String()
		RDateMilady=TmpD.Split("/")
        tmpYear = RDateMilady(0)
        tmpMonth = RDateMilady(1)
        tmpday = RDateMilady(2)
        Dim tmpPersianCalender = New System.Globalization.PersianCalendar()
        Dim dt As DateTime
        dt = New DateTime(Convert.ToInt32(tmpYear), Convert.ToInt32(tmpMonth),  Convert.ToInt32(tmpday), tmpPersianCalender)
                  
        if aa=1 Then Return TmpD
        
        Return dt
    End Function
    
    <DisplayName("بهای هوشمندسازی خدمات شهری")> Public Function IncomeHoushmand()
 
   Try
        
 
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                Dim ExistRayvarz As Boolean =True
   				
        		Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		    	
             
                 
           if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =163  Then  ExistRayvarz = False

                 'SP516174  682
                DistrickBranch =682   '780 '382 ' 682  '382 '
                 
              If ExistRayvarz = False Then
                
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
			

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
                
                Dim Ti As Integer
         

    
		            Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
		            Dim Tmp_Price as Double
		            
		          				               
		            Tmp_Price	=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable/1.1			               
		            TmpOne.Price =math.round(Tmp_Price,0)  '309337   '308718
		           
		            TmpOne.WrapperAccountNo = 401312100  '''308718  229091300  ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
				                
				    Dim TmpIncomeCalculationDesc = "بهای هوشمندسازی خدمات شهری"
		            TmpOne.AccountNoComments = TmpIncomeCalculationDesc
		            If TmpOne.WrapperAccountNo <> 0 Then
		               TmpAccounting_DocDetailsList.Add(TmpOne)
		           End if  
		           
		            Dim TmpOne2 As New BIZ.Communication.DataAccess.Accounting_DocDetails
		            				               
		            TmpOne2.Price = math.round(Tmp_Price*0.1,0)   '309337   '308718
		           
		            TmpOne2.WrapperAccountNo =206098003 ' 206980030  '''308718  229091300  ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
				                
				    TmpIncomeCalculationDesc = "ارزش افزوده"
		            TmpOne2.AccountNoComments = TmpIncomeCalculationDesc
		            If TmpOne2.WrapperAccountNo <> 0 Then
		               TmpAccounting_DocDetailsList.Add(TmpOne2)
		           End if  
           
       
			
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                
		    
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = TmpAccounting_DocDetailsList(TTj).Price  '309337   '308718
                    'TmpDocDetails.FileNo=5
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
        
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
               
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable  '309337
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                 
                DtoAccounting_DocHeaderTotal.PhasType = 7'309337
             
              
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
               
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
            
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = 0
                		ListRefP.add(Refcenter)
                        
                    
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		              Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                RefFund.Value = 200682010
		                ListRefP.add(RefFund)
		
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
						
								
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
				
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
						
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                'Mess.District = DistrickBranch
		                Mess.ActTyp = 3
		                Mess.DocTyp = 3
		                Mess.vchrtyp=0
		                 Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = "بهای هوشمندسازی خدمات شهری"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
		               
		                '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""

              
                tmpstr = TmpDocument.Save(NidF)
                
       
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری                               
    Catch ex As Exception
     'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
    End Try
End Function

   <DisplayName("خدمات سرويس هاي الكترونيك شهرداري")> Public Function IncomeSrvElectronic()
 
   Try
        
 
		Dim NidF as String =""
        Dim TmpChekNo As Integer = 0 '20

       		NidF=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche.tostring
       	

       
            Dim NidIns As String= " "
            Dim ListRefP As New List(Of BIZ.Communication.RefParameetrs)

           
                Dim PParamName As New List(Of String)
                Dim PParamValue As New List(Of String)

                Dim DistrickBranch As Integer = 0

                Dim PtmpDistrict As String = Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).BillID.Substring(8, 3)

                
                
                Dim ExistRayvarz As Boolean =True
   				
        		Dim strCodeNew as String
	      		Dim tmpDistrict as Integer=0
	      
				strCodeNew = Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		    	tmpDistrict =  strCodeNew.Split("-")(0)
		    	
             
                 
           if Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).CI_IncomeAccountGroup =164  Then  ExistRayvarz = False

                 
                DistrickBranch = 682  '780 '382 ' 682  '382 ' 'SP516174
                 
              If ExistRayvarz = False Then
                
               If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable > 0 Then

 
                Dim TmpAccounting_DocDetailsList As New List(Of BIZ.Communication.DataAccess.Accounting_DocDetails)
                Dim TmpDT As List(Of DtoSC.Income_Calculation)

                Dim IncomeDisc As List(Of DtoSC.Income_Discount)
                IncomeDisc = Info8.GetIncome.GetIncome_Discount

                
                
                '''''''''''''''''''New
                
                
                	Dim Tj As Integer = 0
 					Dim yy As Integer = 1
 					Dim TmpAccounting_DocDetailsListTotal As New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                ''''''''''''''''''''''''''''''
			

                TmpDT = Info8.GetIncome.GetIncome_Calculation_InNidIncome(Info8.GetAccountingDocCreateParameter().IncomeFicheList(0).NidIncome)
                
               Dim TmpImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup)
               Dim ImcomeAccontGroup As New List(Of DtoSC.ADP_IncomeAccountGroup) 
               ImcomeAccontGroup= Info8.GetIncome.GetADP_IncomeAccountGroup
               
                
                Dim Ti As Integer
         

    
		            Dim TmpOne As New BIZ.Communication.DataAccess.Accounting_DocDetails
		            Dim Tmp_Price as Double
		            
		          				               
		            Tmp_Price	=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable		               
		            TmpOne.Price =math.round(Tmp_Price,0)  '309337   '308718
		           
		            TmpOne.WrapperAccountNo = 401312100  '''308718  229091300  ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
				                
				    Dim TmpIncomeCalculationDesc = "بهاي خدمات سرويس هاي الكترونيك شهرداري"
		            TmpOne.AccountNoComments = TmpIncomeCalculationDesc
		            If TmpOne.WrapperAccountNo <> 0 Then
		               TmpAccounting_DocDetailsList.Add(TmpOne)
		           End if  
		           
		           Dim TmpOne2 As New BIZ.Communication.DataAccess.Accounting_DocDetails
		            				               
		            TmpOne2.Price = math.round(Tmp_Price*0.1,0)   '309337   '308718
		           
		            TmpOne2.WrapperAccountNo =206098003 ' 206980030  '''308718  229091300  ' IIf(IsDBNull(TmpInComeCode), 0, TmpInComeCode)
				                
				    TmpIncomeCalculationDesc = "ارزش افزوده"
		            TmpOne2.AccountNoComments = TmpIncomeCalculationDesc
		            If TmpOne2.WrapperAccountNo <> 0 Then
		               TmpAccounting_DocDetailsList.Add(TmpOne2)
		           End if  
           
       
			
                '--------------------------------------------'---------------------
                Dim TmpChek As Integer = 0                
                Dim TTj As Integer = 0
                Dim TmpDocument As New BIZ.Communication.ClsAccounting
                Dim tmpdate As String = ""
                
		    
                Dim DtoAccounting_DocHeaderTotal As New Biz.Communication.DataAccess.Accounting_DocHeader
				DtoAccounting_DocHeaderTotal.NidFiche = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).NidFiche
                For TTj = 0 To TmpAccounting_DocDetailsList.count - 1

                    Dim TmpDocDetails As New BIZ.Communication.DataAccess.Accounting_DocDetails
                    TmpDocDetails.Price = TmpAccounting_DocDetailsList(TTj).Price  '309337   '308718
                    'TmpDocDetails.FileNo=5
                    TmpDocDetails.WrapperAccountNo = TmpAccounting_DocDetailsList(TTj).WrapperAccountNo
                    TmpDocDetails.AccountNoComments = TmpAccounting_DocDetailsList(TTj).AccountNoComments
                    TmpDocDetails.FicheNo =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Ficheno.tostring
                    TmpDocDetails.BillID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID.tostring
                    TmpDocDetails.PaymentID =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID.tostring
        
     				TmpDocDetails.BankCode = CStr(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentBranch)
                    if CStr(TmpDocDetails.BankCode)=""  Then  TmpDocDetails.BankCode= 18
     				TmpChekNo= CStr(TmpDocDetails.BankCode)
					
					If Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).eumFichestatus = 3 Then
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
                	Else
                    	tmpdate = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                	End If
 
                  
                    TmpDocDetails.PaymentDate =ChangeDate(tmpdate) 'Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
                    
                    TmpDocDetails.IncmRow = YY
                    TmpDocDetails.AccountNo = strCodeNew 'Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)

                    If TmpDocDetails.Price <> 0 Then
                   
                        TmpAccounting_DocDetailsListTotal.Add(TmpDocDetails)
                        yy += 1
                    End If
                Next
               
                Dim Puser As String = "7332DA55-0A3F-446B-8103-E71BACB5B969"
				
               
                DtoAccounting_DocHeaderTotal.DocRow = TmpChek + 1
                
                
                DtoAccounting_DocHeaderTotal.SaraPrice = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable  '309337
                
                
                DtoAccounting_DocHeaderTotal.FicheNo =  Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(BIZ.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)

                DtoAccounting_DocHeaderTotal.EumObjOnPrice = CByte(Info8.GetAccountingDocCreateParameter.ObjOnPrice)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingObjInDocument = CByte(Biz.SA.ClsEnum.EumAccountingObjInDocument.Fiche)
                
                
                DtoAccounting_DocHeaderTotal.EumAccountingDocumentingCause = CByte(Biz.SA.ClsEnum.EumAccountingDocumentingCause.Confirm)
                
                 
                DtoAccounting_DocHeaderTotal.PhasType = 7'309337
             
              
                Dim TmpAccTotal As New Biz.Communication.ClsAccountingDocMessage

                TmpAccTotal.Accounting_DocHeader = DtoAccounting_DocHeaderTotal

                TmpAccTotal.Accounting_DocDetailList = New List(Of Biz.Communication.DataAccess.Accounting_DocDetails)
                
              '  Info8.AddError(BIZ.SA.EumErrorAction.Stop, DtoAccounting_DocHeaderTotal.SaraPrice, "aa_11" &  TmpAccounting_DocDetailsListTotal.sum(Function(f) f.Price))
               
                TmpAccTotal.Accounting_DocDetailList = TmpAccounting_DocDetailsListTotal
                ''''''''''''''''''New 
            
                        Dim RefRDD As New BIZ.Communication.RefParameetrs
                		RefRDD.Name = "RefownrDsc"
                		RefRDD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo   '99845 TmpDate
                		ListRefP.add(RefRDD)
            
                        Dim Refcenter As New BIZ.Communication.RefParameetrs
                		Refcenter.Name = "Center1"
                		Refcenter.Value = 0
                		ListRefP.add(Refcenter)
                        
                    
		               	Dim RefNo As New BIZ.Communication.RefParameetrs
                		RefNo.Name = "RefReconstructionNo"
                		RefNo.Value = Info8.GetRequest.Info.NidWorkItem   '93883 TmpDate
                		ListRefP.add(RefNo)
                	
                		Dim RefP As New BIZ.Communication.RefParameetrs
		                RefP.Name = "DocDate"
		                RefP.Value =ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString)  '99433 TmpDate
		                ListRefP.add(RefP)
		
		                Dim RefPR As New BIZ.Communication.RefParameetrs
		                RefPR.Name = "RowDate"
		                RefPR.Value =ChangeDate(TmpDate)
		                ListRefP.add(RefPR)
		
		                Dim RefPRD As New BIZ.Communication.RefParameetrs
		                RefPRD.Name = "RowDocNo"
		                RefPRD.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		                ListRefP.add(RefPRD)
		
		              Dim RefFund As New BIZ.Communication.RefParameetrs
		                RefFund.Name = "Fund"
		                RefFund.Value = 200682010
		                ListRefP.add(RefFund)
		
						
						Dim RefP0 As New BIZ.Communication.RefParameetrs
		                RefP0.Name = "Ref"
		                RefP0.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).ficheno
		                ListRefP.add(RefP0)
						
								
						Dim Refvchrtyp  As New BIZ.Communication.RefParameetrs
		                Refvchrtyp.Name = "vchrtyp"
		                Refvchrtyp.Value = 0
		                ListRefP.add(Refvchrtyp)
				
						Dim RefDUE  As New BIZ.Communication.RefParameetrs
		                RefDUE.Name = "DUE"
		                RefDUE.Value = ChangeDate(BIZ.SA.ClsCommon.CurrentShamsiDateString) 
		                ListRefP.add(RefDUE)
		                
		                Dim RefQTY   As New BIZ.Communication.RefParameetrs
		                RefQTY.Name = "QTY"
		                RefQTY.Value = Convert.ToDecimal(Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).Payable)
		                ListRefP.add(RefQTY)
						
		                Dim RefPR2 As New BIZ.Communication.RefParameetrs
		                RefPR2.Name = "Ref2"
		                RefPR2.Value = Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		                ListRefP.add(RefPR2)
		                Dim RefPR3 As New BIZ.Communication.RefParameetrs
		                RefPR3.Name = "Ref3"
		                RefPR3.Value =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).paymentid
		                ListRefP.add(RefPR3)
		
		                Dim RefP6 As New BIZ.Communication.RefParameetrs
		                RefP6.Name = "Ref6"
		                RefP6.Value = NidIns
		                ListRefP.add(RefP6)
		                 
		               
		
		                Dim Mess As New BIZ.Communication.ClsRayvarzMessageContract
		                
		
		                Mess.RefParameterList = ListRefP
		                
		                Mess.District = DistrickBranch
		               
		               
		                'Mess.District = DistrickBranch
		                Mess.ActTyp = 3
		                Mess.DocTyp = 3
		                Mess.vchrtyp=0
		                 Mess.IncmMkrTyp = 1
		                Mess.docdsc="اسناد شهرسازی"  
		                Mess.DocTypDsc = " بهاي خدمات سرويس هاي الكترونيك شهرداري"
		                Mess.vchrtyp=0
                        TmpAccTotal.RayvarzMessage =Mess
		               
		                '''''''''''''''''''''''''
                        Dim ListAcc As New List(Of Biz.Communication.ClsAccountingDocMessage)
                ListAcc.Add(TmpAccTotal)
			
                 Dim FicheInfo As New Global.Biz.Communication.ClsDocFichInfoDto
		        FicheInfo.BankPaymentDate =Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BankPaymentDate
		        FicheInfo.BillID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).BillID
		        FicheInfo.EumObjOnPrice=Info8.GetAccountingDocCreateParameter.ObjOnPrice
		        FicheInfo.FicheNo=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).FicheNo
		        FicheInfo.NosaziCodeStr=Info8.GetFunctions.GetNosaziNickName(Info8.GetRequest.Info.NidNosaziCode)
		        FicheInfo.District=FicheInfo.NosaziCodeStr.Split("-")(0)
		        FicheInfo.PaymentDate=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentDate
		        FicheInfo.PaymentID=Info8.GetAccountingDocCreateParameter.IncomeFicheList(0).PaymentID
		       
		        TmpDocument.FicheInfo = New Global.Biz.Communication.ClsDocFichInfoDto
		        TmpDocument.FicheInfo = FicheInfo

                TmpDocument.Accounting_Doc = New List(Of Biz.Communication.ClsAccountingDocMessage)
                TmpDocument.Accounting_Doc = ListAcc


                Dim tmpstr As String = ""

              
                tmpstr = TmpDocument.Save(NidF)
                
       
                If tmpstr <> "" Then Info8.AddError(BIZ.SA.EumErrorAction.warning, "tmpstr", tmpstr.tostring)
            End If
        End If '  عدم تکراری                               
    Catch ex As Exception
     'Info8.AddError(BIZ.SA.EumErrorAction.Stop, "cتوجه", "اشکال در ارسال به رایورز" + ex.Message)
    End Try
End Function



