@echo off
cd /d "%~dp0"
echo RayvarzResend v34 — نسخه آخر (PR #116 — مرکز هزینه)
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
