نسخه لوکال — بدون Publish

این بسته برای اجرای مستقیم با dotnet run است.

پیش‌نیاز:
- .NET 8 SDK
- SQL Server با HRPerformanceDB

مراحل:
1) اسکریپت‌های database/01 تا 10
2) ویرایش src/HRPerformance.API/appsettings.Development.json
3) start-local.bat

سینک MIS:
POST /api/attendancesync/run
GET /api/attendancesync/diagnostic
