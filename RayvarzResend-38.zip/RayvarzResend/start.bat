@echo off
cd /d "%~dp0"
echo RayvarzResend v38 — نسخه آخر (تهاتر 158 — CI_IncomeCalculation)
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
