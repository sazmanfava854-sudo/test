RayvarzResend v26 — نسخه DEBUG (غیر پابلیش)

- Build: Debug + فایل .pdb (اتصال Visual Studio / dnSpy)
- appsettings: LogLevel=Debug, Auth:Shimas:DebugSigning=true
- start-debug.bat را اجرا کنید (نه start.bat نسخه Release)

APIهای SSO (مرورگر یا curl):
  GET /api/auth/sso-outbound-map
  GET /api/auth/sso-signing-preview
  GET /api/auth/sso-loginkey-check
  GET /api/auth/sso-loginkey-probe
  GET /api/auth/sso-loginkey-probe?apiName=...&clientId=...&secret=...  (فقط دیباگ محلی)

ورود با دیباگ:
  /auth/login?debug=1

اسکریپت curl (کنار exe):
  run-sso-loginkey-curl-only.cmd -SecretKey ... -ProbeSwaps
