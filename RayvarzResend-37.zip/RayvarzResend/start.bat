@echo off
cd /d "%~dp0"
echo RayvarzResend v37 — نسخه آخر (بارگذاری Accounting_DocDetails + تهاتر IncomeCode)
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
