@echo off
cd /d "%~dp0"
echo RayvarzResend v41 — چک رایورز + Accounting_DocHeader قبل از ارسال
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
