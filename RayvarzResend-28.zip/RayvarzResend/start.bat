@echo off
cd /d "%~dp0"
echo RayvarzResend v28 — نسخه آخر (PR #115)
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
