let currentFiche = null;
let config = null;
let currentUser = null;
let authMode = null;
let unsentItems = [];
const selectedUnsentFicheNos = new Set();
/** @type {Map<string, string>} ficheNo → Income | Duty */
const unsentSourceKindByFicheNo = new Map();
const unsentSearchState = {
  page: 1,
  pageSize: 25,
  totalCount: 0,
  totalPages: 0,
  filters: null
};

const $ = (id) => document.getElementById(id);

let appToastTimer = null;

function hideAppMessage() {
  const host = $('appToastHost');
  if (!host) return;
  host.innerHTML = '';
  if (appToastTimer) {
    clearTimeout(appToastTimer);
    appToastTimer = null;
  }
}

function showAppMessage(message, type = 'info', { timeout = 9000 } = {}) {
  const host = $('appToastHost');
  if (!host || !message) return;

  hideAppMessage();

  const toast = document.createElement('div');
  toast.className = `app-toast app-toast-${type}`;
  toast.setAttribute('role', type === 'error' ? 'alert' : 'status');

  const text = document.createElement('span');
  text.className = 'app-toast-text';
  text.textContent = message;

  const closeBtn = document.createElement('button');
  closeBtn.type = 'button';
  closeBtn.className = 'app-toast-close';
  closeBtn.setAttribute('aria-label', 'بستن');
  closeBtn.textContent = '×';
  closeBtn.addEventListener('click', hideAppMessage);

  toast.appendChild(text);
  toast.appendChild(closeBtn);
  host.appendChild(toast);

  if (timeout > 0) {
    appToastTimer = setTimeout(hideAppMessage, timeout);
  }
}

function showAppSuccess(message, options) {
  showAppMessage(message, 'success', options);
}

function showAppError(message, options) {
  showAppMessage(message, 'error', { timeout: 12000, ...options });
}

function showAppWarning(message, options) {
  showAppMessage(message, 'warning', options);
}

function showAppInfo(message, options) {
  showAppMessage(message, 'info', options);
}

window.showAppSuccess = showAppSuccess;
window.showAppError = showAppError;
window.showAppWarning = showAppWarning;

const categoryLabels = {
  Income: 'درآمد',
  DutyNosazi: 'نوسازی',
  DutySenfi: 'صنفی',
  Unknown: 'نامشخص'
};

function branchFromRegion(regionStr) {
  const r = parseInt(regionStr, 10);
  if (Number.isNaN(r)) return null;
  if (r === 102) return 102;
  if (r === 218 || r === 80) return 218;
  if (r >= 1 && r <= 12) return 200 + r;
  if (r >= 201 && r <= 212) return r;
  return null;
}

/** همان منطق تب تکی: branch ۲۰۱–۲۱۲ / ۲۱۸ → منطقه ۱–۱۲ / ۲۱۸ برای فیلتر SQL */
const FAVA_DISTRICT_VALUE = 'fava';

function branchIdToDistrict(branchId) {
  const raw = String(branchId ?? '').trim();
  if (raw === FAVA_DISTRICT_VALUE) return FAVA_DISTRICT_VALUE;
  const id = parseInt(raw, 10);
  if (!id) return '';
  if (id === 102) return '102';
  if (id === 218) return '218';
  if (id >= 201 && id <= 212) return String(id - 200);
  if (id >= 1 && id <= 12) return String(id);
  return '';
}

/** پر کردن کمبو منطقه/شعبه از config.branches — مشترک بین ارسال تکی و دسته‌ای */
function fillBranchSelect(selectEl, { includeAll = false, allLabel = 'همه مناطق', restrictToDistrict = null } = {}) {
  if (!selectEl || !config?.branches) return;
  selectEl.innerHTML = '';
  if (includeAll) {
    const all = document.createElement('option');
    all.value = '';
    all.textContent = allLabel;
    selectEl.appendChild(all);
  }
  const restrict = restrictToDistrict ? String(restrictToDistrict) : '';
  if (includeAll || selectEl.id === 'newUserDistrict') {
    const fava = document.createElement('option');
    fava.value = FAVA_DISTRICT_VALUE;
    fava.textContent = 'فاوا (پشتیبانی — همه شعب)';
    selectEl.appendChild(fava);
  }
  config.branches.forEach((b) => {
    if (restrict) {
      const dist = branchIdToDistrict(String(b.id));
      if (dist !== restrict) return;
    }
    const opt = document.createElement('option');
    opt.value = b.id;
    opt.textContent = b.name;
    selectEl.appendChild(opt);
  });
}

function getUserDistrict() {
  const d = currentUser?.district;
  return d == null || d === '' ? '' : String(d);
}

function applyRegionalUserRestrictions() {
  if (isAdminUser()) {
    fillBranchSelect($('branch'));
    $('branch')?.removeAttribute('disabled');
    $('fund')?.removeAttribute('disabled');
    syncFundFromBranch();
    return;
  }

  if (getUserDistrict() === FAVA_DISTRICT_VALUE) {
    fillBranchSelect($('branch'));
    $('branch')?.removeAttribute('disabled');
    $('fund')?.removeAttribute('disabled');
    syncFundFromBranch();
    return;
  }

  const district = getUserDistrict();
  fillBranchSelect($('branch'), { restrictToDistrict: district || '__none__' });
  const branchId = district ? branchFromRegion(district) : null;
  if (branchId) {
    $('branch').value = branchId;
    $('branch').disabled = true;
    if (branchId !== 102) syncFundFromBranch();
    $('fund').disabled = true;
  }
}

function fillFundSelect(selectEl) {
  if (!selectEl || !config?.branches) return;
  selectEl.innerHTML = '';
  config.branches.forEach((b) => {
    if (!b.fund || Number(b.fund) <= 0) return;
    const opt = document.createElement('option');
    opt.value = b.fund;
    opt.textContent = `${b.fund} — ${b.name}`;
    selectEl.appendChild(opt);
  });
}

function applyOperatorFund(f) {
  const branchId = parseInt($('branch').value, 10);
  const mapped = config.branches.find((b) => b.id === branchId);
  const districtFund = mapped && Number(mapped.fund) > 0 ? Number(mapped.fund) : 0;
  const suggested = Number(f?.suggestedFund || 0);
  const districtFunds = new Set(
    (config.branches || []).filter((b) => Number(b.fund) > 0).map((b) => Number(b.fund))
  );
  if (suggested > 0 && !districtFunds.has(suggested) && suggested !== districtFund) {
    setFundValue(suggested);
    return;
  }
  if (districtFund > 0) {
    setFundValue(districtFund);
    return;
  }
  if (suggested > 0) setFundValue(suggested);
}

function setFundValue(fund) {
  const sel = $('fund');
  if (!sel || fund == null || fund === '' || Number(fund) <= 0) return false;
  const value = String(fund);
  if (![...sel.options].some((o) => o.value === value)) {
    const opt = document.createElement('option');
    opt.value = value;
    const mapped = (config.branches || []).find((b) => String(b.fund) === value);
    opt.textContent = mapped ? `${mapped.fund} — ${mapped.name}` : value;
    sel.appendChild(opt);
  }
  sel.value = value;
  return sel.value === value;
}

function applyBranchFromFiche(f) {
  if (f.resolvedDistrictBranch) {
    const branchId = f.resolvedDistrictBranch;
    const match = config.branches.find(b => b.id === branchId);
    if (match) {
      $('branch').value = branchId;
      applyOperatorFund(f);
      return true;
    }
  }
  const region = f.dutyRegion || f.incomeRegion;
  const branchId = region ? branchFromRegion(region) : null;
  if (!branchId) {
    applyOperatorFund(f);
    return false;
  }
  const match = config.branches.find(b => b.id === branchId);
  if (!match) {
    applyOperatorFund(f);
    return false;
  }
  $('branch').value = branchId;
  applyOperatorFund(f);
  return true;
}

function syncFundFromBranch() {
  const branchId = parseInt($('branch').value);
  const item = config.branches.find(b => b.id === branchId);
  if (item && Number(item.fund) > 0) $('fund').value = String(item.fund);
}

function syncBranchFromFund() {
  const fund = parseInt($('fund').value);
  const item = config.branches.find(b => b.fund === fund);
  if (item) $('branch').value = item.id;
}

function formatShamsiDisplay(yyyymmdd) {
  if (!yyyymmdd) return '-';
  const d = String(yyyymmdd).replace(/\D/g, '');
  if (d.length < 8) return toPersianDigits(String(yyyymmdd));
  return toPersianDigits(`${d.slice(0, 4)}/${d.slice(4, 6)}/${d.slice(6, 8)}`);
}

function formatBillPayDisplay(value) {
  const digits = normalizeDigits(String(value ?? '').trim()).replace(/\D/g, '');
  if (!digits) return '-';
  return toPersianDigits(digits);
}

function clearGridSelection(selectionSet, cacheMap) {
  selectionSet.clear();
  if (cacheMap) cacheMap.clear();
}

let activeMainTabKey = null;

function clearFieldValue(id) {
  const el = $(id);
  if (!el) return;
  if (el.type === 'checkbox' || el.type === 'radio') el.checked = false;
  else if (el.type === 'file') el.value = '';
  else if (el.tagName === 'SELECT') el.selectedIndex = 0;
  else el.value = '';
}

function hideEl(id) {
  const el = $(id);
  if (el) el.hidden = true;
}

function resetMainTabPanelState(tabKey) {
  if (!tabKey) return;
  switch (tabKey) {
    case 'unsent':
      ['unsentFromDate', 'unsentToDate', 'unsentFicheNo', 'unsentBillId', 'unsentPaymentId'].forEach(clearFieldValue);
      if ($('unsentDistrict')) $('unsentDistrict').value = '';
      clearFieldValue('unsentExcelFile');
      setUnsentExcelStatus('فایل اکسل انتخاب نشده');
      clearGridSelection(selectedUnsentFicheNos, null);
      unsentSourceKindByFicheNo.clear();
      unsentSearchState.page = 1;
      unsentSearchState.totalCount = 0;
      unsentSearchState.totalPages = 0;
      renderUnsentTable([], { page: 1, pageSize: unsentSearchState.pageSize, totalCount: 0, totalPages: 0 });
      hideEl('unsentResultsSection');
      hideEl('unsentPagination');
      hideEl('unsentResultBox');
      clearFieldValue('identifierValue');
      hideEl('ficheSection');
      hideEl('resultSection');
      hideEl('sendResultCard');
      if ($('btnSend')) $('btnSend').disabled = true;
      break;
    case 'installment':
      clearFieldValue('installmentValues');
      clearFieldValue('installmentApplyEndState');
      clearFieldValue('installmentApplyEndStateExcel');
      clearFieldValue('installmentExcelFile');
      if ($('installmentExcelStatus')) $('installmentExcelStatus').textContent = 'فایلی انتخاب نشده';
      hideEl('installmentPreviewSection');
      hideEl('installmentResultBox');
      {
        const tbody = $('installmentPreviewTable')?.querySelector('tbody');
        if (tbody) tbody.innerHTML = '';
      }
      if ($('installmentPreviewSummary')) $('installmentPreviewSummary').textContent = '';
      if ($('btnInstallmentUpdate')) $('btnInstallmentUpdate').disabled = true;
      break;
    case 'ficheDate':
      clearFieldValue('ficheDateIdentifier');
      ['ficheDatePermanentFrom', 'ficheDatePermanentTo', 'ficheDateTemporaryFrom', 'ficheDateTemporaryTo',
        'ficheDateNewPermanent', 'ficheDateNewTemporary', 'ficheDateNewBreak'].forEach(clearFieldValue);
      ['ficheDateApplyPermanent', 'ficheDateApplyTemporary', 'ficheDateApplyBreak', 'ficheDateApplyStatus', 'ficheDateSelectAll']
        .forEach(clearFieldValue);
      clearGridSelection(selectedFicheDateNos, ficheDateSelectedItems);
      ficheDateSearchState.page = 1;
      ficheDateSearchState.totalCount = 0;
      ficheDateSearchState.totalPages = 0;
      renderFicheDateTable([], { page: 1, pageSize: ficheDateSearchState.pageSize, totalCount: 0, totalPages: 0 });
      hideEl('ficheDateResultsSection');
      hideEl('ficheDatePagination');
      hideEl('ficheDateResultBox');
      if (typeof syncFicheDateApplyFields === 'function') syncFicheDateApplyFields();
      break;
    case 'bankInquiry':
      ['bankInquiryFicheNo', 'bankInquiryBillId', 'bankInquiryPaymentId', 'bankInquiryNewPaymentDate'].forEach(clearFieldValue);
      clearFieldValue('bankInquirySelectAll');
      clearGridSelection(selectedBankInquiryNos, bankInquirySelectedItems);
      bankInquirySearchState.page = 1;
      bankInquirySearchState.totalCount = 0;
      bankInquirySearchState.totalPages = 0;
      renderBankInquiryTable([], { page: 1, pageSize: bankInquirySearchState.pageSize, totalCount: 0, totalPages: 0 });
      hideEl('bankInquiryResultsSection');
      hideEl('bankInquiryPagination');
      hideEl('bankInquiryApplySection');
      hideEl('bankInquiryResultBox');
      hideEl('bankInquiryDiagnoseBox');
      break;
    case 'costCenter':
      clearFieldValue('costCenterFicheNo');
      clearFieldValue('costCenterOne');
      clearFieldValue('costCenterTwo');
      clearFieldValue('costCenterSelectAll');
      clearGridSelection(selectedCostCenterNos, costCenterSelectedItems);
      costCenterSearchState.page = 1;
      costCenterSearchState.totalCount = 0;
      costCenterSearchState.totalPages = 0;
      renderCostCenterTable([], { page: 1, pageSize: costCenterSearchState.pageSize, totalCount: 0, totalPages: 0 });
      hideEl('costCenterResultsSection');
      hideEl('costCenterPagination');
      hideEl('costCenterApplySection');
      hideEl('costCenterResultBox');
      break;
    case 'shahkar':
      ['shahkarUserName', 'shahkarNationalCode'].forEach(clearFieldValue);
      clearFieldValue('shahkarSelectAll');
      clearGridSelection(selectedShahkarUserNames, shahkarSelectedItems);
      renderShahkarTable([]);
      hideEl('shahkarResultsSection');
      hideEl('shahkarResultBox');
      break;
    case 'users':
      if (typeof resetGroupForm === 'function') resetGroupForm();
      if (typeof closeUserEdit === 'function') closeUserEdit();
      hideEl('usersResultBox');
      break;
    default:
      break;
  }
}

function setGridRowSelected(selectionSet, cacheMap, item, selected) {
  if (!item?.ficheNo) return;
  if (selected) {
    selectionSet.add(item.ficheNo);
    if (cacheMap) cacheMap.set(item.ficheNo, item);
  } else {
    selectionSet.delete(item.ficheNo);
    if (cacheMap) cacheMap.delete(item.ficheNo);
  }
}

function setupMainTabs() {
  const tabs = document.querySelectorAll('.main-tab');
  const panels = {
    unsent: $('tabUnsent'),
    installment: $('tabInstallment'),
    ficheDate: $('tabFicheDate'),
    bankInquiry: $('tabBankInquiry'),
    costCenter: $('tabCostCenter'),
    shahkar: $('tabShahkar'),
    users: $('tabUsers')
  };

  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      const key = tab.dataset.tab;
      if (tab.hidden) return;
      activateMainTab(key, tabs, panels);
    });
  });
}

function activateMainTab(key, tabs = document.querySelectorAll('.main-tab'), panels = {
  unsent: $('tabUnsent'),
  installment: $('tabInstallment'),
  ficheDate: $('tabFicheDate'),
  bankInquiry: $('tabBankInquiry'),
  costCenter: $('tabCostCenter'),
  shahkar: $('tabShahkar'),
  users: $('tabUsers')
}) {
  if (activeMainTabKey && activeMainTabKey !== key) {
    resetMainTabPanelState(activeMainTabKey);
  }
  activeMainTabKey = key;

  tabs.forEach((t) => {
    const active = t.dataset.tab === key && !t.hidden;
    t.classList.toggle('active', active);
    t.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  Object.entries(panels).forEach(([name, panel]) => {
    if (!panel) return;
    const show = name === key;
    panel.hidden = !show;
    panel.classList.toggle('active', show);
  });
}

function getSingleFicheKind() {
  return $('singleFicheKind')?.value || 'Income';
}

let rayvarzSendMode = 'single';

function setRayvarzSendMode(mode) {
  if (mode === 'bulk' && !canAccessUnsent()) mode = 'single';
  rayvarzSendMode = mode === 'bulk' ? 'bulk' : 'single';
  document.querySelectorAll('[data-rayvarz-mode]').forEach((btn) => {
    const active = btn.dataset.rayvarzMode === rayvarzSendMode;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  const singlePanel = $('rayvarzSinglePanel');
  const bulkPanel = $('rayvarzBulkPanel');
  if (singlePanel) singlePanel.hidden = rayvarzSendMode !== 'single';
  if (bulkPanel) bulkPanel.hidden = rayvarzSendMode !== 'bulk';
  if (rayvarzSendMode === 'bulk') {
    $('ficheSection')?.setAttribute('hidden', '');
    $('resultSection')?.setAttribute('hidden', '');
  }
}

const installmentLookupLabels = {
  NoDocument: 'شماره سند',
  TrackingNo: 'کد پیگیری'
};

let installmentMode = 'single';
let installmentExcelRows = [];

const ficheDateStatusLabels = {
  0: 'صدورموقت',
  1: 'صدوردایم',
  2: 'چاپ',
  3: 'تایید دستی/لحظه‌ای بانک',
  4: 'ابطال',
  5: 'تایید بانک'
};

const ficheDateStatusOrder = [0, 1, 2, 3, 4, 5];

let ficheDateItems = [];
const selectedFicheDateNos = new Set();
const ficheDateSelectedItems = new Map();
const ficheDateSearchState = {
  page: 1,
  pageSize: 25,
  totalCount: 0,
  totalPages: 0
};

function getInstallmentApplyEndState() {
  if (installmentMode === 'excel') {
    return !!$('installmentApplyEndStateExcel')?.checked;
  }
  return !!$('installmentApplyEndState')?.checked;
}

function syncInstallmentOdooatCheckboxes(source) {
  const single = $('installmentApplyEndState');
  const excel = $('installmentApplyEndStateExcel');
  if (!single || !excel) return;
  const checked = source === 'excel' ? excel.checked : single.checked;
  single.checked = checked;
  excel.checked = checked;
}

function setInstallmentMode(mode) {
  const prevMode = installmentMode;
  installmentMode = mode === 'excel' ? 'excel' : 'single';
  document.querySelectorAll('.installment-mode-tab[data-installment-mode]').forEach((btn) => {
    const active = btn.dataset.installmentMode === installmentMode;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-selected', active ? 'true' : 'false');
  });
  const singlePanel = $('installmentSinglePanel');
  const excelPanel = $('installmentExcelPanel');
  if (singlePanel) singlePanel.hidden = installmentMode !== 'single';
  if (excelPanel) excelPanel.hidden = installmentMode !== 'excel';

  if (prevMode !== installmentMode) {
    syncInstallmentOdooatCheckboxes(prevMode === 'excel' ? 'excel' : 'single');
  }

  $('installmentPreviewSection').hidden = true;
  if ($('btnInstallmentUpdate')) $('btnInstallmentUpdate').disabled = true;
}

function normalizeExcelHeader(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '')
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک');
}

function mapExcelHeaderIndex(headers) {
  const map = {};
  headers.forEach((h, idx) => {
    const key = normalizeExcelHeader(h);
    if (key === 'identifier' || key === 'شناسه' || key === 'nodocument' || key === 'trackingno'
      || key === 'شمارهسند' || key === 'کدپیگیری' || key === 'شمارهسند/کدپیگیری') {
      map.identifier = idx;
    }
    if (key === 'paymentcost' || key === 'مبلغ') map.paymentCost = idx;
    if (key === 'paymentdate' || key === 'تاریخ' || key === 'تاریخپرداخت') map.paymentDate = idx;
  });
  return map;
}

function mapUnsentExcelHeaderIndex(headers) {
  const map = {};
  headers.forEach((h, idx) => {
    const key = normalizeExcelHeader(h);
    if (key === 'شناسهقبض' || key === 'billid' || key === 'billid' || key === 'شناسهقبص') {
      map.billId = idx;
    }
    if (key === 'شناسهپرداخت' || key === 'paymentid' || key === 'payid' || key === 'payid') {
      map.paymentId = idx;
    }
    if (key === 'شمارهفیش' || key === 'ficheno' || key === 'fiche' || key === 'فیش') {
      map.ficheNo = idx;
    }
  });
  return map;
}

function hasScientificNotation(text) {
  return /e[+-]?\d+/i.test(String(text ?? '').trim());
}

function parseExcelCellValue(sheet, rowIdx, colIdx) {
  const ref = XLSX.utils.encode_cell({ r: rowIdx, c: colIdx });
  const cell = sheet[ref];
  if (!cell) return '';
  if (cell.t === 'n' && Number.isFinite(cell.v)) {
    const n = cell.v;
    if (Number.isInteger(n) && Math.abs(n) <= Number.MAX_SAFE_INTEGER) return String(Math.trunc(n));
    return String(n);
  }
  if (cell.w != null && String(cell.w).trim() !== '') return String(cell.w).trim();
  if (cell.t === 's') return String(cell.v ?? '').trim();
  return String(cell.v ?? '').trim();
}

function normalizeDigits(value) {
  return String(value ?? '').replace(/[\u06F0-\u06F9\u0660-\u0669]/g, (ch) => {
    const code = ch.charCodeAt(0);
    if (code >= 0x06f0 && code <= 0x06f9) return String(code - 0x06f0);
    return String(code - 0x0660);
  });
}

function normalizeSearchId(value) {
  return normalizeDigits(String(value ?? '')).trim();
}

function normalizeBillOrPayIdDigits(value) {
  const digits = normalizeDigits(String(value ?? '').trim()).replace(/\D/g, '');
  if (!digits) return '';
  return digits.length < 13 ? digits.padStart(13, '0') : digits;
}

function setSheetCellAsText(sheet, rowIdx, colIdx, value) {
  const ref = XLSX.utils.encode_cell({ r: rowIdx, c: colIdx });
  sheet[ref] = { t: 's', v: String(value), w: String(value) };
}

function parseInstallmentExcelFile(file) {
  return new Promise((resolve, reject) => {
    if (typeof XLSX === 'undefined') {
      reject(new Error('کتابخانه خواندن اکسل بارگذاری نشد'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array', cellText: true, cellDates: false });
        const sheetName = workbook.SheetNames[0];
        if (!sheetName) {
          reject(new Error('برگه‌ای در فایل اکسل یافت نشد'));
          return;
        }
        const sheet = workbook.Sheets[sheetName];
        const range = sheet?.['!ref']
          ? XLSX.utils.decode_range(sheet['!ref'])
          : { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };

        const headerRow = [];
        for (let c = range.s.c; c <= range.e.c; c++) {
          headerRow.push(parseExcelCellValue(sheet, range.s.r, c));
        }
        if (!headerRow.length) {
          reject(new Error('فایل اکسل خالی است'));
          return;
        }

        const col = mapExcelHeaderIndex(headerRow);
        const required = ['identifier', 'paymentCost', 'paymentDate'];
        const missing = required.filter((k) => col[k] == null);
        if (missing.length) {
          reject(new Error('ستون‌های الزامی: شناسه، مبلغ، تاریخ پرداخت'));
          return;
        }

        const parsed = [];
        for (let r = range.s.r + 1; r <= range.e.r; r++) {
          const identifier = parseExcelCellValue(sheet, r, col.identifier);
          const paymentCost = parseExcelCellValue(sheet, r, col.paymentCost);
          const paymentDate = parseExcelCellValue(sheet, r, col.paymentDate);

          if (hasScientificNotation(identifier)) {
            reject(new Error(
              `ردیف ${r + 1}: شناسه «${identifier}» به‌صورت علمی خوانده شد (مثل 5.02E+14). تغییر نوع ستون به Text عدد را برنمی‌گرداند — کد پیگیری را دوباره تایپ کنید یا از «دانلود قالب اکسل» استفاده کنید.`
            ));
            return;
          }
          if (hasScientificNotation(paymentCost)) {
            reject(new Error(
              `ردیف ${r + 1}: مبلغ «${paymentCost}» به‌صورت علمی است. ستون PaymentCost را Text کنید.`
            ));
            return;
          }

          const item = {
            identifier: normalizeSearchId(identifier),
            paymentCost: paymentCost.trim(),
            paymentDate: paymentDate.trim()
          };
          if (!item.identifier && !item.paymentCost && !item.paymentDate) continue;
          parsed.push(item);
        }

        if (!parsed.length) {
          reject(new Error('هیچ ردیف داده‌ای در فایل اکسل یافت نشد'));
          return;
        }
        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('خطا در خواندن فایل'));
    reader.readAsArrayBuffer(file);
  });
}

function parseUnsentExcelFile(file) {
  return new Promise((resolve, reject) => {
    if (typeof XLSX === 'undefined') {
      reject(new Error('کتابخانه خواندن اکسل بارگذاری نشد'));
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array', cellText: true, cellDates: false });
        const sheetName = workbook.SheetNames[0];
        if (!sheetName) {
          reject(new Error('برگه‌ای در فایل اکسل یافت نشد'));
          return;
        }
        const sheet = workbook.Sheets[sheetName];
        const range = sheet?.['!ref']
          ? XLSX.utils.decode_range(sheet['!ref'])
          : { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };

        const headerRow = [];
        for (let c = range.s.c; c <= range.e.c; c++) {
          headerRow.push(parseExcelCellValue(sheet, range.s.r, c));
        }
        if (!headerRow.length) {
          reject(new Error('فایل اکسل خالی است'));
          return;
        }

        const col = mapUnsentExcelHeaderIndex(headerRow);
        if (col.ficheNo == null && (col.billId == null || col.paymentId == null)) {
          reject(new Error('ستون شماره فیش، یا هر دو ستون شناسه قبض و شناسه پرداخت لازم است'));
          return;
        }

        const parsed = [];
        const seen = new Set();
        for (let r = range.s.r + 1; r <= range.e.r; r++) {
          const billId = col.billId != null ? parseExcelCellValue(sheet, r, col.billId) : '';
          const paymentId = col.paymentId != null ? parseExcelCellValue(sheet, r, col.paymentId) : '';
          const ficheNo = col.ficheNo != null ? parseExcelCellValue(sheet, r, col.ficheNo) : '';
          if (!billId && !paymentId && !ficheNo) continue;
          if (hasScientificNotation(billId) || hasScientificNotation(paymentId)
            || hasScientificNotation(ficheNo)) {
            reject(new Error(
              `ردیف ${r + 1}: شناسه قبض/پرداخت به‌صورت علمی خوانده شد. ستون را Text کنید و مقدار را دوباره وارد کنید.`
            ));
            return;
          }
          const item = {
            billId: normalizeSearchId(billId),
            paymentId: normalizeSearchId(paymentId),
            ficheNo: normalizeSearchId(ficheNo)
          };
          const pairComplete = !!item.billId && !!item.paymentId;
          if (!item.ficheNo && !pairComplete) {
            reject(new Error(`ردیف ${r + 1}: یا شماره فیش را وارد کنید، یا شناسه قبض و شناسه پرداخت را با هم`));
            return;
          }
          const key = pairComplete
            ? `${normalizeBillOrPayIdDigits(item.billId)}|${normalizeBillOrPayIdDigits(item.paymentId)}`
            : `fiche:${normalizeBillOrPayIdDigits(item.ficheNo)}`;
          if (seen.has(key)) continue;
          seen.add(key);
          parsed.push(item);
        }

        if (!parsed.length) {
          reject(new Error('هیچ ردیف داده‌ای در فایل اکسل یافت نشد'));
          return;
        }
        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = () => reject(new Error('خطا در خواندن فایل'));
    reader.readAsArrayBuffer(file);
  });
}

function setUnsentExcelStatus(message, loading = false) {
  const el = document.querySelector('.unsent-excel-status-row .installment-excel-status')
    || $('unsentExcelStatus');
  if (!el) return;
  el.hidden = false;
  el.removeAttribute('aria-hidden');
  el.textContent = message;
  el.classList.toggle('is-loading', loading);
}

function formatUnsentBatchSendResult(data) {
  const total = data.total ?? 0;
  const ok = data.succeeded ?? 0;
  const fail = data.failed ?? 0;
  const skip = data.skipped ?? 0;
  const headerLines = [
    `خلاصه ارسال: ${toPersianDigits(String(total))} فیش — موفق: ${toPersianDigits(String(ok))}، ناموفق: ${toPersianDigits(String(fail))}، رد: ${toPersianDigits(String(skip))}`
  ];
  if (data.dryRun) {
    headerLines.push('حالت آزمایشی (DryRun) — ارسال واقعی به رایورز انجام نشد.');
  }

  const detailBlocks = (data.results || []).map((r) => {
    const fiche = toPersianDigits(r.ficheNo || '—');
    const status = r.skipped ? 'رد شده' : (r.success ? 'موفق' : 'ناموفق');
    const parts = [`فیش ${fiche} — ${status}`];
    const msg = (r.message || '').trim();
    if (msg) parts.push(toPersianDigits(msg));
    const bill = formatBillPayDisplay(r.billId);
    const pay = formatBillPayDisplay(r.paymentId);
    if (bill && bill !== '-' && bill !== '—') parts.push(`شناسه قبض: ${bill}`);
    if (pay && pay !== '-' && pay !== '—') parts.push(`شناسه پرداخت: ${pay}`);
    if (r.docNotSentError) parts.push(`DocNotSent: ${toPersianDigits(r.docNotSentError)}`);
    return parts.join('\n');
  });

  const header = headerLines.join('\n');
  if (!detailBlocks.length) return header;
  // یک خط بین خلاصه و اولین فیش — بدون lines.push('') و بدون join('\n\n') روی header
  return `${header}\n${detailBlocks.join('\n\n')}`;
}

function rememberUnsentSourceKind(item, fallbackKind) {
  if (!item?.ficheNo) return;
  const kind = item.sourceKind || fallbackKind;
  if (kind) unsentSourceKindByFicheNo.set(item.ficheNo, kind);
}

function syncUnsentSourceKindsFromItems(items, fallbackKind) {
  (items || []).forEach((item) => rememberUnsentSourceKind(item, fallbackKind));
}

function getSelectedUnsentBatchTargets() {
  return getSelectedUnsentFicheNos().map((ficheNo) => ({
    ficheNo,
    sourceKind: unsentSourceKindByFicheNo.get(ficheNo)
      || $('unsentFicheKind')?.value
      || 'Income'
  }));
}

function appendUnsentItems(items, { autoSelect = false } = {}) {
  const incoming = items || [];
  const existing = new Set(unsentItems.map((row) => row.ficheNo));
  let added = 0;
  let duplicate = 0;
  const next = unsentItems.slice();
  incoming.forEach((item) => {
    if (!item?.ficheNo) return;
    if (existing.has(item.ficheNo)) {
      duplicate += 1;
      return;
    }
    existing.add(item.ficheNo);
    rememberUnsentSourceKind(item, null);
    next.push(item);
    if (autoSelect) selectedUnsentFicheNos.add(item.ficheNo);
    added += 1;
  });
  renderUnsentTable(next, {
    page: 1,
    totalPages: 1,
    totalCount: next.length,
    pageSize: unsentSearchState.pageSize
  });
  return { added, duplicate };
}

function getInstallmentPayload() {
  const base = {
    applyEndState: getInstallmentApplyEndState()
  };
  if (installmentMode === 'excel') {
    return {
      ...base,
      excelRows: installmentExcelRows.map((r) => ({
        identifier: r.identifier || '',
        paymentCost: r.paymentCost || '',
        paymentDate: r.paymentDate || ''
      }))
    };
  }
  const raw = ($('installmentValues')?.value || '').trim();
  return {
    ...base,
    valuesText: normalizeSearchId(raw)
  };
}

function syncInstallmentDryRunUi() {
  const updateBtn = $('btnInstallmentUpdate');
  if (updateBtn && !updateBtn.disabled) updateBtn.textContent = 'اعمال';
}

function toPersianDigits(value) {
  return String(value ?? '').replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);
}

function formatInstallmentCost(value) {
  if (value == null || value === '') return '-';
  const n = Number(String(value).replace(/,/g, ''));
  if (!Number.isNaN(n)) return n.toLocaleString('fa-IR');
  return toPersianDigits(value);
}

function formatInstallmentDate(value) {
  if (!value) return '-';
  const raw = String(value).trim();
  const digits = raw.replace(/\D/g, '');
  if (digits.length >= 8) {
    return toPersianDigits(`${digits.slice(0, 4)}/${digits.slice(4, 6)}/${digits.slice(6, 8)}`);
  }
  return toPersianDigits(raw);
}

function formatNosaziCode(value) {
  if (!value) return '-';
  return toPersianDigits(String(value).trim());
}

function formatOdooatPlan(row) {
  return row.willApplyEndState ? 'بله' : 'خیر';
}

function renderInstallmentPreview(data) {
  const section = $('installmentPreviewSection');
  const tbody = $('installmentPreviewTable')?.querySelector('tbody');
  const summary = $('installmentPreviewSummary');
  const updateBtn = $('btnInstallmentUpdate');
  if (!section || !tbody) return;

  const items = data.items || [];
  section.hidden = false;
  if (summary) {
    summary.textContent = `ردیف یافت شد: ${data.foundCount || 0} | بدون نتیجه: ${data.notFoundCount || 0} | تطابق کامل: ${data.matchedCount || 0} | عدم تطابق: ${data.mismatchCount || 0}`;
  }
  tbody.innerHTML = '';
  items.forEach((row, idx) => {
    const tr = document.createElement('tr');
    if (!row.found) tr.classList.add('row-not-found');
    else if (row.found && row.dataMatches === false) tr.classList.add('row-mismatch');
    const kind = row.detectedLookupKind || '';
    const rowNum = row.rowIndex || idx + 1;
    const status = !row.found
      ? (row.validationMessage || 'یافت نشد')
      : (row.dataMatches ? 'تطابق کامل' : (row.validationMessage || 'عدم تطابق'));

    tr.innerHTML = `
      <td class="col-installment-row">${toPersianDigits(rowNum)}</td>
      <td class="col-installment-detect">${installmentLookupLabels[kind] || kind || '—'}</td>
      <td class="col-installment-nodoc">${toPersianDigits(row.noDocument || '-')}</td>
      <td class="col-installment-tracking">${toPersianDigits(row.trackingNo || '-')}</td>
      <td class="col-installment-cost">${formatInstallmentCost(row.paymentCost)}</td>
      <td class="col-installment-date">${formatInstallmentDate(row.paymentDate)}</td>
      <td class="col-installment-workitem">${toPersianDigits(row.nidWorkItem || '-')}</td>
      <td class="col-installment-nosazi">${formatNosaziCode(row.nosaziCode)}</td>
      <td class="col-installment-odooat">${formatOdooatPlan(row)}</td>
      <td class="col-installment-status">${status}</td>
      <td class="col-installment-comments">${row.proposedComments || '-'}</td>
    `;
    tbody.appendChild(tr);
  });
  if (updateBtn) {
    updateBtn.disabled = !(data.matchedCount > 0);
    updateBtn.textContent = 'اعمال';
  }
}

function formatInstallmentUpdateResult(data) {
  const lines = (data.results || []).map((r) => {
    const count = data.dryRun ? (r.wouldUpdate || 0) : (r.rowsAffected || 0);
    const kind = installmentLookupLabels[r.detectedLookupKind] || r.detectedLookupKind || '';
    return `${r.lookupValue} [${kind}]: ${r.success ? 'OK' : 'FAIL'} (${count} ردیف) — ${r.message || ''}`;
  });
  const modeLine = data.excelMode ? 'حالت: اکسل' : 'حالت: تکی';
  return [
    '=== نتیجه UPDATE Installment_List ===',
    modeLine,
    `DryRun: ${data.dryRun}`,
    `ApplyEndState (عودت): ${data.applyEndState}`,
    data.dryRun
      ? `شبیه‌سازی — ${data.wouldUpdate || 0} ردیف UPDATE می‌شد | بدون نتیجه: ${data.notFound}${data.skippedMismatch ? ` | عدم تطابق: ${data.skippedMismatch}` : ''}`
      : `به‌روز: ${data.updated} | بدون نتیجه: ${data.notFound} | خطا: ${data.failed}${data.skippedMismatch ? ` | عدم تطابق: ${data.skippedMismatch}` : ''}`,
    '',
    ...lines
  ].join('\n');
}

function initFicheDateStatusControls() {
  const filterHost = $('ficheDateStatusFilters');
  const statusSelect = $('ficheDateNewStatus');
  if (filterHost) {
    filterHost.innerHTML = '';
    ficheDateStatusOrder.forEach((value) => {
      const labelText = ficheDateStatusLabels[value];
      const labelEl = document.createElement('label');
      labelEl.className = 'fiche-date-ms-option';
      labelEl.setAttribute('role', 'option');
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.value = String(value);
      input.className = 'fiche-date-status-filter';
      if (value === 1) input.checked = true;
      const text = document.createElement('span');
      text.className = 'fiche-date-ms-option-text';
      text.textContent = `${value} — ${labelText}`;
      labelEl.appendChild(input);
      labelEl.appendChild(text);
      filterHost.appendChild(labelEl);
    });
    setupFicheDateStatusDropdown();
    updateFicheDateStatusTriggerLabel();
  }
  if (statusSelect) {
    statusSelect.innerHTML = '';
    ficheDateStatusOrder.forEach((value) => {
      const label = ficheDateStatusLabels[value];
      const opt = document.createElement('option');
      opt.value = String(value);
      opt.textContent = `${value} — ${label}`;
      if (value === 1) opt.selected = true;
      statusSelect.appendChild(opt);
    });
  }
  syncFicheDateApplyFields();
}

function updateFicheDateStatusTriggerLabel() {
  const labelEl = $('ficheDateStatusTriggerLabel');
  if (!labelEl) return;
  const selected = getSelectedFicheDateStatuses();
  if (selected.length === 0) {
    labelEl.textContent = 'انتخاب وضعیت…';
    return;
  }
  if (selected.length === 1) {
    const value = selected[0];
    labelEl.textContent = `${value} — ${ficheDateStatusLabels[value] || value}`;
    return;
  }
  labelEl.textContent = `${selected.length.toLocaleString('fa-IR')} وضعیت انتخاب‌شده`;
}

function closeFicheDateStatusMenu() {
  const menu = $('ficheDateStatusFilters');
  const trigger = $('ficheDateStatusTrigger');
  if (menu) menu.hidden = true;
  if (trigger) trigger.setAttribute('aria-expanded', 'false');
}

function toggleFicheDateStatusMenu() {
  const menu = $('ficheDateStatusFilters');
  const trigger = $('ficheDateStatusTrigger');
  if (!menu || !trigger) return;
  const open = menu.hidden;
  menu.hidden = !open;
  trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
}

function setupFicheDateStatusDropdown() {
  const trigger = $('ficheDateStatusTrigger');
  const menu = $('ficheDateStatusFilters');
  if (!trigger || !menu || trigger.dataset.bound === '1') return;
  trigger.dataset.bound = '1';

  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleFicheDateStatusMenu();
  });

  menu.querySelectorAll('.fiche-date-status-filter').forEach((input) => {
    input.addEventListener('change', updateFicheDateStatusTriggerLabel);
  });

  document.addEventListener('click', (e) => {
    const wrap = $('ficheDateStatusMulti');
    if (!wrap || wrap.contains(e.target)) return;
    closeFicheDateStatusMenu();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeFicheDateStatusMenu();
  });
}

function syncFicheDateApplyFields() {
  const pairs = [
    ['ficheDateApplyPermanent', 'ficheDateNewPermanent'],
    ['ficheDateApplyTemporary', 'ficheDateNewTemporary'],
    ['ficheDateApplyBreak', 'ficheDateNewBreak']
  ];
  pairs.forEach(([chkId, inputId]) => {
    const chk = $(chkId);
    const input = $(inputId);
    if (!chk || !input) return;
    input.disabled = !chk.checked;
  });
  const statusChk = $('ficheDateApplyStatus');
  const statusSel = $('ficheDateNewStatus');
  if (statusChk && statusSel) statusSel.disabled = !statusChk.checked;
}

function updateFicheDateIdentifierHint() {
  const input = $('ficheDateIdentifier');
  const hint = $('ficheDateIdentifierHint');
  if (!input || !hint) return;
  const value = (input.value || '').trim();
  if (!value) {
    hint.hidden = true;
    hint.textContent = '';
    return;
  }
  const type = detectIdentifierType(value);
  if (!type) {
    hint.hidden = true;
    return;
  }
  hint.hidden = false;
  hint.textContent = `تشخیص: ${identifierTypeLabels[type] || type}`;
}

async function searchFicheDateAccountGroups(query, limit = 20) {
  const params = new URLSearchParams();
  const trimmed = (query || '').trim();
  if (trimmed) params.set('q', trimmed);
  params.set('limit', String(limit));
  const res = await apiFetch(`/api/fiche-date/account-groups?${params.toString()}`);
  const data = await parseJsonResponse(res);
  if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
  return data.titles || [];
}

let accountGroupSearchTimer = null;
let accountGroupSearchSeq = 0;
const ficheDateSelectedAccountGroups = new Set();

function updateFicheDateAccountGroupTriggerLabel() {
  const labelEl = $('ficheDateAccountGroupTriggerLabel');
  if (!labelEl) return;
  const selected = Array.from(ficheDateSelectedAccountGroups);
  if (selected.length === 0) {
    labelEl.textContent = 'انتخاب عنوان مالکیت…';
    return;
  }
  if (selected.length === 1) {
    labelEl.textContent = selected[0];
    return;
  }
  labelEl.textContent = `${selected.length.toLocaleString('fa-IR')} عنوان انتخاب‌شده`;
}

function getSelectedFicheDateAccountGroups() {
  return Array.from(ficheDateSelectedAccountGroups);
}

function closeFicheDateAccountGroupMenu() {
  const menu = $('ficheDateAccountGroupMenu');
  const trigger = $('ficheDateAccountGroupTrigger');
  if (menu) menu.hidden = true;
  if (trigger) trigger.setAttribute('aria-expanded', 'false');
}

function toggleFicheDateAccountGroupMenu() {
  const menu = $('ficheDateAccountGroupMenu');
  const trigger = $('ficheDateAccountGroupTrigger');
  if (!menu || !trigger) return;
  const open = menu.hidden;
  menu.hidden = !open;
  trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
  if (open) fetchFicheDateAccountGroupOptions($('ficheDateAccountGroupSearch')?.value || '');
}

function renderFicheDateAccountGroupOptions(titles) {
  const host = $('ficheDateAccountGroupOptions');
  if (!host) return;
  host.innerHTML = '';
  if (!titles.length) {
    const empty = document.createElement('div');
    empty.className = 'fiche-date-account-group-empty';
    empty.textContent = 'موردی یافت نشد';
    host.appendChild(empty);
    return;
  }
  titles.forEach((title) => {
    const labelEl = document.createElement('label');
    labelEl.className = 'fiche-date-ms-option';
    labelEl.setAttribute('role', 'option');
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.className = 'fiche-date-account-group-filter';
    input.value = title;
    input.checked = ficheDateSelectedAccountGroups.has(title);
    input.addEventListener('change', () => {
      if (input.checked) ficheDateSelectedAccountGroups.add(title);
      else ficheDateSelectedAccountGroups.delete(title);
      updateFicheDateAccountGroupTriggerLabel();
    });
    const text = document.createElement('span');
    text.className = 'fiche-date-ms-option-text';
    text.textContent = title;
    labelEl.appendChild(input);
    labelEl.appendChild(text);
    host.appendChild(labelEl);
  });
}

async function fetchFicheDateAccountGroupOptions(query) {
  const seq = ++accountGroupSearchSeq;
  try {
    const titles = await searchFicheDateAccountGroups(query, 50);
    if (seq !== accountGroupSearchSeq) return;
    const merged = [...new Set([...titles, ...ficheDateSelectedAccountGroups])]
      .sort((a, b) => a.localeCompare(b, 'fa'));
    renderFicheDateAccountGroupOptions(merged);
  } catch {
    if (seq !== accountGroupSearchSeq) return;
    renderFicheDateAccountGroupOptions(Array.from(ficheDateSelectedAccountGroups));
  }
}

function setupFicheDateAccountGroupLazyLoad() {
  if (!canAccessFicheDateChange()) return;
  const trigger = $('ficheDateAccountGroupTrigger');
  const menu = $('ficheDateAccountGroupMenu');
  const search = $('ficheDateAccountGroupSearch');
  if (!trigger || !menu || trigger.dataset.lazyBound === '1') return;
  trigger.dataset.lazyBound = '1';

  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleFicheDateAccountGroupMenu();
  });

  search?.addEventListener('input', () => {
    clearTimeout(accountGroupSearchTimer);
    accountGroupSearchTimer = setTimeout(() => {
      fetchFicheDateAccountGroupOptions(search.value);
    }, 300);
  });

  document.addEventListener('click', (e) => {
    const wrap = $('ficheDateAccountGroupMulti');
    if (!wrap || wrap.contains(e.target)) return;
    closeFicheDateAccountGroupMenu();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeFicheDateAccountGroupMenu();
  });

  updateFicheDateAccountGroupTriggerLabel();
}

function updateUserGroupPermsTriggerLabel() {
  const labelEl = $('userGroupPermsTriggerLabel');
  const menu = $('userGroupPermsMenu');
  if (!labelEl || !menu) return;
  const labels = Array.from(menu.querySelectorAll('.user-group-perm-check:checked'))
    .map((el) => (el.dataset.permLabel || '').trim())
    .filter(Boolean);
  if (labels.length === 0) {
    labelEl.textContent = 'انتخاب دسترسی…';
    return;
  }
  if (labels.length === 1) {
    labelEl.textContent = labels[0];
    return;
  }
  labelEl.textContent = `${labels.length.toLocaleString('fa-IR')} دسترسی انتخاب‌شده`;
}

function setupUserGroupPermsDropdown() {
  const trigger = $('userGroupPermsTrigger');
  const menu = $('userGroupPermsMenu');
  if (!trigger || !menu || trigger.dataset.bound === '1') return;
  trigger.dataset.bound = '1';

  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = menu.hidden;
    menu.hidden = !open;
    trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  menu.querySelectorAll('.user-group-perm-check').forEach((input) => {
    input.addEventListener('change', updateUserGroupPermsTriggerLabel);
  });

  document.addEventListener('click', (e) => {
    const wrap = $('userGroupPermsMulti');
    if (!wrap || wrap.contains(e.target)) return;
    menu.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      menu.hidden = true;
      trigger.setAttribute('aria-expanded', 'false');
    }
  });

  updateUserGroupPermsTriggerLabel();
}

function getSelectedFicheDateStatuses() {
  return Array.from(document.querySelectorAll('.fiche-date-status-filter:checked'))
    .map((el) => parseInt(el.value, 10))
    .filter((n) => !Number.isNaN(n));
}

function getFicheDateSearchPayload(page = ficheDateSearchState.page) {
  const pageSize = parseInt($('ficheDatePageSize')?.value || ficheDateSearchState.pageSize, 10) || 25;
  ficheDateSearchState.pageSize = pageSize;
  return {
    identifierValue: normalizeSearchId($('ficheDateIdentifier')?.value),
    permanentFromDate: ($('ficheDatePermanentFrom')?.value || '').trim(),
    permanentToDate: ($('ficheDatePermanentTo')?.value || '').trim(),
    temporaryFromDate: ($('ficheDateTemporaryFrom')?.value || '').trim(),
    temporaryToDate: ($('ficheDateTemporaryTo')?.value || '').trim(),
    accountGroupTitles: getSelectedFicheDateAccountGroups(),
    eumFicheStatuses: getSelectedFicheDateStatuses(),
    page,
    pageSize
  };
}

function hasFicheDateSearchFilter(payload = getFicheDateSearchPayload()) {
  return !!(payload.identifierValue
    || payload.permanentFromDate || payload.permanentToDate
    || payload.temporaryFromDate || payload.temporaryToDate
    || (payload.accountGroupTitles && payload.accountGroupTitles.length > 0)
    || (payload.eumFicheStatuses && payload.eumFicheStatuses.length > 0));
}

function updateFicheDatePaginationUi() {
  const bar = $('ficheDatePagination');
  const label = $('ficheDatePageLabel');
  const prevBtn = $('btnFicheDatePrevPage');
  const nextBtn = $('btnFicheDateNextPage');
  if (!bar || !label || !prevBtn || !nextBtn) return;

  const { page, totalPages, totalCount } = ficheDateSearchState;
  const hasResults = totalCount > 0;
  bar.hidden = !hasResults;

  if (!hasResults) {
    label.textContent = '';
    prevBtn.disabled = true;
    nextBtn.disabled = true;
    return;
  }

  label.textContent = `صفحه ${page.toLocaleString('fa-IR')} از ${totalPages.toLocaleString('fa-IR')} — ${totalCount.toLocaleString('fa-IR')} مورد`;
  prevBtn.disabled = page <= 1;
  nextBtn.disabled = page >= totalPages;
}

function syncFicheDateUpdateButton() {
  const btn = $('btnFicheDateUpdate');
  if (!btn) return;
  btn.disabled = selectedFicheDateNos.size === 0;
}

function renderFicheDateTable(items, meta = {}) {
  ficheDateItems = items || [];
  if (meta.page != null) ficheDateSearchState.page = meta.page;
  if (meta.pageSize != null) ficheDateSearchState.pageSize = meta.pageSize;
  if (meta.totalCount != null) ficheDateSearchState.totalCount = meta.totalCount;
  if (meta.totalPages != null) ficheDateSearchState.totalPages = meta.totalPages;

  const section = $('ficheDateResultsSection');
  const tbody = $('ficheDateTable')?.querySelector('tbody');
  const countLabel = $('ficheDateCountLabel');
  const selectAll = $('ficheDateSelectAll');
  if (!section || !tbody) return;

  tbody.innerHTML = '';
  if (ficheDateItems.length === 0) {
    section.hidden = false;
    if (countLabel) {
      countLabel.textContent = ficheDateSearchState.totalCount > 0
        ? `۰ مورد در این صفحه — ${ficheDateSearchState.totalCount.toLocaleString('fa-IR')} مورد کل`
        : 'نتیجه‌ای یافت نشد';
    }
    if (selectAll) selectAll.checked = false;
    updateFicheDatePaginationUi();
    syncFicheDateUpdateButton();
    return;
  }

  ficheDateItems.forEach((item) => {
    const checked = selectedFicheDateNos.has(item.ficheNo) ? ' checked' : '';
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td class="col-check"><input type="checkbox" class="fiche-date-row-check" data-fiche-no="${item.ficheNo}"${checked} /></td>
      <td>${toPersianDigits(item.ficheNo || '-')}</td>
      <td>${toPersianDigits(item.billId || '-')}</td>
      <td>${toPersianDigits(item.paymentId || '-')}</td>
      <td>${item.accountGroupTitle || '-'}</td>
      <td>${toPersianDigits(item.exportTemporaryDate || '-')}</td>
      <td>${toPersianDigits(item.exportPermanentDate || '-')}</td>
      <td>${toPersianDigits(item.paymentBreakDate || '-')}</td>
      <td>${toPersianDigits(item.paymentDate || '-')}</td>
      <td>${item.eumFicheStatusLabel || item.eumFicheStatus}</td>
    `;
    tbody.appendChild(tr);
  });

  tbody.querySelectorAll('.fiche-date-row-check').forEach((cb) => {
    cb.addEventListener('change', () => {
      const ficheNo = cb.dataset.ficheNo;
      const item = ficheDateItems.find((row) => row.ficheNo === ficheNo);
      setGridRowSelected(selectedFicheDateNos, ficheDateSelectedItems, item || { ficheNo }, cb.checked);
      syncFicheDateUpdateButton();
      if (selectAll) {
        const all = tbody.querySelectorAll('.fiche-date-row-check');
        selectAll.checked = all.length > 0 && Array.from(all).every((x) => x.checked);
      }
      updateFicheDateCountLabel();
    });
  });

  section.hidden = false;
  updateFicheDateCountLabel();
  if (selectAll) {
    const selectedOnPage = ficheDateItems.filter((item) => selectedFicheDateNos.has(item.ficheNo)).length;
    selectAll.checked = ficheDateItems.length > 0 && selectedOnPage === ficheDateItems.length;
  }
  updateFicheDatePaginationUi();
  syncFicheDateUpdateButton();
}

function updateFicheDateCountLabel() {
  const countLabel = $('ficheDateCountLabel');
  if (!countLabel) return;
  const selectedTotal = selectedFicheDateNos.size;
  const pageInfo = `${ficheDateItems.length.toLocaleString('fa-IR')} مورد در این صفحه — ${ficheDateSearchState.totalCount.toLocaleString('fa-IR')} مورد کل`;
  countLabel.textContent = selectedTotal > 0
    ? `${pageInfo} | ${selectedTotal.toLocaleString('fa-IR')} انتخاب‌شده`
    : pageInfo;
}

async function fetchFicheDateResults(page = 1, { clearSelection = false } = {}) {
  const payload = getFicheDateSearchPayload(page);
  if (!hasFicheDateSearchFilter(payload)) {
    showAppWarning('حداقل یک فیلتر وارد کنید');
    return false;
  }

  if (clearSelection) clearGridSelection(selectedFicheDateNos, ficheDateSelectedItems);
  ficheDateSearchState.page = page;

  const btn = $('btnFicheDateSearch');
  const prevBtn = $('btnFicheDatePrevPage');
  const nextBtn = $('btnFicheDateNextPage');
  const box = $('ficheDateResultBox');
  if (btn) btn.disabled = true;
  if (prevBtn) prevBtn.disabled = true;
  if (nextBtn) nextBtn.disabled = true;
  const prevLabel = btn?.textContent;
  if (btn) btn.textContent = 'در حال جستجو…';
  if (box) box.hidden = true;

  try {
    const res = await apiFetch('/api/fiche-date/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);

    const totalCount = data.totalCount ?? data.count ?? 0;
    const totalPages = data.totalPages ?? (data.pageSize > 0 ? Math.ceil(totalCount / data.pageSize) : 0);
    renderFicheDateTable(data.items || [], {
      page: data.page ?? page,
      pageSize: data.pageSize ?? payload.pageSize,
      totalCount,
      totalPages
    });
    return true;
  } catch (e) {
    showAppError(e.message);
    renderFicheDateTable([], { page: 1, pageSize: payload.pageSize, totalCount: 0, totalPages: 0 });
    return false;
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = prevLabel || 'جستجو';
    }
    updateFicheDatePaginationUi();
  }
}

function getFicheDateUpdatePayload() {
  const applyStatus = !!$('ficheDateApplyStatus')?.checked;
  return {
    ficheNos: Array.from(selectedFicheDateNos),
    applyExportPermanentDate: !!$('ficheDateApplyPermanent')?.checked,
    newExportPermanentDate: ($('ficheDateNewPermanent')?.value || '').trim(),
    applyExportTemporaryDate: !!$('ficheDateApplyTemporary')?.checked,
    newExportTemporaryDate: ($('ficheDateNewTemporary')?.value || '').trim(),
    applyPaymentBreakDate: !!$('ficheDateApplyBreak')?.checked,
    newPaymentBreakDate: ($('ficheDateNewBreak')?.value || '').trim(),
    applyEumFicheStatus: applyStatus,
    newEumFicheStatus: applyStatus ? parseInt($('ficheDateNewStatus')?.value || '1', 10) : null
  };
}

function formatFicheDateUpdateResult(data) {
  const lines = (data.results || []).map((r) => {
    const cached = ficheDateSelectedItems.get(r.ficheNo);
    const titlePart = cached?.accountGroupTitle ? ` | عنوان: ${cached.accountGroupTitle}` : '';
    return `${r.ficheNo}: ${r.success ? 'OK' : 'FAIL'} — ${r.message || ''}${titlePart}`;
  });
  return [
    '=== نتیجه UPDATE Income_Fiche ===',
    `DryRun: ${data.dryRun}`,
    data.dryRun
      ? `شبیه‌سازی — ${data.wouldUpdate || 0} فیش UPDATE می‌شد | بدون نتیجه: ${data.notFound}`
      : `به‌روز: ${data.updated} | بدون نتیجه: ${data.notFound} | خطا: ${data.failed}`,
    '',
    ...lines
  ].join('\n');
}

let bankInquiryItems = [];
const selectedBankInquiryNos = new Set();
let shahkarItems = [];
const selectedShahkarUserNames = new Set();
const shahkarSelectedItems = new Map();
const bankInquirySelectedItems = new Map();
const bankInquirySearchState = {
  page: 1,
  pageSize: 25,
  totalCount: 0,
  totalPages: 0
};

function getBankInquirySearchPayload(page = bankInquirySearchState.page) {
  const pageSize = parseInt($('bankInquiryPageSize')?.value || bankInquirySearchState.pageSize, 10) || 25;
  bankInquirySearchState.pageSize = pageSize;
  return {
    ficheNo: normalizeSearchId($('bankInquiryFicheNo')?.value),
    billId: normalizeSearchId($('bankInquiryBillId')?.value),
    paymentId: normalizeSearchId($('bankInquiryPaymentId')?.value),
    page,
    pageSize
  };
}

function validateBankInquirySearchPayload(payload) {
  const hasFicheNo = !!payload.ficheNo;
  const hasBillPayment = !!payload.billId && !!payload.paymentId;
  if (!hasFicheNo && !hasBillPayment) {
    return 'حداقل یکی از فیلترها را وارد کنید: شماره فیش، یا شناسه قبض و شناسه پرداخت';
  }
  if ((payload.billId && !payload.paymentId) || (!payload.billId && payload.paymentId)) {
    return 'هر دو فیلد شناسه قبض و شناسه پرداخت الزامی است';
  }
  return null;
}

function updateBankInquiryPaginationUi() {
  const bar = $('bankInquiryPagination');
  const label = $('bankInquiryPageLabel');
  const prevBtn = $('btnBankInquiryPrevPage');
  const nextBtn = $('btnBankInquiryNextPage');
  if (!bar || !label || !prevBtn || !nextBtn) return;

  const { page, totalPages, totalCount } = bankInquirySearchState;
  const show = totalCount > 0;
  bar.hidden = !show;
  if (!show) return;

  label.textContent = `صفحه ${page.toLocaleString('fa-IR')} از ${Math.max(totalPages, 1).toLocaleString('fa-IR')}`;
  prevBtn.disabled = page <= 1;
  nextBtn.disabled = page >= totalPages;
}

function syncBankInquiryConfirmButton() {
  const btn = $('btnBankInquiryConfirm');
  if (!btn) return;
  btn.disabled = selectedBankInquiryNos.size === 0;
  const applySection = $('bankInquiryApplySection');
  if (applySection) applySection.hidden = selectedBankInquiryNos.size === 0;
}

function updateBankInquiryCountLabel() {
  const countLabel = $('bankInquiryCountLabel');
  if (!countLabel) return;
  const selectedTotal = selectedBankInquiryNos.size;
  const pageInfo = `${bankInquiryItems.length.toLocaleString('fa-IR')} مورد در این صفحه — ${bankInquirySearchState.totalCount.toLocaleString('fa-IR')} مورد کل`;
  countLabel.textContent = selectedTotal > 0
    ? `${pageInfo} — ${selectedTotal.toLocaleString('fa-IR')} انتخاب‌شده`
    : pageInfo;
}

function renderBankInquiryTable(items, meta = {}) {
  bankInquiryItems = items || [];
  if (meta.page != null) bankInquirySearchState.page = meta.page;
  if (meta.pageSize != null) bankInquirySearchState.pageSize = meta.pageSize;
  if (meta.totalCount != null) bankInquirySearchState.totalCount = meta.totalCount;
  if (meta.totalPages != null) bankInquirySearchState.totalPages = meta.totalPages;

  const section = $('bankInquiryResultsSection');
  const tbody = $('bankInquiryTable')?.querySelector('tbody');
  const selectAll = $('bankInquirySelectAll');
  if (!section || !tbody) return;

  section.hidden = false;

  if (bankInquiryItems.length === 0) {
    tbody.innerHTML = '<tr><td colspan="11" class="empty-row">موردی یافت نشد</td></tr>';
    updateBankInquiryCountLabel();
    updateBankInquiryPaginationUi();
    syncBankInquiryConfirmButton();
    return;
  }

  tbody.innerHTML = bankInquiryItems.map((item) => {
    const checked = selectedBankInquiryNos.has(item.ficheNo) ? ' checked' : '';
    return `<tr>
      <td class="col-check"><input type="checkbox" class="bank-inquiry-row-check" data-fiche-no="${item.ficheNo}"${checked} /></td>
      <td>${toPersianDigits(item.ficheNo || '-')}</td>
      <td>${toPersianDigits(item.nidWorkItem || '-')}</td>
      <td>${formatNosaziCode(item.nosaziCode)}</td>
      <td>${toPersianDigits(item.billId || '-')}</td>
      <td>${toPersianDigits(item.paymentId || '-')}</td>
      <td>${formatShamsiDisplay(item.paymentDate)}</td>
      <td>${formatShamsiDisplay(item.bankPaymentDate)}</td>
      <td>${item.eumFicheStatusLabel || item.eumFicheStatus}</td>
      <td>${formatShamsiDisplay(item.userConfirmDate)}</td>
      <td>${item.usernameUserConfirm || '-'}</td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('.bank-inquiry-row-check').forEach((cb) => {
    cb.addEventListener('change', () => {
      const ficheNo = cb.dataset.ficheNo;
      const item = bankInquiryItems.find((row) => row.ficheNo === ficheNo);
      setGridRowSelected(selectedBankInquiryNos, bankInquirySelectedItems, item || { ficheNo }, cb.checked);
      syncBankInquiryConfirmButton();
      if (selectAll) {
        const all = tbody.querySelectorAll('.bank-inquiry-row-check');
        selectAll.checked = all.length > 0 && Array.from(all).every((x) => x.checked);
      }
      updateBankInquiryCountLabel();
    });
  });

  updateBankInquiryCountLabel();
  if (selectAll) {
    const selectedOnPage = bankInquiryItems.filter((item) => selectedBankInquiryNos.has(item.ficheNo)).length;
    selectAll.checked = bankInquiryItems.length > 0 && selectedOnPage === bankInquiryItems.length;
  }
  updateBankInquiryPaginationUi();
  syncBankInquiryConfirmButton();
}

function setShahkarRowSelected(selectionSet, cacheMap, item, selected) {
  const key = (item?.userName || '').trim();
  if (!key) return;
  if (selected) {
    selectionSet.add(key);
    if (cacheMap) cacheMap.set(key, item);
  } else {
    selectionSet.delete(key);
    if (cacheMap) cacheMap.delete(key);
  }
}

function syncShahkarConfirmButton() {
  const btn = $('btnShahkarConfirm');
  if (btn) btn.disabled = selectedShahkarUserNames.size === 0;
}

function updateShahkarCountLabel() {
  const countLabel = $('shahkarCountLabel');
  if (!countLabel) return;
  const total = shahkarItems.length;
  const selectedTotal = selectedShahkarUserNames.size;
  countLabel.textContent = selectedTotal > 0
    ? `${total.toLocaleString('fa-IR')} مورد — ${selectedTotal.toLocaleString('fa-IR')} انتخاب‌شده`
    : `${total.toLocaleString('fa-IR')} مورد`;
}

function formatShahkarOkLabel(value, isOk) {
  if (isOk) return 'تأیید (1)';
  const v = (value || '').trim();
  return v ? v : 'خیر';
}

function renderShahkarTable(items) {
  shahkarItems = items || [];
  const section = $('shahkarResultsSection');
  const tbody = $('shahkarTable')?.querySelector('tbody');
  const selectAll = $('shahkarSelectAll');
  if (!section || !tbody) return;

  section.hidden = false;

  if (shahkarItems.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" class="empty-row">موردی یافت نشد</td></tr>';
    updateShahkarCountLabel();
    syncShahkarConfirmButton();
    return;
  }

  tbody.innerHTML = shahkarItems.map((item) => {
    const userName = (item.userName || '').trim();
    const checked = selectedShahkarUserNames.has(userName) ? ' checked' : '';
    const okLabel = formatShahkarOkLabel(item.shahkarOk, item.isShahkarOk);
    return `<tr>
      <td class="col-check"><input type="checkbox" class="shahkar-row-check" data-user-name="${userName}"${checked} /></td>
      <td>${userName || '-'}</td>
      <td>${toPersianDigits(item.nationalCode || '-')}</td>
      <td>${okLabel}</td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('.shahkar-row-check').forEach((cb) => {
    cb.addEventListener('change', () => {
      const userName = (cb.dataset.userName || '').trim();
      const item = shahkarItems.find((row) => (row.userName || '').trim() === userName);
      setShahkarRowSelected(selectedShahkarUserNames, shahkarSelectedItems, item || { userName }, cb.checked);
      syncShahkarConfirmButton();
      if (selectAll) {
        const all = tbody.querySelectorAll('.shahkar-row-check');
        selectAll.checked = all.length > 0 && Array.from(all).every((x) => x.checked);
      }
      updateShahkarCountLabel();
    });
  });

  updateShahkarCountLabel();
  if (selectAll) {
    const selectedOnPage = shahkarItems.filter((item) => selectedShahkarUserNames.has((item.userName || '').trim())).length;
    selectAll.checked = shahkarItems.length > 0 && selectedOnPage === shahkarItems.length;
  }
  syncShahkarConfirmButton();
}

async function fetchShahkarResults({ clearSelection = false } = {}) {
  const userName = ($('shahkarUserName')?.value || '').trim();
  const nationalCode = normalizeSearchId($('shahkarNationalCode')?.value);
  if (!userName && !nationalCode) {
    return showAppWarning('نام کاربری یا کد ملی را وارد کنید');
  }

  if (clearSelection) {
    clearGridSelection(selectedShahkarUserNames, shahkarSelectedItems);
  }

  const box = $('shahkarResultBox');
  try {
    const res = await apiFetch('/api/shahkar/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userName, nationalCode })
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
    renderShahkarTable(data.items || []);
    if (box) box.hidden = true;
  } catch (e) {
    if (box) {
      box.hidden = false;
      box.textContent = e.message;
    }
    showAppError(e.message);
  }
}

async function fetchBankInquiryResults(page = 1, { clearSelection = false } = {}) {
  const payload = getBankInquirySearchPayload(page);
  const validationError = validateBankInquirySearchPayload(payload);
  if (validationError) return showAppWarning(validationError);

  if (clearSelection) clearGridSelection(selectedBankInquiryNos, bankInquirySelectedItems);
  bankInquirySearchState.page = page;

  const btn = $('btnBankInquirySearch');
  const prevBtn = $('btnBankInquiryPrevPage');
  const nextBtn = $('btnBankInquiryNextPage');
  const box = $('bankInquiryResultBox');
  if (btn) btn.disabled = true;
  if (prevBtn) prevBtn.disabled = true;
  if (nextBtn) nextBtn.disabled = true;

  try {
    const res = await apiFetch('/api/bank-inquiry/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
    renderBankInquiryTable(data.items || [], {
      page: data.page,
      pageSize: data.pageSize,
      totalCount: data.totalCount,
      totalPages: data.totalPages
    });
    if (box) box.hidden = true;
  } catch (e) {
    renderBankInquiryTable([], { page: 1, pageSize: payload.pageSize, totalCount: 0, totalPages: 0 });
    if (box) {
      box.hidden = false;
      box.textContent = e.message;
    }
    showAppError(e.message);
  } finally {
    if (btn) btn.disabled = false;
    updateBankInquiryPaginationUi();
  }
}

let costCenterItems = [];
const selectedCostCenterNos = new Set();
const costCenterSelectedItems = new Map();
const costCenterSearchState = {
  page: 1,
  pageSize: 25,
  totalCount: 0,
  totalPages: 0
};

function getCostCenterSearchPayload(page = costCenterSearchState.page) {
  const pageSize = parseInt($('costCenterPageSize')?.value || costCenterSearchState.pageSize, 10) || 25;
  costCenterSearchState.pageSize = pageSize;
  return {
    ficheNo: normalizeSearchId($('costCenterFicheNo')?.value),
    page,
    pageSize
  };
}

function validateCostCenterSearchPayload(payload) {
  if (!payload.ficheNo) return 'شماره فیش را وارد کنید';
  return null;
}

function updateCostCenterPaginationUi() {
  const bar = $('costCenterPagination');
  const label = $('costCenterPageLabel');
  const prevBtn = $('btnCostCenterPrevPage');
  const nextBtn = $('btnCostCenterNextPage');
  if (!bar || !label || !prevBtn || !nextBtn) return;

  const { page, totalPages, totalCount } = costCenterSearchState;
  const show = totalCount > 0;
  bar.hidden = !show;
  if (!show) return;

  label.textContent = `صفحه ${page.toLocaleString('fa-IR')} از ${Math.max(totalPages, 1).toLocaleString('fa-IR')}`;
  prevBtn.disabled = page <= 1;
  nextBtn.disabled = page >= totalPages;
}

function syncCostCenterUpdateButton() {
  const btn = $('btnCostCenterUpdate');
  if (!btn) return;
  const centerOne = ($('costCenterOne')?.value || '').trim();
  const centerTwo = ($('costCenterTwo')?.value || '').trim();
  const hasCenters = !!centerOne && !!centerTwo;
  btn.disabled = selectedCostCenterNos.size === 0 || !hasCenters;
  const applySection = $('costCenterApplySection');
  if (applySection) applySection.hidden = selectedCostCenterNos.size === 0;
}

function updateCostCenterCountLabel() {
  const countLabel = $('costCenterCountLabel');
  if (!countLabel) return;
  const selectedTotal = selectedCostCenterNos.size;
  const pageInfo = `${costCenterItems.length.toLocaleString('fa-IR')} مورد در این صفحه — ${costCenterSearchState.totalCount.toLocaleString('fa-IR')} مورد کل`;
  countLabel.textContent = selectedTotal > 0
    ? `${pageInfo} — ${selectedTotal.toLocaleString('fa-IR')} انتخاب‌شده`
    : pageInfo;
}

function formatCostCenterValue(value) {
  if (value == null || value === '') return '-';
  return toPersianDigits(String(value));
}

function renderCostCenterTable(items, meta = {}) {
  costCenterItems = items || [];
  if (meta.page != null) costCenterSearchState.page = meta.page;
  if (meta.pageSize != null) costCenterSearchState.pageSize = meta.pageSize;
  if (meta.totalCount != null) costCenterSearchState.totalCount = meta.totalCount;
  if (meta.totalPages != null) costCenterSearchState.totalPages = meta.totalPages;

  const section = $('costCenterResultsSection');
  const tbody = $('costCenterTable')?.querySelector('tbody');
  const selectAll = $('costCenterSelectAll');
  if (!section || !tbody) return;

  section.hidden = false;

  if (costCenterItems.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-row">موردی یافت نشد</td></tr>';
    updateCostCenterCountLabel();
    updateCostCenterPaginationUi();
    syncCostCenterUpdateButton();
    return;
  }

  tbody.innerHTML = costCenterItems.map((item) => {
    const checked = selectedCostCenterNos.has(item.ficheNo) ? ' checked' : '';
    return `<tr>
      <td class="col-check"><input type="checkbox" class="cost-center-row-check" data-fiche-no="${item.ficheNo}"${checked} /></td>
      <td>${toPersianDigits(item.ficheNo || '-')}</td>
      <td>${formatCostCenterValue(item.deposit)}</td>
      <td>${formatCostCenterValue(item.creditorPapers)}</td>
      <td>${formatNosaziCode(item.nosaziCode)}</td>
      <td>${toPersianDigits(item.billId || '-')}</td>
      <td>${toPersianDigits(item.paymentId || '-')}</td>
    </tr>`;
  }).join('');

  tbody.querySelectorAll('.cost-center-row-check').forEach((cb) => {
    cb.addEventListener('change', () => {
      const ficheNo = cb.dataset.ficheNo;
      const item = costCenterItems.find((row) => row.ficheNo === ficheNo);
      setGridRowSelected(selectedCostCenterNos, costCenterSelectedItems, item || { ficheNo }, cb.checked);
      syncCostCenterUpdateButton();
      if (selectAll) {
        const all = tbody.querySelectorAll('.cost-center-row-check');
        selectAll.checked = all.length > 0 && Array.from(all).every((x) => x.checked);
      }
      updateCostCenterCountLabel();
    });
  });

  updateCostCenterCountLabel();
  if (selectAll) {
    const selectedOnPage = costCenterItems.filter((item) => selectedCostCenterNos.has(item.ficheNo)).length;
    selectAll.checked = costCenterItems.length > 0 && selectedOnPage === costCenterItems.length;
  }
  updateCostCenterPaginationUi();
  syncCostCenterUpdateButton();
}

async function fetchCostCenterResults(page = 1, { clearSelection = false } = {}) {
  const payload = getCostCenterSearchPayload(page);
  const validationError = validateCostCenterSearchPayload(payload);
  if (validationError) return showAppWarning(validationError);

  if (clearSelection) clearGridSelection(selectedCostCenterNos, costCenterSelectedItems);
  costCenterSearchState.page = page;

  const btn = $('btnCostCenterSearch');
  const prevBtn = $('btnCostCenterPrevPage');
  const nextBtn = $('btnCostCenterNextPage');
  const box = $('costCenterResultBox');
  if (btn) btn.disabled = true;
  if (prevBtn) prevBtn.disabled = true;
  if (nextBtn) nextBtn.disabled = true;

  try {
    const res = await apiFetch('/api/cost-center/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
    renderCostCenterTable(data.items || [], {
      page: data.page,
      pageSize: data.pageSize,
      totalCount: data.totalCount,
      totalPages: data.totalPages
    });
    if (box) box.hidden = true;
  } catch (e) {
    renderCostCenterTable([], { page: 1, pageSize: payload.pageSize, totalCount: 0, totalPages: 0 });
    if (box) {
      box.hidden = false;
      box.textContent = e.message;
    }
    showAppError(e.message);
  } finally {
    if (btn) btn.disabled = false;
    updateCostCenterPaginationUi();
  }
}

function getCostCenterUpdatePayload() {
  return {
    ficheNos: Array.from(selectedCostCenterNos),
    centerOne: ($('costCenterOne')?.value || '').trim(),
    centerTwo: ($('costCenterTwo')?.value || '').trim()
  };
}

function validateCostCenterUpdatePayload(payload) {
  if (!payload.ficheNos.length) return 'حداقل یک فیش از نتایج انتخاب کنید';
  if (!payload.centerOne) return 'مرکز یک را وارد کنید';
  if (!payload.centerTwo) return 'مرکز دو را وارد کنید';
  if (!/^\d+$/.test(normalizeSearchId(payload.centerOne))) return 'مرکز یک باید عدد باشد';
  if (!/^\d+$/.test(normalizeSearchId(payload.centerTwo))) return 'مرکز دو باید عدد باشد';
  return null;
}

function formatCostCenterUpdateResult(data) {
  const lines = (data.results || []).map((r) => `${r.ficheNo}: ${r.success ? 'OK' : 'FAIL'} — ${r.message || ''}`);
  return [
    '=== نتیجه UPDATE Income_Fiche (مرکز هزینه) ===',
    `DryRun: ${data.dryRun}`,
    `Deposit (مرکز یک): ${data.deposit ?? '-'}`,
    `CreditorPapers (مرکز دو): ${data.creditorPapers ?? '-'}`,
    data.dryRun
      ? `شبیه‌سازی — ${data.wouldUpdate || 0} فیش UPDATE می‌شد | بدون نتیجه: ${data.notFound}`
      : `به‌روز: ${data.updated || 0} | بدون نتیجه: ${data.notFound} | خطا: ${data.failed}`,
    '',
    ...lines
  ].join('\n');
}

function getBankInquiryConfirmPayload() {
  return {
    ficheNos: Array.from(selectedBankInquiryNos),
    newPaymentDate: ($('bankInquiryNewPaymentDate')?.value || '').trim()
  };
}

function validateBankInquiryConfirmPayload(payload) {
  if (!payload.ficheNos.length) return 'حداقل یک فیش از نتایج انتخاب کنید';
  if (!payload.newPaymentDate) return 'تاریخ پرداخت جدید را وارد کنید';
  return null;
}

function formatBankInquiryConfirmResult(data) {
  const lines = (data.results || []).map((r) => {
    const cached = bankInquirySelectedItems.get(r.ficheNo);
    const nosazi = cached?.nosaziCode;
    const workItem = cached?.nidWorkItem;
    const nosaziPart = nosazi ? ` | کد نوسازی: ${formatNosaziCode(nosazi)}` : '';
    const workItemPart = workItem ? ` | شماره فرآیند: ${toPersianDigits(workItem)}` : '';
    const inquiryPart = r.bankInquiryMessage
      ? ` | استعلام${r.bankInquirySource ? ` (${r.bankInquirySource})` : ''}: ${r.bankInquiryMessage}`
      : '';
    const billPart = r.billId ? ` | قبض: ${toPersianDigits(r.billId)}` : '';
    const payPart = r.paymentId ? ` | پرداخت: ${toPersianDigits(r.paymentId)}` : '';
    return `${r.ficheNo}: ${r.success ? 'OK' : 'FAIL'} — ${r.message || ''}${billPart}${payPart}${inquiryPart}${workItemPart}${nosaziPart}`;
  });
  return [
    '=== نتیجه UPDATE Income_Fiche (خدمات الکترونیک) ===',
    `DryRun: ${data.dryRun}`,
    data.dryRun
      ? `شبیه‌سازی — ${data.wouldUpdate || 0} فیش UPDATE می‌شد | بدون نتیجه: ${data.notFound}`
      : `به‌روز: ${data.updated || 0} | بدون نتیجه: ${data.notFound} | خطا: ${data.failed}`,
    `استعلام بانک: ${config?.bankInquiryConfirm?.serviceConfigured ? 'پیکربندی شده' : 'نیاز به UserName/Password'}`,
    `سرویس قبوض: ${config?.bankInquiryConfirm?.ficheLookupServiceUrl || '-'}`,
    `سرویس آنی: ${config?.bankInquiryConfirm?.onlineBankServiceUrl || '-'}`,
    `PaymentDate جدید: ${data.paymentDate || '-'}`,
    `UserConfirmDate: ${data.userConfirmDate || '-'}`,
    `UsernameUserConfirm: ${data.usernameUserConfirm || '-'}`,
    `EumFicheStatus → ${data.newEumFicheStatus}`,
    `EumIncomePaymentType → ${data.newEumIncomePaymentType}`,
    '',
    ...lines
  ].join('\n');
}

function formatBankInquiryDiagnoseStep(step) {
  if (!step) return ['  (فراخوانی نشد)'];
  const lines = [
    `  URL: ${step.url}`,
    `  درخواست: ${step.requestBody}`,
    `  HTTP: ${step.httpStatus ?? '-'} | زمان: ${step.elapsedMs} ms`,
    `  نتیجه: ${step.kind} — ${step.message || ''}`
  ];
  if (step.paymentDate) lines.push(`  تاریخ پرداخت: ${step.paymentDate}`);
  if (step.exception) lines.push(`  خطا: ${step.exception}`);
  lines.push(`  پاسخ خام: ${step.rawResponse || '(خالی)'}`);
  return lines;
}

function formatBankInquiryDiagnoseResult(data) {
  return [
    '=== تست مستقیم سرویس‌های استعلام epay (بدون تغییر در دیتابیس) ===',
    `شناسه قبض: ${data.billId} | شناسه پرداخت: ${data.payId}`,
    `کاربر: ${data.userName} | رمز: ${data.passwordConfigured ? 'تنظیم شده' : 'خالی!'} | پیکربندی: ${data.configured ? 'کامل' : 'ناقص'}`,
    ...(data.error ? [`خطا: ${data.error}`] : []),
    '',
    '--- مرحله ۱: استعلام قبوض (epay_FindFichesByBillIDPayID) ---',
    ...formatBankInquiryDiagnoseStep(data.ficheLookup),
    '',
    '--- مرحله ۲: استعلام آنی بانک (epay_EstelamOnLineBank) ---',
    ...formatBankInquiryDiagnoseStep(data.onlineBank)
  ].join('\n');
}

function getBankInquiryDiagnoseIds() {
  const billId = ($('bankInquiryBillId')?.value || '').trim();
  const paymentId = ($('bankInquiryPaymentId')?.value || '').trim();
  if (billId && paymentId) return { billId, paymentId };

  const firstSelected = Array.from(selectedBankInquiryNos)
    .map((no) => bankInquirySelectedItems.get(no))
    .find((item) => item?.billId && item?.paymentId);
  if (firstSelected) return { billId: firstSelected.billId, paymentId: firstSelected.paymentId };

  const firstRow = (bankInquiryItems || []).find((item) => item?.billId && item?.paymentId);
  if (firstRow) return { billId: firstRow.billId, paymentId: firstRow.paymentId };
  return null;
}

function setupBankInquiryDiagnoseHandler() {
  bindClick('btnBankInquiryDiagnose', async () => {
    const ids = getBankInquiryDiagnoseIds();
    if (!ids) return showAppWarning('شناسه قبض و شناسه پرداخت را وارد کنید یا یک فیش را از نتایج جستجو انتخاب کنید');

    const btn = $('btnBankInquiryDiagnose');
    const box = $('bankInquiryDiagnoseBox');
    btn.disabled = true;
    if (box) {
      box.hidden = false;
      box.textContent = 'در حال فراخوانی سرویس‌های استعلام…';
    }
    try {
      const res = await apiFetch('/api/bank-inquiry/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ids)
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      if (box) box.textContent = formatBankInquiryDiagnoseResult(data);
      const paid = data.ficheLookup?.kind === 'Paid' || data.onlineBank?.kind === 'Paid';
      if (paid) showAppSuccess('فیش در استعلام بانک پرداخت‌شده است');
      else showAppInfo('نتیجه تست سرویس‌ها در کادر زیر نمایش داده شد');
    } catch (e) {
      if (box) box.textContent = e.message;
      showAppError(e.message);
    } finally {
      btn.disabled = false;
    }
  });
}

/** همان منطق سرور IdentifierDetector — فقط برای نمایش راهنما */
function detectIdentifierType(value) {
  const v = (value || '').trim();
  if (!v) return null;
  if (v.includes('/')) return 'FicheNo';
  if (/^\d+$/.test(v) && v.length >= 20) return 'BillPaymentKey';
  return 'FicheNo';
}

const identifierTypeLabels = {
  FicheNo: 'شماره فیش (FicheNo)',
  BillPaymentKey: 'BillID + PaymentID'
};

function updateIdentifierHint() {
  const hint = $('identifierHint');
  const input = $('identifierValue');
  if (!hint || !input) return;
  const t = detectIdentifierType(input.value);
  if (!t) {
    hint.hidden = true;
    hint.textContent = '';
    return;
  }
  hint.hidden = false;
  hint.textContent = `تشخیص سیستم: ${identifierTypeLabels[t]}`;
}

function isTahatorFiche(f) {
  const g = f?.incomeAccountGroup;
  return g === 157 || g === 158;
}

function isTahatorAmountFiche(f) {
  return f?.incomeAccountGroup === 157;
}

function isTahatorIncomeDetailFiche(f) {
  return f?.incomeAccountGroup === 158;
}

/** هر دو فیش تهاتر (۱۵۷+۱۵۸) از API /api/tahator/send استفاده می‌کنند. */
function isTahatorIncomeFiche(f) {
  return isTahatorFiche(f);
}

let datePickersReady = false;

function initDatePickers() {
  if (typeof jalaliDatepicker === 'undefined') {
    console.warn('jalaliDatepicker load نشد — فایل lib/jalalidatepicker را چک کنید');
    return;
  }
  if (!datePickersReady) {
    jalaliDatepicker.startWatch({
      time: false,
      autoShow: true,
      autoHide: true,
      hideAfterChange: true,
      autoReadOnlyInput: false,
      persianDigits: false,
      zIndex: 2500,
      container: 'body',
      selector: 'input[data-jdp]',
      separatorChars: { date: '/', between: ' ', time: ':' }
    });
    datePickersReady = true;
  }

  document.querySelectorAll('.btn-date-icon').forEach((btn) => {
    if (btn.dataset.bound === '1') return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const input = document.getElementById(btn.dataset.for || '');
      if (!input || input.disabled) return;
      input.focus();
      setTimeout(() => jalaliDatepicker.show(input), 0);
    });
  });
}

function getSelectedUnsentFicheNos() {
  return Array.from(selectedUnsentFicheNos);
}

function getUnsentSearchFilters() {
  const fromDate = ($('unsentFromDate')?.value || '').trim();
  const toDate = ($('unsentToDate')?.value || '').trim();
  return {
    ficheKind: $('unsentFicheKind').value,
    ficheNo: normalizeSearchId($('unsentFicheNo')?.value),
    fromDate: fromDate || null,
    toDate: toDate || null,
    billId: normalizeSearchId($('unsentBillId')?.value),
    paymentId: normalizeSearchId($('unsentPaymentId')?.value),
    district: branchIdToDistrict($('unsentDistrict')?.value)
  };
}

function validateUnsentSearchFilters(filters) {
  if ((filters.fromDate && !filters.toDate) || (!filters.fromDate && filters.toDate)) {
    return 'هر دو تاریخ از و تا را وارد کنید';
  }
  const hasAny = filters.ficheNo || filters.billId || filters.paymentId || filters.district
    || (filters.fromDate && filters.toDate);
  if (!hasAny) {
    return 'حداقل یکی از شماره فیش، شناسه قبض، شناسه پرداخت، منطقه یا بازه تاریخ را وارد کنید';
  }
  return null;
}

function updateUnsentPaginationUi() {
  const bar = $('unsentPagination');
  const label = $('unsentPageLabel');
  const prevBtn = $('btnUnsentPrevPage');
  const nextBtn = $('btnUnsentNextPage');
  if (!bar || !label || !prevBtn || !nextBtn) return;

  const { page, totalPages, totalCount } = unsentSearchState;
  const hasResults = totalCount > 0;
  bar.hidden = !hasResults;

  if (!hasResults) {
    label.textContent = '';
    prevBtn.disabled = true;
    nextBtn.disabled = true;
    return;
  }

  label.textContent = `صفحه ${page.toLocaleString('fa-IR')} از ${totalPages.toLocaleString('fa-IR')} — ${totalCount.toLocaleString('fa-IR')} مورد`;
  prevBtn.disabled = page <= 1;
  nextBtn.disabled = page >= totalPages;
}

function updateUnsentSendButton() {
  const btn = $('btnUnsentSend');
  if (!btn) return;
  const selected = getSelectedUnsentFicheNos().length;
  btn.disabled = selected === 0;
  btn.textContent = selected > 0
    ? `ارسال ${selected} فیش انتخاب‌شده`
    : 'ارسال انتخاب‌شده‌ها';
}

function renderUnsentTable(items, meta = {}) {
  unsentItems = items || [];
  if (meta.page != null) unsentSearchState.page = meta.page;
  if (meta.pageSize != null) unsentSearchState.pageSize = meta.pageSize;
  if (meta.totalCount != null) unsentSearchState.totalCount = meta.totalCount;
  if (meta.totalPages != null) unsentSearchState.totalPages = meta.totalPages;

  const section = $('unsentResultsSection');
  const tbody = $('unsentTable')?.querySelector('tbody');
  const countLabel = $('unsentCountLabel');
  const selectAll = $('unsentSelectAll');
  if (!section || !tbody) return;

  if (!unsentItems.length) {
    section.hidden = false;
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">موردی یافت نشد</td></tr>';
    if (countLabel) {
      countLabel.textContent = unsentSearchState.totalCount > 0
        ? `۰ مورد در این صفحه — ${unsentSearchState.totalCount.toLocaleString('fa-IR')} مورد کل`
        : '۰ مورد';
    }
    if (selectAll) selectAll.checked = false;
    updateUnsentPaginationUi();
    updateUnsentSendButton();
    return;
  }

  section.hidden = false;
  tbody.innerHTML = unsentItems.map((item) => {
    const checked = selectedUnsentFicheNos.has(item.ficheNo) ? ' checked' : '';
    return `
    <tr>
      <td class="col-check"><input type="checkbox" class="unsent-row-check" data-fiche-no="${item.ficheNo}"${checked} /></td>
      <td>${item.subKindLabel || (item.isTahator ? 'تهاتر' : '-')}</td>
      <td class="num-cell col-unsent-bill">${formatBillPayDisplay(item.billId)}</td>
      <td class="num-cell col-unsent-pay">${formatBillPayDisplay(item.paymentId)}</td>
      <td class="num-cell col-unsent-fiche">${formatBillPayDisplay(item.ficheNo)}</td>
      <td class="col-installment-cost">${Number(item.payable || 0).toLocaleString('fa-IR')}</td>
      <td class="col-unsent-fill" aria-hidden="true"></td>
    </tr>
  `;
  }).join('');

  const selectedOnPage = unsentItems.filter((item) => selectedUnsentFicheNos.has(item.ficheNo)).length;
  if (countLabel) {
    const selectedTotal = selectedUnsentFicheNos.size;
    const pageInfo = `${unsentItems.length.toLocaleString('fa-IR')} مورد در این صفحه — ${unsentSearchState.totalCount.toLocaleString('fa-IR')} مورد کل`;
    countLabel.textContent = selectedTotal > 0
      ? `${pageInfo} | ${selectedTotal.toLocaleString('fa-IR')} انتخاب‌شده`
      : pageInfo;
  }
  if (selectAll) {
    selectAll.checked = unsentItems.length > 0 && selectedOnPage === unsentItems.length;
  }

  document.querySelectorAll('.unsent-row-check').forEach((cb) => {
    cb.addEventListener('change', () => {
      const ficheNo = cb.dataset.ficheNo;
      if (!ficheNo) return;
      if (cb.checked) selectedUnsentFicheNos.add(ficheNo);
      else selectedUnsentFicheNos.delete(ficheNo);

      const all = document.querySelectorAll('.unsent-row-check');
      const checked = document.querySelectorAll('.unsent-row-check:checked');
      if (selectAll) selectAll.checked = all.length > 0 && checked.length === all.length;
      updateUnsentSendButton();
      const countLabelEl = $('unsentCountLabel');
      if (countLabelEl && unsentSearchState.totalCount > 0) {
        const selectedTotal = selectedUnsentFicheNos.size;
        const pageInfo = `${unsentItems.length.toLocaleString('fa-IR')} مورد در این صفحه — ${unsentSearchState.totalCount.toLocaleString('fa-IR')} مورد کل`;
        countLabelEl.textContent = selectedTotal > 0
          ? `${pageInfo} | ${selectedTotal.toLocaleString('fa-IR')} انتخاب‌شده`
          : pageInfo;
      }
    });
  });
  updateUnsentPaginationUi();
  updateUnsentSendButton();
}

async function fetchUnsentResults(page = 1, { clearSelection = false } = {}) {
  const filters = getUnsentSearchFilters();
  const validationError = validateUnsentSearchFilters(filters);
  if (validationError) {
    showAppWarning(validationError);
    return false;
  }

  const pageSize = parseInt($('unsentPageSize')?.value || unsentSearchState.pageSize, 10) || 25;
  unsentSearchState.pageSize = pageSize;
  unsentSearchState.filters = filters;
  if (clearSelection) {
    selectedUnsentFicheNos.clear();
    unsentSourceKindByFicheNo.clear();
  }

  const btn = $('btnUnsentSearch');
  const prevBtn = $('btnUnsentPrevPage');
  const nextBtn = $('btnUnsentNextPage');
  if (btn) btn.disabled = true;
  if (prevBtn) prevBtn.disabled = true;
  if (nextBtn) nextBtn.disabled = true;
  const prevLabel = btn?.textContent;
  if (btn) btn.textContent = 'در حال جستجو…';
  $('unsentResultBox').hidden = true;

  try {
    const res = await apiFetch('/api/unsent/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...filters,
        page,
        pageSize
      })
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);

    const totalCount = data.totalCount ?? data.count ?? 0;
    const totalPages = data.totalPages ?? (data.pageSize > 0 ? Math.ceil(totalCount / data.pageSize) : 0);
    const items = data.items || [];
    syncUnsentSourceKindsFromItems(items, filters.ficheKind);
    renderUnsentTable(items, {
      page: data.page ?? page,
      pageSize: data.pageSize ?? pageSize,
      totalCount,
      totalPages
    });
    return true;
  } catch (e) {
    showAppError(e.message);
    renderUnsentTable([], { page: 1, pageSize, totalCount: 0, totalPages: 0 });
    return false;
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = prevLabel || 'جستجو';
    }
    updateUnsentPaginationUi();
  }
}

function formatShamsiInput(yyyymmdd) {
  if (!yyyymmdd) return '';
  const d = String(yyyymmdd).replace(/\D/g, '');
  if (d.length < 8) return String(yyyymmdd);
  return `${d.slice(0, 4)}/${d.slice(4, 6)}/${d.slice(6, 8)}`;
}

function applyFicheDatesToForm(f) {
  $('docDate').value = formatShamsiInput(f.rayvarzDocDate);
  $('actDate').value = formatShamsiInput(f.rayvarzActDate);
  $('dueDate').value = formatShamsiInput(f.rayvarzDueDate);
}

function getPayload(resetStatus) {
  return {
    fiche: currentFiche,
    branch: parseInt($('branch').value),
    fund: parseInt($('fund').value),
    docDate: $('docDate').value,
    actDate: $('actDate').value,
    dueDate: $('dueDate').value,
    resetStatus: !!resetStatus
  };
}

async function parseJsonResponse(res) {
  const text = await res.text();
  if (!text || !text.trim()) {
    throw new Error(`پاسخ خالی از سرور (HTTP ${res.status}). برنامه dotnet run را چک کنید و connection string را در appsettings.json تنظیم کنید.`);
  }
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`پاسخ نامعتبر از سرور (HTTP ${res.status}): ${text.slice(0, 300)}`);
  }
}

async function loadAuthMode() {
  if (authMode) return authMode;
  try {
    const res = await fetch('/api/auth/mode', { credentials: 'include' });
    if (res.ok) authMode = await res.json();
  } catch {
    // ignore
  }
  return authMode;
}

async function redirectToLogin() {
  const mode = await loadAuthMode();
  const path = mode?.allowHybridLocalLogin || !mode?.preferSsoLogin
    ? '/login.html'
    : (mode.loginPath || '/auth/login');
  window.location.href = path;
}

async function apiFetch(url, options = {}) {
  const res = await fetch(url, { credentials: 'include', ...options });
  if (res.status === 401) {
    redirectToLogin();
    throw new Error('نشست منقضی شده — دوباره وارد شوید');
  }
  return res;
}

function readIsAdminFlag(user) {
  if (!user) return false;
  const raw = user.isAdmin ?? user.IsAdmin;
  return raw === true || raw === 1 || raw === '1' || raw === 'true';
}

function normalizeAuthSession(user) {
  if (!user) return user;
  if (readIsAdminFlag(user)) {
    user.isAdmin = true;
    user.canAccessUnsentFiches = true;
    user.canAccessInstallment = true;
    user.canAccessFicheDateChange = true;
    user.canAccessBankInquiryConfirm = true;
    user.canAccessCostCenter = true;
    user.canAccessShahkar = true;
    user.canManageUsers = true;
  }
  return user;
}

function isAdminUser() {
  return readIsAdminFlag(currentUser);
}

function canAccessUnsent() {
  return isAdminUser() || !!currentUser?.canAccessUnsentFiches;
}

function hasAnyModulePermission() {
  if (isAdminUser()) return true;
  return !!(
    currentUser?.canAccessUnsentFiches
    || currentUser?.canAccessInstallment
    || currentUser?.canAccessFicheDateChange
    || currentUser?.canAccessBankInquiryConfirm
    || currentUser?.canAccessCostCenter
    || currentUser?.canAccessShahkar
    || currentUser?.canManageUsers
  );
}

/** تب رایورز: ارسال جمعی، یا ارسال تکی وقتی هیچ ماژول دیگری تعریف نشده */
function canAccessRayvarzModule() {
  if (isAdminUser()) return true;
  if (canAccessUnsent()) return true;
  return !hasAnyModulePermission();
}

const MAIN_TAB_ACCESS_ORDER = [
  { key: 'unsent', can: () => canAccessRayvarzModule() },
  { key: 'installment', can: () => canAccessInstallment() },
  { key: 'ficheDate', can: () => canAccessFicheDateChange() },
  { key: 'bankInquiry', can: () => canAccessBankInquiryConfirm() },
  { key: 'costCenter', can: () => canAccessCostCenter() },
  { key: 'shahkar', can: () => canAccessShahkar() },
  { key: 'users', can: () => canManageUsers() }
];

function canAccessInstallment() {
  return isAdminUser() || !!currentUser?.canAccessInstallment;
}

function canAccessFicheDateChange() {
  return isAdminUser() || !!currentUser?.canAccessFicheDateChange;
}

function canAccessBankInquiryConfirm() {
  return isAdminUser() || !!currentUser?.canAccessBankInquiryConfirm;
}

function canAccessCostCenter() {
  return isAdminUser() || !!currentUser?.canAccessCostCenter;
}

function canAccessShahkar() {
  return isAdminUser() || !!currentUser?.canAccessShahkar;
}

function canManageUsers() {
  return isAdminUser() || !!currentUser?.canManageUsers;
}

function isCenterUser() {
  return !isAdminUser() && getUserDistrict() === '102';
}

function applyPermissionUi() {
  document.querySelectorAll('.perm-rayvarz').forEach((el) => {
    el.hidden = !canAccessRayvarzModule();
  });
  document.querySelectorAll('.perm-unsent').forEach((el) => {
    el.hidden = !canAccessUnsent();
  });
  document.querySelectorAll('.perm-installment').forEach((el) => {
    el.hidden = !canAccessInstallment();
  });
  document.querySelectorAll('.perm-fiche-date').forEach((el) => {
    el.hidden = !canAccessFicheDateChange();
  });
  document.querySelectorAll('.perm-bank-inquiry').forEach((el) => {
    el.hidden = !canAccessBankInquiryConfirm();
  });
  document.querySelectorAll('.perm-cost-center').forEach((el) => {
    el.hidden = !canAccessCostCenter();
  });
  document.querySelectorAll('.perm-shahkar').forEach((el) => {
    el.hidden = !canAccessShahkar();
  });
  document.querySelectorAll('.perm-users').forEach((el) => {
    el.hidden = !canManageUsers();
  });
  if (!canAccessUnsent() && rayvarzSendMode === 'bulk') {
    setRayvarzSendMode('single');
  }
}

function defaultMainTabKey() {
  const first = MAIN_TAB_ACCESS_ORDER.find((t) => t.can());
  return first?.key ?? 'unsent';
}

function readInitialMainTabKey() {
  const tab = (new URLSearchParams(window.location.search).get('tab') || '').trim();
  if (!tab) return defaultMainTabKey();
  const match = MAIN_TAB_ACCESS_ORDER.find((t) => t.key === tab && t.can());
  return match?.key ?? defaultMainTabKey();
}

function defaultRayvarzSendMode() {
  return canAccessUnsent() ? 'bulk' : 'single';
}

function applyAuthUi() {
  applyPermissionUi();

  const heroUser = $('heroUser');
  if (heroUser && currentUser) {
    heroUser.hidden = false;
    $('userDisplayName').textContent = currentUser.displayName || currentUser.username;
    const districtLabel = getUserDistrict() ? districtLabelFromValue(getUserDistrict()) : '';
    $('userRoleBadge').textContent = isAdminUser()
      ? 'ادمین'
      : isCenterUser()
        ? 'کاربر — شعبه مرکز'
        : (districtLabel ? `کاربر — ${districtLabel}` : 'کاربر');
    $('userRoleBadge').className = `user-badge ${isAdminUser() ? 'badge-admin' : 'badge-user'}`;
  }

  activateMainTab(readInitialMainTabKey());
  setRayvarzSendMode(defaultRayvarzSendMode());
}

async function ensureAuthenticated() {
  const res = await fetch('/api/auth/me', { credentials: 'include' });
  if (!res.ok) {
    redirectToLogin();
    return false;
  }
  currentUser = normalizeAuthSession(await res.json());
  document.body.classList.add('app-authenticated');
  applyAuthUi();
  return true;
}

function districtLabelFromValue(value) {
  if (!value) return '—';
  if (String(value) === '102') return 'شعبه مرکز (۱۰۲)';
  if (String(value) === FAVA_DISTRICT_VALUE) return 'فاوا';
  const branch = config?.branches?.find((b) => branchIdToDistrict(String(b.id)) === String(value));
  return branch ? branch.name : value;
}

async function loadUsersTable() {
  if (!canManageUsers()) return;
  const res = await apiFetch('/api/admin/users');
  const data = await parseJsonResponse(res);
  cachedUsers = (data.items || []).map(normalizeEntityId);
  const tbody = $('usersTable')?.querySelector('tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  cachedUsers.forEach((u) => {
    const tr = document.createElement('tr');
    const groupNames = (u.groupIds || [])
      .map((id) => cachedGroups.find((g) => String(g.id) === String(id))?.name)
      .filter(Boolean)
      .join('، ') || '—';
    tr.innerHTML = `
      <td>${u.nationalId || u.username}</td>
      <td dir="ltr">${u.domain || '—'}</td>
      <td>${u.firstName || '—'}</td>
      <td>${u.lastName || '—'}</td>
      <td>${u.position || '—'}</td>
      <td>${districtLabelFromValue(u.district)}</td>
      <td>${u.isAdmin ? 'ادمین' : 'کاربر'}</td>
      <td>${groupNames}</td>
      <td>${u.isActive ? 'فعال' : 'غیرفعال'}</td>
      <td><button type="button" class="btn secondary btn-sm btn-edit-user" data-user-id="${u.id}">ویرایش</button></td>
    `;
    tbody.appendChild(tr);
  });
}

let cachedGroups = [];
let cachedUsers = [];
let editingUserId = null;
let editingGroupId = null;

function normalizeEntityId(entity) {
  if (!entity || typeof entity !== 'object') return entity;
  const id = entity.id ?? entity.Id;
  return id != null ? { ...entity, id } : entity;
}

function syncGroupFormActions() {
  const createBtn = $('btnCreateGroup');
  const cancelBtn = $('btnCancelGroupEdit');
  const form = document.querySelector('.user-groups-form');
  if (createBtn) {
    createBtn.textContent = editingGroupId ? 'ذخیره تغییرات گروه' : 'ثبت گروه';
  }
  if (cancelBtn) cancelBtn.hidden = !editingGroupId;
  form?.classList.toggle('is-editing', !!editingGroupId);
}

function setupGroupsTableActions() {
  const table = $('groupsTable');
  const tbody = table?.querySelector('tbody');
  if (!tbody || tbody.dataset.actionsBound === '1') return;
  tbody.dataset.actionsBound = '1';
  tbody.addEventListener('click', async (e) => {
    const editBtn = e.target.closest('.btn-edit-group');
    if (editBtn) {
      e.preventDefault();
      openGroupEdit(editBtn.dataset.groupId);
      return;
    }
    const saveBtn = e.target.closest('.btn-save-group');
    if (saveBtn) {
      e.preventDefault();
      try {
        await saveGroupFromForm();
      } catch (err) {
        alert(err.message);
      }
    }
  });
}

function setupUsersTableActions() {
  const tbody = $('usersTable')?.querySelector('tbody');
  if (!tbody || tbody.dataset.actionsBound === '1') return;
  tbody.dataset.actionsBound = '1';
  tbody.addEventListener('click', (e) => {
    const editBtn = e.target.closest('.btn-edit-user');
    if (!editBtn) return;
    e.preventDefault();
    openUserEdit(editBtn.dataset.userId);
  });
}

async function loadGroupsTable() {
  if (!canManageUsers()) return;
  const res = await apiFetch('/api/admin/groups');
  const data = await parseJsonResponse(res);
  cachedGroups = (data.items || []).map(normalizeEntityId);
  renderGroupsTableBody();
  const editUser = editingUserId
    ? cachedUsers.find((u) => String(u.id) === String(editingUserId))
    : null;
  renderUserGroupsPickerMenu('newUserGroupsMenu', 'newUserGroupsTriggerLabel', []);
  renderUserGroupsPickerMenu(
    'editUserGroupsMenu',
    'editUserGroupsTriggerLabel',
    editUser?.groupIds || []
  );
}

function renderGroupsTableBody() {
  const tbody = $('groupsTable')?.querySelector('tbody');
  if (!tbody) return;
  tbody.innerHTML = '';
  cachedGroups.forEach((g) => {
    const isEditing = editingGroupId && String(editingGroupId) === String(g.id);
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${g.name}</td>
      <td>${g.canAccessUnsentFiches ? 'بله' : 'خیر'}</td>
      <td>${g.canAccessInstallment ? 'بله' : 'خیر'}</td>
      <td>${g.canManageUsers ? 'بله' : 'خیر'}</td>
      <td>${g.canAccessFicheDateChange ? 'بله' : 'خیر'}</td>
      <td>${g.canAccessBankInquiryConfirm ? 'بله' : 'خیر'}</td>
      <td>${g.canAccessShahkar ? 'بله' : 'خیر'}</td>
      <td>${g.canAccessCostCenter ? 'بله' : 'خیر'}</td>
      <td class="group-actions-cell">
        <button type="button" class="btn secondary btn-sm btn-edit-group" data-group-id="${g.id}">ویرایش</button>${isEditing ? ` <button type="button" class="btn primary btn-sm btn-save-group" data-group-id="${g.id}">ذخیره</button>` : ''}
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function openGroupEdit(groupId) {
  const group = cachedGroups.find((g) => String(g.id) === String(groupId));
  if (!group) return;
  editingGroupId = group.id;
  if ($('newGroupName')) $('newGroupName').value = group.name;
  if ($('newGroupUnsent')) $('newGroupUnsent').checked = group.canAccessUnsentFiches;
  if ($('newGroupInstallment')) $('newGroupInstallment').checked = group.canAccessInstallment;
  if ($('newGroupFicheDate')) $('newGroupFicheDate').checked = group.canAccessFicheDateChange;
  if ($('newGroupBankInquiry')) $('newGroupBankInquiry').checked = group.canAccessBankInquiryConfirm;
  if ($('newGroupShahkar')) $('newGroupShahkar').checked = group.canAccessShahkar;
  if ($('newGroupCostCenter')) $('newGroupCostCenter').checked = group.canAccessCostCenter;
  if ($('newGroupUsers')) $('newGroupUsers').checked = group.canManageUsers;
  updateUserGroupPermsTriggerLabel();
  syncGroupFormActions();
  renderGroupsTableBody();
  document.querySelector('.user-groups-form')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function resetGroupForm() {
  editingGroupId = null;
  if ($('newGroupName')) $('newGroupName').value = '';
  if ($('newGroupUnsent')) $('newGroupUnsent').checked = false;
  if ($('newGroupInstallment')) $('newGroupInstallment').checked = false;
  if ($('newGroupFicheDate')) $('newGroupFicheDate').checked = false;
  if ($('newGroupBankInquiry')) $('newGroupBankInquiry').checked = false;
  if ($('newGroupShahkar')) $('newGroupShahkar').checked = false;
  if ($('newGroupCostCenter')) $('newGroupCostCenter').checked = false;
  if ($('newGroupUsers')) $('newGroupUsers').checked = false;
  updateUserGroupPermsTriggerLabel();
  syncGroupFormActions();
  renderGroupsTableBody();
}

async function saveGroupFromForm({ forceCreate = false } = {}) {
  const payload = {
    name: ($('newGroupName')?.value || '').trim(),
    canAccessUnsentFiches: !!$('newGroupUnsent')?.checked,
    canAccessInstallment: !!$('newGroupInstallment')?.checked,
    canAccessFicheDateChange: !!$('newGroupFicheDate')?.checked,
    canAccessBankInquiryConfirm: !!$('newGroupBankInquiry')?.checked,
    canAccessShahkar: !!$('newGroupShahkar')?.checked,
    canAccessCostCenter: !!$('newGroupCostCenter')?.checked,
    canManageUsers: !!$('newGroupUsers')?.checked
  };
  if (!payload.name) return alert('نام گروه الزامی است');
  const isUpdate = !!editingGroupId && !forceCreate;
  const url = isUpdate
    ? `/api/admin/groups/${editingGroupId}`
    : '/api/admin/groups';
  const method = 'POST';
  const res = await apiFetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await parseJsonResponse(res);
  if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
  resetGroupForm();
  await loadGroupsTable();
  await loadUsersTable();
}

function updatePickerTriggerLabel(menuEl, labelEl, fallbackText) {
  if (!menuEl || !labelEl) return;
  const labels = Array.from(menuEl.querySelectorAll('input[type="checkbox"]:checked'))
    .map((el) => (el.dataset.groupName || el.dataset.permLabel || '').trim())
    .filter(Boolean);
  if (labels.length === 0) {
    labelEl.textContent = fallbackText;
    return;
  }
  if (labels.length === 1) {
    labelEl.textContent = labels[0];
    return;
  }
  labelEl.textContent = `${labels.length.toLocaleString('fa-IR')} مورد انتخاب‌شده`;
}

function renderUserGroupsPickerMenu(menuId, labelId, selectedIds = []) {
  const menu = $(menuId);
  const labelEl = $(labelId);
  if (!menu) return;
  menu.innerHTML = '';
  cachedGroups.forEach((g) => {
    const row = document.createElement('label');
    row.className = 'fiche-date-ms-option user-group-perm-option';
    row.setAttribute('role', 'option');
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.className = 'user-group-membership-check';
    input.value = g.id;
    input.dataset.groupName = g.name;
    input.checked = (selectedIds || []).some((id) => String(id) === String(g.id));
    input.addEventListener('change', () => updatePickerTriggerLabel(menu, labelEl, 'انتخاب گروه…'));
    const text = document.createElement('span');
    text.className = 'fiche-date-ms-option-text';
    text.textContent = g.name;
    row.appendChild(input);
    row.appendChild(text);
    menu.appendChild(row);
  });
  updatePickerTriggerLabel(menu, labelEl, 'انتخاب گروه…');
}

function readSelectedGroupIdsFromMenu(menuId) {
  const menu = $(menuId);
  if (!menu) return [];
  return Array.from(menu.querySelectorAll('.user-group-membership-check:checked')).map((el) => el.value);
}

function setupPickerDropdown({ wrapId, triggerId, menuId, labelId, fallbackLabel }) {
  const wrap = $(wrapId);
  const trigger = $(triggerId);
  const menu = $(menuId);
  const labelEl = $(labelId);
  if (!wrap || !trigger || !menu || trigger.dataset.bound === '1') return;
  trigger.dataset.bound = '1';
  trigger.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = menu.hidden;
    menu.hidden = !open;
    trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  menu.querySelectorAll('input[type="checkbox"]').forEach((input) => {
    input.addEventListener('change', () => updatePickerTriggerLabel(menu, labelEl, fallbackLabel));
  });
  document.addEventListener('click', (e) => {
    if (wrap.contains(e.target)) return;
    menu.hidden = true;
    trigger.setAttribute('aria-expanded', 'false');
  });
}

function readDirectPermissionsFromForm(prefix) {
  return {
    canAccessUnsentFiches: !!$(`${prefix}Unsent`)?.checked,
    canAccessInstallment: !!$(`${prefix}Installment`)?.checked,
    canAccessFicheDateChange: !!$(`${prefix}FicheDate`)?.checked,
    canAccessBankInquiryConfirm: !!$(`${prefix}BankInquiry`)?.checked,
    canAccessShahkar: !!$(`${prefix}Shahkar`)?.checked,
    canAccessCostCenter: !!$(`${prefix}CostCenter`)?.checked,
    canManageUsers: !!$(`${prefix}Users`)?.checked
  };
}

function allDirectPermissionsGranted() {
  return {
    canAccessUnsentFiches: true,
    canAccessInstallment: true,
    canAccessFicheDateChange: true,
    canAccessBankInquiryConfirm: true,
    canAccessShahkar: true,
    canAccessCostCenter: true,
    canManageUsers: true
  };
}

function syncAdminCheckboxDirectPermissions(adminCheckboxId, directPrefix) {
  const adminEl = $(adminCheckboxId);
  if (!adminEl) return;
  const sync = () => {
    if (adminEl.checked) setDirectPermissionsOnForm(directPrefix, allDirectPermissionsGranted());
  };
  adminEl.addEventListener('change', sync);
  sync();
}

function setDirectPermissionsOnForm(prefix, perms) {
  const p = perms || {};
  if ($(`${prefix}Unsent`)) $(`${prefix}Unsent`).checked = !!p.canAccessUnsentFiches;
  if ($(`${prefix}Installment`)) $(`${prefix}Installment`).checked = !!p.canAccessInstallment;
  if ($(`${prefix}FicheDate`)) $(`${prefix}FicheDate`).checked = !!p.canAccessFicheDateChange;
  if ($(`${prefix}BankInquiry`)) $(`${prefix}BankInquiry`).checked = !!p.canAccessBankInquiryConfirm;
  if ($(`${prefix}Shahkar`)) $(`${prefix}Shahkar`).checked = !!p.canAccessShahkar;
  if ($(`${prefix}CostCenter`)) $(`${prefix}CostCenter`).checked = !!p.canAccessCostCenter;
  if ($(`${prefix}Users`)) $(`${prefix}Users`).checked = !!p.canManageUsers;
  const menu = $(`${prefix}PermsMenu`);
  const labelEl = $(`${prefix}PermsTriggerLabel`);
  if (menu && labelEl) updatePickerTriggerLabel(menu, labelEl, 'انتخاب دسترسی…');
}

function setupUserManagementPickers() {
  setupPickerDropdown({
    wrapId: 'newUserGroupsMulti',
    triggerId: 'newUserGroupsTrigger',
    menuId: 'newUserGroupsMenu',
    labelId: 'newUserGroupsTriggerLabel',
    fallbackLabel: 'انتخاب گروه…'
  });
  setupPickerDropdown({
    wrapId: 'editUserGroupsMulti',
    triggerId: 'editUserGroupsTrigger',
    menuId: 'editUserGroupsMenu',
    labelId: 'editUserGroupsTriggerLabel',
    fallbackLabel: 'انتخاب گروه…'
  });
  setupPickerDropdown({
    wrapId: 'newUserDirectPermsMulti',
    triggerId: 'newUserDirectPermsTrigger',
    menuId: 'newUserDirectPermsMenu',
    labelId: 'newUserDirectPermsTriggerLabel',
    fallbackLabel: 'انتخاب دسترسی…'
  });
  setupPickerDropdown({
    wrapId: 'editUserDirectPermsMulti',
    triggerId: 'editUserDirectPermsTrigger',
    menuId: 'editUserDirectPermsMenu',
    labelId: 'editUserDirectPermsTriggerLabel',
    fallbackLabel: 'انتخاب دسترسی…'
  });
}

function resolveNewUserDistrict() {
  const raw = ($('newUserDistrict')?.value || '').trim();
  if (raw === FAVA_DISTRICT_VALUE) return FAVA_DISTRICT_VALUE;
  return branchIdToDistrict(raw);
}

function openUserEdit(userId) {
  const user = cachedUsers.find((u) => String(u.id) === String(userId));
  if (!user) return;
  editingUserId = user.id;
  const panel = $('userEditPanel');
  if (panel) panel.hidden = false;
  if ($('userEditTitle')) {
    $('userEditTitle').textContent = `${user.firstName} ${user.lastName} — ${user.nationalId || user.username}`;
  }
  if ($('editUserIsActive')) $('editUserIsActive').checked = !!user.isActive;
  if ($('editUserIsAdmin')) $('editUserIsAdmin').checked = !!user.isAdmin;
  if ($('editUserDomain')) $('editUserDomain').value = user.domain || '';
  if ($('editUserNewPassword')) $('editUserNewPassword').value = '';
  renderUserGroupsPickerMenu('editUserGroupsMenu', 'editUserGroupsTriggerLabel', user.groupIds || []);
  setDirectPermissionsOnForm('editUserDirect', user.directPermissions);
  panel?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function closeUserEdit() {
  editingUserId = null;
  const panel = $('userEditPanel');
  if (panel) panel.hidden = true;
}

async function saveUserEdit() {
  if (!editingUserId) return;
  const payload = {
    isAdmin: !!$('editUserIsAdmin')?.checked,
    isActive: !!$('editUserIsActive')?.checked,
    domain: ($('editUserDomain')?.value || '').trim(),
    groupIds: readSelectedGroupIdsFromMenu('editUserGroupsMenu'),
    directPermissions: readDirectPermissionsFromForm('editUserDirect')
  };
  const res = await apiFetch(`/api/admin/users/${editingUserId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  const data = await parseJsonResponse(res);
  if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
  closeUserEdit();
  await loadUsersTable();
}

async function resetUserPassword() {
  if (!editingUserId) return;
  const password = $('editUserNewPassword')?.value || '';
  const policyError = typeof validatePasswordPolicy === 'function' ? validatePasswordPolicy(password) : null;
  if (policyError) return alert(policyError);
  const res = await apiFetch(`/api/admin/users/${editingUserId}/reset-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password })
  });
  const data = await parseJsonResponse(res);
  if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
  if ($('editUserNewPassword')) $('editUserNewPassword').value = '';
  alert('رمز عبور با موفقیت تغییر کرد');
}

async function createUserFromForm() {
  const nationalId = ($('newUserNationalId')?.value || '').trim();
  const domain = ($('newUserDomain')?.value || '').trim();
  const payload = {
    username: nationalId,
    password: $('newUserPassword')?.value || '',
    firstName: ($('newUserFirstName')?.value || '').trim(),
    lastName: ($('newUserLastName')?.value || '').trim(),
    nationalId,
    domain,
    position: ($('newUserPosition')?.value || '').trim(),
    district: resolveNewUserDistrict(),
    isAdmin: !!$('newUserIsAdmin')?.checked,
    groupIds: readSelectedGroupIdsFromMenu('newUserGroupsMenu'),
    directPermissions: readDirectPermissionsFromForm('newUserDirect')
  };
  if (!payload.firstName || !payload.lastName || !payload.nationalId || !payload.password) {
    return alert('نام، نام خانوادگی، کد ملی و رمز عبور الزامی است');
  }
  if (!payload.domain) {
    return alert('دامین الزامی است (مثلاً hoseine-sh)');
  }
  if (payload.nationalId.length !== 10 || !/^\d+$/.test(payload.nationalId)) {
    return alert('کد ملی باید ۱۰ رقم باشد');
  }
  if (!payload.isAdmin && !payload.district) {
    return alert('برای کاربر منطقه‌ای، انتخاب منطقه یا شعبه مرکز الزامی است');
  }
  const passwordPolicyError = typeof validatePasswordPolicy === 'function'
    ? validatePasswordPolicy(payload.password)
    : null;
  if (passwordPolicyError) return alert(passwordPolicyError);
  const box = $('usersResultBox');
  try {
    const res = await apiFetch('/api/admin/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
    if (box) {
      box.hidden = false;
      box.textContent = `کاربر ${data.user?.nationalId || data.user?.username || nationalId} با دامین ${data.user?.domain || domain} ثبت شد.`;
    }
    $('newUserPassword').value = '';
    $('newUserNationalId').value = '';
    if ($('newUserDomain')) $('newUserDomain').value = '';
    await loadUsersTable();
  } catch (e) {
    if (box) {
      box.hidden = false;
      box.textContent = e.message;
    }
    alert(e.message);
  }
}

function formatDiagnostics(d) {
  if (!d) return '';
  const lines = [
    '--- Diagnostics ---',
    `Category: ${d.category || '-'}`,
    `Stage: ${d.stage || '-'}`,
    `ElapsedMs: ${d.elapsedMs ?? '-'}`,
    `PostUrl: ${d.postUrl || '-'}`,
    `HasWsAddressingHeader: ${d.hasWsAddressingHeader}`,
    `WsAddressingTo: ${d.wsAddressingTo || '-'}`,
    `EnvelopeStyle: ${d.envelopeStyle || '-'}`,
    `SoapAction: ${d.soapAction || '-'}`,
    `ContentType: ${d.contentType || '-'}`,
    `ProxyMode: ${d.proxyMode || '-'}`,
    `RequestBodyBytes: ${d.requestBodyBytes ?? '-'}`,
    `HttpStatusCode: ${d.httpStatusCode ?? '-'}`,
    `ResponseBodyBytes: ${d.responseBodyBytes ?? '-'}`
  ];
  if (d.likelyCause) lines.push(`LikelyCause: ${d.likelyCause}`);
  if (d.hint) lines.push(`Hint: ${d.hint}`);
  if (d.exceptionChain?.length) {
    lines.push('ExceptionChain:');
    d.exceptionChain.forEach((x) => lines.push(`  - ${x}`));
  }
  return lines.join('\n') + '\n';
}

function updateSendButton(f) {
  const btn = $('btnSend');
  if (!btn) return;
  if (!f) {
    btn.disabled = true;
    btn.title = 'ابتدا فیش را دریافت کنید';
    return;
  }
  if (isTahatorIncomeFiche(f)) {
    btn.disabled = false;
    btn.title = config?.tahator?.dryRun ?? config?.dryRun
      ? 'تهاتر — DryRun فعال'
      : 'ارسال فیش تهاتر (فقط شماره وارد شده) به رایورز';
    return;
  }
  if (!f.canSend) {
    btn.disabled = true;
    btn.title = f.blockReason || f.statusMessage || 'قابل ارسال نیست';
    return;
  }
  btn.disabled = false;
  btn.title = config?.dryRun
    ? 'DryRun فعال — ارسال آزمایشی'
    : 'ارسال به رایورز';
}

function renderSendResultCard(items, tone) {
  $('resultSection').hidden = false;
  const card = $('sendResultCard');
  if (!card) return;
  card.className = `send-result-card send-result-${tone}`;
  card.innerHTML = items.map((row) => `
    <div class="send-result-row">
      <div class="send-result-label">${row.label}</div>
      <div class="send-result-value">${row.value ?? '—'}</div>
    </div>
  `).join('');
}

function showSendResult(data) {
  const tone = data.success
    ? (data.verifiedInRayvarz === false ? 'warn' : 'ok')
    : 'err';
  const statusFa = data.dryRun
    ? 'آزمایشی — به رایورز ارسال نشد'
    : data.success
      ? (data.verifiedInRayvarz === false ? 'ارسال شد ولی در رایورز تأیید نشد' : 'ارسال موفق')
      : 'ارسال ناموفق';
  renderSendResultCard([
    { label: 'وضعیت', value: statusFa },
    { label: 'پیام', value: data.message || '—' },
    { label: 'شماره پیگیری', value: data.pursuitDocNo || '—' },
    { label: 'ثبت در رایورز', value: data.verifiedInRayvarz ? 'بله' : (data.verifiedInRayvarz === false ? 'خیر' : '—') },
    { label: 'واسط حسابداری', value: data.accountingDocWritten ? (data.accountingDocMessage || 'ثبت شد') : (data.accountingDocMessage || '—') },
    { label: 'خطای ارسال', value: data.docNotSentError || '—' },
    { label: 'هشدار', value: data.warning || '—' }
  ], tone);
}

function bnkAcntNoSource(f) {
  if (f.bnkAcntNoSource) return f.bnkAcntNoSource;
  if (f.category === 'Income') return 'کد نوسازی — Base_NosaziCode (فیش درآمد)';
  if (f.category === 'DutyNosazi' || f.category === 'DutySenfi') return 'کد نوسازی — Duty_Fiche.OtherFields (فیش نوسازی/صنفی)';
  return 'کد نوسازی';
}

function buildMappingRows(f) {
  const branch = config.branches.find(b => b.id === parseInt($('branch').value));
  const fund = $('fund').value;
  const region = f.dutyRegion || f.incomeRegion;
  return [
    { field: 'شماره فیش', value: f.ficheNo || '—' },
    { field: 'شناسه قبض', value: f.billId || '—' },
    { field: 'شناسه پرداخت', value: f.paymentId || '—' },
    { field: 'کد نوسازی', value: f.bnkAcntNo || '—' },
    { field: 'منطقه / شعبه', value: branch ? `${branch.id} — ${branch.name}` : (region ? `منطقه ${region}` : '—') },
    { field: 'منبع', value: fund || f.suggestedFund || '—' },
    { field: 'تاریخ سند', value: $('docDate').value || '—' },
    { field: 'تاریخ عملیات', value: $('actDate').value || '—' },
    { field: 'تاریخ سررسید', value: $('dueDate').value || '—' },
    { field: 'نوع سند', value: f.docDsc || f.docTypDsc || String(f.docTyp || '—') },
    { field: 'مبلغ قابل پرداخت', value: `${Number(f.payable || 0).toLocaleString('fa-IR')} ریال` },
    { field: 'تعداد ردیف درآمد', value: String((f.rows || []).length) }
  ];
}

function renderMappingTable(f) {
  const rows = buildMappingRows(f);
  $('mappingTable').innerHTML = rows.map(r => `
    <div class="mapping-row mapping-row-fa">
      <div class="mapping-field">${r.field}</div>
      <div class="mapping-value">${r.value}</div>
    </div>
  `).join('');
}

function renderFiche(f) {
  $('ficheSection').hidden = false;
  const alertHtml = f.blockReason
    ? `<div class="fiche-alert fiche-alert-err" role="alert">${f.blockReason}</div>`
    : '';

  $('ficheSummary').innerHTML = `
    ${alertHtml}
    <div class="stat-card">
      <span class="stat-label">شماره فیش</span>
      <span class="stat-value">${f.ficheNo}</span>
    </div>
    <div class="stat-card">
      <span class="stat-label">نوع</span>
      <span class="stat-value">${isTahatorAmountFiche(f) ? 'تهاتر (مبلغ — گروه ۱۵۷)' : isTahatorIncomeDetailFiche(f) ? 'تهاتر (درآمد — گروه ۱۵۸)' : (categoryLabels[f.category] || f.category)}</span>
    </div>
    <div class="stat-card">
      <span class="stat-label">مبلغ قابل پرداخت</span>
      <span class="stat-value money">${Number(f.payable).toLocaleString()} ریال</span>
    </div>
    <div class="stat-card">
      <span class="stat-label">منبع</span>
      <span class="stat-value">${$('fund')?.value || f.suggestedFund || '-'}</span>
    </div>
    <div class="stat-card">
      <span class="stat-label">کد نوسازی</span>
      <span class="stat-value">${f.bnkAcntNo || '-'}</span>
    </div>
  `;

  renderMappingTable(f);

  const rowsTitle = $('incomeRowsTitle');
  if (rowsTitle) {
    rowsTitle.textContent = isTahatorAmountFiche(f)
      ? 'ردیف تهاتر مبلغ (تک‌ردیف — بدون جزئیات Income_Calculation)'
      : isTahatorIncomeDetailFiche(f)
        ? 'ردیف‌های درآمد (جزئیات تهاتر)'
        : 'ردیف‌های درآمد';
  }

  const tbody = $('rowsTable').querySelector('tbody');
  tbody.innerHTML = '';
  (f.rows || []).forEach((r, i) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${i + 1}</td><td>${r.incmNo}</td><td>${r.incmRowDsc}</td><td>${Number(r.val).toLocaleString()}</td>`;
    tbody.appendChild(tr);
  });
}

async function init() {
  const authed = await ensureAuthenticated();
  if (!authed) return;

  try {
    const res = await apiFetch('/api/config');
    config = await parseJsonResponse(res);
    syncInstallmentDryRunUi();
  } catch (e) {
    alert(e.message);
    return;
  }

  const branchSel = $('branch');
  const fundSel = $('fund');
  fillBranchSelect(branchSel);
  fillBranchSelect($('unsentDistrict'), { includeAll: true });
  fillBranchSelect($('newUserDistrict'), { includeAll: true, allLabel: 'انتخاب منطقه' });
  fillFundSelect(fundSel);
  applyRegionalUserRestrictions();

  branchSel.onchange = () => { syncFundFromBranch(); if (currentFiche) renderMappingTable(currentFiche); };
  fundSel.onchange = () => { syncBranchFromFund(); if (currentFiche) renderMappingTable(currentFiche); };
  $('docDate').onchange = () => { if (currentFiche) renderMappingTable(currentFiche); };
  $('actDate').onchange = () => { if (currentFiche) renderMappingTable(currentFiche); };
  $('dueDate').onchange = () => { if (currentFiche) renderMappingTable(currentFiche); };
  $('identifierValue')?.addEventListener('input', updateIdentifierHint);
  const installmentInput = $('installmentValues');
  if (installmentInput) {
    installmentInput.addEventListener('input', () => {
      installmentInput.value = installmentInput.value.replace(/\D/g, '');
    });
  }

  document.querySelectorAll('.installment-mode-tab[data-installment-mode]').forEach((btn) => {
    btn.addEventListener('click', () => setInstallmentMode(btn.dataset.installmentMode));
  });
  document.querySelectorAll('[data-rayvarz-mode]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (btn.hidden) return;
      setRayvarzSendMode(btn.dataset.rayvarzMode);
    });
  });
  $('installmentApplyEndState')?.addEventListener('change', () => syncInstallmentOdooatCheckboxes('single'));
  $('installmentApplyEndStateExcel')?.addEventListener('change', () => syncInstallmentOdooatCheckboxes('excel'));
  setInstallmentMode('single');

  const excelInput = $('installmentExcelFile');
  if (excelInput) {
    excelInput.addEventListener('change', async () => {
      const status = $('installmentExcelStatus');
      const file = excelInput.files?.[0];
      installmentExcelRows = [];
      $('installmentPreviewSection').hidden = true;
      if ($('btnInstallmentUpdate')) $('btnInstallmentUpdate').disabled = true;
      if (!file) {
        if (status) status.textContent = 'فایلی انتخاب نشده';
        return;
      }
      if (status) status.textContent = 'در حال خواندن فایل…';
      try {
        installmentExcelRows = await parseInstallmentExcelFile(file);
        if (status) {
          status.textContent = `${file.name} — ${installmentExcelRows.length.toLocaleString('fa-IR')} ردیف خوانده شد`;
        }
      } catch (e) {
        if (status) status.textContent = e.message;
        excelInput.value = '';
        showAppError(e.message);
      }
    });
  }
  syncFundFromBranch();
  setupMainTabs();
  initDatePickers();
  initFicheDateStatusControls();
  $('ficheDateIdentifier')?.addEventListener('input', updateFicheDateIdentifierHint);
  ['ficheDateApplyPermanent', 'ficheDateApplyTemporary', 'ficheDateApplyBreak', 'ficheDateApplyStatus']
    .forEach((id) => $(id)?.addEventListener('change', syncFicheDateApplyFields));
  if (canAccessFicheDateChange()) {
    setupFicheDateAccountGroupLazyLoad();
  }
  window.addEventListener('load', initDatePickers);
  if (canManageUsers()) {
    setupUserGroupPermsDropdown();
    setupUserManagementPickers();
    setupGroupsTableActions();
    setupUsersTableActions();
    syncAdminCheckboxDirectPermissions('newUserIsAdmin', 'newUserDirect');
    syncAdminCheckboxDirectPermissions('editUserIsAdmin', 'editUserDirect');
    syncGroupFormActions();
    await loadGroupsTable();
    await loadUsersTable();
  }
}

function bindClick(id, handler) {
  const el = $(id);
  if (!el) {
    console.error(`دکمه #${id} در HTML یافت نشد — index.html را به‌روز کنید.`);
    return false;
  }
  el.addEventListener('click', handler);
  return true;
}

function setupEventHandlers() {
  const required = ['btnLoad', 'btnSend'];
  const missing = required.filter((id) => !$(id));
  if (missing.length) {
    alert(`فایل index.html قدیمی است یا ناقص.\nدکمه‌های گم‌شده: ${missing.join(', ')}\nاز شاخه rayvarz-resend دوباره کپی کنید.`);
  }

  bindClick('btnLoad', async () => {
  const kind = getSingleFicheKind();
  const value = normalizeSearchId($('identifierValue').value);
  if (!value) return showAppWarning('شناسه فیش را وارد کنید');

  $('btnLoad').disabled = true;
  try {
    const res = await apiFetch('/api/fiche/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ficheKind: kind,
        identifierValue: value,
        branch: parseInt($('branch').value),
        docDate: $('docDate').value
      })
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || data.detail || data.title || `خطا (HTTP ${res.status})`);

    currentFiche = data;
    if (kind === 'Income' && data.category !== 'Income') {
      throw new Error('نوع فیش با «درآمد» انتخاب‌شده مطابقت ندارد');
    }
    if (kind === 'Duty' && data.category !== 'DutyNosazi' && data.category !== 'DutySenfi') {
      throw new Error('نوع فیش با «نوسازی و صنفی» انتخاب‌شده مطابقت ندارد');
    }
    updateIdentifierHint();
    applyBranchFromFiche(data);
    applyFicheDatesToForm(data);
    renderFiche(data);
    updateSendButton(data);
    $('resultSection').hidden = true;
  } catch (e) {
    showAppError(e.message);
    currentFiche = null;
    $('ficheSection').hidden = true;
    updateSendButton(null);
  } finally {
    $('btnLoad').disabled = false;
  }
  });

  bindClick('btnSend', async () => {
  if (!currentFiche) return;
  if (!isTahatorIncomeFiche(currentFiche) && !currentFiche.canSend) {
    return showAppWarning(currentFiche.blockReason || currentFiche.statusMessage || 'این فیش قابل ارسال نیست');
  }

  if (isTahatorIncomeFiche(currentFiche)) {
    $('btnSend').disabled = true;
    showAppInfo(`در حال ارسال فیش ${currentFiche.ficheNo}…`);
    try {
      const res = await apiFetch('/api/tahator/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ficheNo: currentFiche.ficheNo, branch: 0, fund: 0 })
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      showTahatorSendResult(data);
      if (data.dryRun) showAppInfo('ارسال آزمایشی تهاتر — به رایورز ارسال نشد.');
      else if (data.skipped) showAppWarning(data.message);
      else if (data.success) {
        showAppSuccess(data.message || 'ارسال تهاتر موفق');
        if (!data.dryRun) resetMainTabPanelState('unsent');
      } else showAppError(data.message || (data.docNotSentError ? `عدم ارسال: ${data.docNotSentError}` : 'تهاتر ناموفق'));
      $('resultSection')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (e) {
      showAppError(e.message);
    } finally {
      $('btnSend').disabled = false;
      updateSendButton(currentFiche);
    }
    return;
  }

  $('btnSend').disabled = true;
  showAppInfo(`در حال ارسال فیش ${currentFiche.ficheNo}…`);
  try {
    const res = await apiFetch('/api/fiche/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(getPayload(true))
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || data.detail || data.title || `خطا (HTTP ${res.status})`);

    showSendResult(data);

    if (data.dryRun) {
      showAppInfo('ارسال آزمایشی — به رایورز ارسال نشد.');
    } else if (data.success && data.verifiedInRayvarz === false) {
      showAppWarning('ارسال انجام شد ولی در رایورز تأیید نشد.');
    } else if (!data.success) {
      showAppError(data.message || data.docNotSentError || 'ارسال ناموفق');
    } else if (data.success && data.verifiedInRayvarz) {
      showAppSuccess('فیش در رایورز ثبت شد.');
      resetMainTabPanelState('unsent');
    }
    $('resultSection')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) {
    showAppError(e.message);
  } finally {
    $('btnSend').disabled = false;
    updateSendButton(currentFiche);
  }
  });

  const selectAll = $('unsentSelectAll');
  if (selectAll) {
    selectAll.addEventListener('change', () => {
      unsentItems.forEach((item) => {
        if (selectAll.checked) selectedUnsentFicheNos.add(item.ficheNo);
        else selectedUnsentFicheNos.delete(item.ficheNo);
      });
      document.querySelectorAll('.unsent-row-check').forEach((cb) => {
        cb.checked = selectAll.checked;
      });
      updateUnsentSendButton();
      const countLabelEl = $('unsentCountLabel');
      if (countLabelEl && unsentSearchState.totalCount > 0) {
        const selectedTotal = selectedUnsentFicheNos.size;
        const pageInfo = `${unsentItems.length.toLocaleString('fa-IR')} مورد در این صفحه — ${unsentSearchState.totalCount.toLocaleString('fa-IR')} مورد کل`;
        countLabelEl.textContent = selectedTotal > 0
          ? `${pageInfo} | ${selectedTotal.toLocaleString('fa-IR')} انتخاب‌شده`
          : pageInfo;
      }
    });
  }

  let unsentExcelBusy = false;
  $('unsentExcelFile')?.addEventListener('change', async () => {
    const input = $('unsentExcelFile');
    const excelBtn = $('btnUnsentExcel');
    const box = $('unsentResultBox');
    const file = input?.files?.[0];

    if (!file) {
      setUnsentExcelStatus('فایل اکسل انتخاب نشده', false);
      return;
    }
    if (unsentExcelBusy) return;

    unsentExcelBusy = true;
    if (excelBtn) excelBtn.disabled = true;
    setUnsentExcelStatus('فایل در حال بررسی است…', true);
    if (box) box.hidden = true;

    try {
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const pairs = await parseUnsentExcelFile(file);
      setUnsentExcelStatus('فایل در حال بررسی است…', true);
      await new Promise((r) => requestAnimationFrame(r));

      const res = await apiFetch('/api/unsent/lookup-by-bill-pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pairs })
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);

      const { added, duplicate } = appendUnsentItems(data.items || [], { autoSelect: true });
      const conflictLines = (data.conflicts || []).map((c) =>
        toPersianDigits(`شناسه قبض: ${c.billId || '-'} | شناسه پرداخت: ${c.paymentId || '-'} — ${c.reason || ''}`)
      );
      const missLines = (data.misses || [])
        .map((m) => toPersianDigits((m.reason || '').trim()))
        .filter(Boolean);
      const conflictCount = data.conflictCount ?? conflictLines.length;

      if (box) {
        const showLog = conflictLines.length > 0 || missLines.length > 0;
        box.hidden = !showLog;
        if (showLog) {
          box.className = 'result-log';
          box.textContent = [
            ...(conflictLines.length ? ['--- تعارض درآمد و نوسازی (به گرید اضافه نشد) ---', ...conflictLines, ''] : []),
            ...missLines
          ].join('\n');
        } else {
          box.textContent = '';
        }
      }

      setUnsentExcelStatus(
        `${file.name} — افزوده: ${added.toLocaleString('fa-IR')} | تکراری: ${duplicate.toLocaleString('fa-IR')} | تعارض: ${conflictCount.toLocaleString('fa-IR')} | یافت‌نشده: ${(data.notFound || 0).toLocaleString('fa-IR')}`,
        false
      );

      if (added > 0 && missLines.length === 0 && conflictCount === 0) {
        showAppSuccess(`${added} فیش به گرید اضافه شد`);
      } else if (added > 0) {
        showAppWarning(`${added} فیش اضافه شد؛ ${missLines.length + conflictCount} ردیف قابل افزودن نبود`);
      } else if (conflictCount > 0 || missLines.length > 0) {
        showAppWarning('هیچ فیشی به گرید اضافه نشد');
      } else {
        showAppInfo('فیش‌های انتخاب‌شده قبلاً در گرید بودند');
      }
    } catch (e) {
      setUnsentExcelStatus(e.message, false);
      if (box) {
        box.hidden = false;
        box.className = 'result-log';
        box.textContent = e.message;
      }
      showAppError(e.message);
    } finally {
      unsentExcelBusy = false;
      if (input) input.value = '';
      if (excelBtn) excelBtn.disabled = false;
    }
  });

  bindClick('btnUnsentSearch', async () => {
    await fetchUnsentResults(1, { clearSelection: true });
  });

  bindClick('btnUnsentPrevPage', async () => {
    if (unsentSearchState.page <= 1) return;
    await fetchUnsentResults(unsentSearchState.page - 1);
  });

  bindClick('btnUnsentNextPage', async () => {
    if (unsentSearchState.page >= unsentSearchState.totalPages) return;
    await fetchUnsentResults(unsentSearchState.page + 1);
  });

  const pageSizeSel = $('unsentPageSize');
  if (pageSizeSel) {
    pageSizeSel.addEventListener('change', async () => {
      if (!unsentSearchState.filters) return;
      await fetchUnsentResults(1);
    });
  }

  bindClick('btnUnsentSend', async () => {
    const targets = getSelectedUnsentBatchTargets();
    if (!targets.length) return showAppWarning('حداقل یک فیش انتخاب کنید');

    const dry = config?.dryRun;
    showAppInfo(dry
      ? `در حال ارسال آزمایشی ${targets.length} فیش انتخاب‌شده…`
      : `در حال ارسال ${targets.length} فیش انتخاب‌شده به رایورز…`);

    const btn = $('btnUnsentSend');
    btn.disabled = true;
    const box = $('unsentResultBox');
    box.hidden = false;
    box.className = 'result-log';
    box.textContent = `در حال ارسال ${targets.length} فیش…`;

    try {
      const res = await apiFetch('/api/unsent/send-batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targets })
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);

      box.textContent = formatUnsentBatchSendResult(data);

      if (data.dryRun) showAppInfo('DryRun: SOAP ساخته شد؛ POST واقعی زده نشد.');
      else if (data.failed > 0) {
        showAppWarning(`ارسال دسته‌ای تمام شد — موفق: ${data.succeeded}، ناموفق: ${data.failed}، رد: ${data.skipped}`);
      } else {
        showAppSuccess(`ارسال دسته‌ای تمام شد — موفق: ${data.succeeded}، ناموفق: ${data.failed}، رد: ${data.skipped}`);
        if (!data.dryRun) resetMainTabPanelState('unsent');
      }
    } catch (e) {
      box.textContent = e.message;
      showAppError(e.message);
    } finally {
      updateUnsentSendButton();
    }
  });

  bindClick('btnInstallmentPreview', async () => {
    const payload = getInstallmentPayload();
    if (installmentMode === 'excel') {
      if (!payload.excelRows?.length) return showAppWarning('فایل اکسل را انتخاب کنید');
    } else if (!payload.valuesText) {
      return showAppWarning('حداقل یک شماره سند یا کد پیگیری وارد کنید');
    }

    const btn = $('btnInstallmentPreview');
    const box = $('installmentResultBox');
    btn.disabled = true;
    if (box) box.hidden = true;
    try {
      const res = await apiFetch('/api/installment/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      renderInstallmentPreview(data);
    } catch (e) {
      showAppError(e.message);
      $('installmentPreviewSection').hidden = true;
      if ($('btnInstallmentUpdate')) $('btnInstallmentUpdate').disabled = true;
    } finally {
      btn.disabled = false;
    }
  });

  bindClick('btnInstallmentUpdate', async () => {
    const payload = getInstallmentPayload();
    if (installmentMode === 'excel') {
      if (!payload.excelRows?.length) return showAppWarning('فایل اکسل را انتخاب کنید');
    } else if (!payload.valuesText) {
      return showAppWarning('حداقل یک شماره سند یا کد پیگیری وارد کنید');
    }

    const dry = config?.installment?.dryRun ?? config?.dryRun ?? false;
    const dryNote = dry ? 'در حالت DryRun تغییری روی سرور اعمال نمی‌شود.' : '';
    if (dryNote && !confirm(`${dryNote}\n\nادامه؟`)) return;
    if (!dryNote && !confirm('ادامه؟')) return;

    const btn = $('btnInstallmentUpdate');
    const box = $('installmentResultBox');
    btn.disabled = true;
    if (box) {
      box.hidden = false;
      box.textContent = 'در حال اعمال…';
    }
    try {
      const res = await apiFetch('/api/installment/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      if (box) box.textContent = formatInstallmentUpdateResult(data);
      if (data.dryRun) {
        showAppInfo(`${data.wouldUpdate || 0} ردیف — تغییری روی سرور اعمال نشد.`);
      } else {
        showAppSuccess(`UPDATE تمام شد — ${data.updated} ردیف به‌روز، ${data.notFound} بدون نتیجه`);
        resetMainTabPanelState('installment');
      }
    } catch (e) {
      if (box) box.textContent = e.message;
      showAppError(e.message);
    } finally {
      btn.disabled = false;
    }
  });

  bindClick('btnFicheDateSearch', async () => {
    await fetchFicheDateResults(1, { clearSelection: true });
  });

  bindClick('btnFicheDatePrevPage', async () => {
    if (ficheDateSearchState.page <= 1) return;
    await fetchFicheDateResults(ficheDateSearchState.page - 1);
  });

  bindClick('btnFicheDateNextPage', async () => {
    if (ficheDateSearchState.page >= ficheDateSearchState.totalPages) return;
    await fetchFicheDateResults(ficheDateSearchState.page + 1);
  });

  const ficheDatePageSize = $('ficheDatePageSize');
  if (ficheDatePageSize) {
    ficheDatePageSize.addEventListener('change', async () => {
      if (ficheDateSearchState.totalCount > 0) {
        await fetchFicheDateResults(1);
      }
    });
  }

  const ficheDateSelectAll = $('ficheDateSelectAll');
  if (ficheDateSelectAll) {
    ficheDateSelectAll.addEventListener('change', () => {
      const tbody = $('ficheDateTable')?.querySelector('tbody');
      if (!tbody) return;
      ficheDateItems.forEach((item) => {
        setGridRowSelected(selectedFicheDateNos, ficheDateSelectedItems, item, ficheDateSelectAll.checked);
      });
      tbody.querySelectorAll('.fiche-date-row-check').forEach((cb) => {
        cb.checked = ficheDateSelectAll.checked;
      });
      updateFicheDateCountLabel();
      syncFicheDateUpdateButton();
    });
  }

  bindClick('btnFicheDateUpdate', async () => {
    const payload = getFicheDateUpdatePayload();
    if (!payload.ficheNos.length) return showAppWarning('حداقل یک فیش انتخاب کنید');
    const hasChange = (payload.applyExportPermanentDate && payload.newExportPermanentDate)
      || (payload.applyExportTemporaryDate && payload.newExportTemporaryDate)
      || (payload.applyPaymentBreakDate && payload.newPaymentBreakDate)
      || (payload.applyEumFicheStatus && payload.newEumFicheStatus != null);
    if (!hasChange) return showAppWarning('حداقل یک فیلد برای تغییر مشخص کنید');

    const dry = config?.ficheDateChange?.dryRun ?? config?.dryRun ?? false;
    const warn = dry
      ? `DryRun فعال — ${payload.ficheNos.length} فیش فقط شبیه‌سازی می‌شود. ادامه؟`
      : `تغییر تاریخ/وضعیت ${payload.ficheNos.length} فیش در Income_Fiche؟`;
    if (!confirm(warn)) return;

    const btn = $('btnFicheDateUpdate');
    const box = $('ficheDateResultBox');
    btn.disabled = true;
    if (box) {
      box.hidden = false;
      box.textContent = 'در حال اعمال…';
    }
    try {
      const res = await apiFetch('/api/fiche-date/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      if (box) box.textContent = formatFicheDateUpdateResult(data);
      if (data.dryRun) {
        showAppInfo(`${data.wouldUpdate || 0} فیش — تغییری روی سرور اعمال نشد (DryRun).`);
      } else {
        showAppSuccess(`UPDATE تمام شد — ${data.updated} فیش به‌روز، ${data.notFound} بدون نتیجه`);
        resetMainTabPanelState('ficheDate');
      }
    } catch (e) {
      if (box) box.textContent = e.message;
      showAppError(e.message);
    } finally {
      btn.disabled = false;
      syncFicheDateUpdateButton();
    }
  });

  bindClick('btnBankInquirySearch', async () => {
    await fetchBankInquiryResults(1, { clearSelection: true });
  });

  bindClick('btnCostCenterSearch', async () => {
    await fetchCostCenterResults(1, { clearSelection: true });
  });

  bindClick('btnCostCenterPrevPage', async () => {
    if (costCenterSearchState.page <= 1) return;
    await fetchCostCenterResults(costCenterSearchState.page - 1);
  });

  bindClick('btnCostCenterNextPage', async () => {
    if (costCenterSearchState.page >= costCenterSearchState.totalPages) return;
    await fetchCostCenterResults(costCenterSearchState.page + 1);
  });

  $('costCenterPageSize')?.addEventListener('change', async () => {
    await fetchCostCenterResults(1);
  });

  $('costCenterSelectAll')?.addEventListener('change', (e) => {
    const tbody = $('costCenterTable')?.querySelector('tbody');
    const selectAll = e.target;
    if (!tbody || !selectAll) return;
    costCenterItems.forEach((item) => {
      setGridRowSelected(selectedCostCenterNos, costCenterSelectedItems, item, selectAll.checked);
    });
    tbody.querySelectorAll('.cost-center-row-check').forEach((cb) => {
      cb.checked = selectAll.checked;
    });
    updateCostCenterCountLabel();
    syncCostCenterUpdateButton();
  });

  ['costCenterOne', 'costCenterTwo'].forEach((id) => {
    $(id)?.addEventListener('input', syncCostCenterUpdateButton);
  });

  bindClick('btnCostCenterUpdate', async () => {
    const payload = getCostCenterUpdatePayload();
    const validationError = validateCostCenterUpdatePayload(payload);
    if (validationError) return showAppWarning(validationError);

    const dry = config?.costCenter?.dryRun ?? config?.dryRun ?? false;
    const warn = dry
      ? `DryRun فعال — به‌روزرسانی مرکز هزینه برای ${payload.ficheNos.length} فیش فقط شبیه‌سازی می‌شود. ادامه؟`
      : `مرکز یک=${payload.centerOne} و مرکز دو=${payload.centerTwo} برای ${payload.ficheNos.length} فیش ثبت شود؟`;
    if (!confirm(warn)) return;

    const btn = $('btnCostCenterUpdate');
    const box = $('costCenterResultBox');
    btn.disabled = true;
    if (box) {
      box.hidden = false;
      box.textContent = 'در حال به‌روزرسانی…';
    }
    try {
      const res = await apiFetch('/api/cost-center/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      if (box) box.textContent = formatCostCenterUpdateResult(data);
      if (data.dryRun) {
        showAppInfo('مرکز هزینه — DryRun؛ تغییری در دیتابیس اعمال نشد.');
      } else if (data.success && (data.updated || 0) > 0) {
        showAppSuccess(data.message || `${data.updated} فیش به‌روز شد`);
        resetMainTabPanelState('costCenter');
      } else {
        showAppError(data.message || 'به‌روزرسانی ناموفق بود');
      }
    } catch (e) {
      if (box) box.textContent = e.message;
      showAppError(e.message);
    } finally {
      btn.disabled = false;
      syncCostCenterUpdateButton();
    }
  });

  bindClick('btnBankInquiryPrevPage', async () => {
    if (bankInquirySearchState.page <= 1) return;
    await fetchBankInquiryResults(bankInquirySearchState.page - 1);
  });

  bindClick('btnBankInquiryNextPage', async () => {
    if (bankInquirySearchState.page >= bankInquirySearchState.totalPages) return;
    await fetchBankInquiryResults(bankInquirySearchState.page + 1);
  });

  $('bankInquiryPageSize')?.addEventListener('change', async () => {
    await fetchBankInquiryResults(1);
  });

  $('bankInquirySelectAll')?.addEventListener('change', (e) => {
    const tbody = $('bankInquiryTable')?.querySelector('tbody');
    const selectAll = e.target;
    if (!tbody || !selectAll) return;
    bankInquiryItems.forEach((item) => {
      setGridRowSelected(selectedBankInquiryNos, bankInquirySelectedItems, item, selectAll.checked);
    });
    tbody.querySelectorAll('.bank-inquiry-row-check').forEach((cb) => {
      cb.checked = selectAll.checked;
    });
    updateBankInquiryCountLabel();
    syncBankInquiryConfirmButton();
  });

  bindClick('btnShahkarSearch', async () => {
    await fetchShahkarResults({ clearSelection: true });
  });

  $('shahkarSelectAll')?.addEventListener('change', (e) => {
    const tbody = $('shahkarTable')?.querySelector('tbody');
    const selectAll = e.target;
    if (!tbody || !selectAll) return;
    shahkarItems.forEach((item) => {
      setShahkarRowSelected(selectedShahkarUserNames, shahkarSelectedItems, item, selectAll.checked);
    });
    tbody.querySelectorAll('.shahkar-row-check').forEach((cb) => {
      cb.checked = selectAll.checked;
    });
    updateShahkarCountLabel();
    syncShahkarConfirmButton();
  });

  bindClick('btnShahkarConfirm', async () => {
    const userNames = Array.from(selectedShahkarUserNames);
    if (userNames.length === 0) return showAppWarning('حداقل یک کاربر انتخاب کنید');

    const dry = config?.shahkar?.dryRun ?? config?.dryRun ?? false;
    const warn = dry
      ? `DryRun فعال — ShahkarOk برای ${userNames.length} کاربر فقط شبیه‌سازی می‌شود. ادامه؟`
      : `ShahkarOk = 1 برای ${userNames.length} کاربر ثبت شود؟`;
    if (!confirm(warn)) return;

    const btn = $('btnShahkarConfirm');
    const box = $('shahkarResultBox');
    btn.disabled = true;
    if (box) {
      box.hidden = false;
      box.textContent = 'در حال ثبت…';
    }
    try {
      const res = await apiFetch('/api/shahkar/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userNames })
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      const lines = (data.results || []).map((r) => `${r.userName}: ${r.success ? 'OK' : 'خطا'} — ${r.message || ''}`);
      if (box) box.textContent = [data.message || '', ...lines].filter(Boolean).join('\n');
      if (data.dryRun) {
        showAppInfo('شاهکار — DryRun؛ تغییری در دیتابیس اعمال نشد.');
      } else if (data.success && (data.updated || 0) > 0) {
        showAppSuccess(data.message || `${data.updated} کاربر به‌روز شد`);
        resetMainTabPanelState('shahkar');
      } else {
        showAppError(data.message || 'به‌روزرسانی ناموفق بود');
      }
    } catch (e) {
      if (box) box.textContent = e.message;
      showAppError(e.message);
    } finally {
      btn.disabled = false;
      syncShahkarConfirmButton();
    }
  });

  bindClick('btnBankInquiryConfirm', async () => {
    const payload = getBankInquiryConfirmPayload();
    const validationError = validateBankInquiryConfirmPayload(payload);
    if (validationError) return showAppWarning(validationError);

    const dry = config?.bankInquiryConfirm?.dryRun ?? config?.dryRun ?? false;
    const warn = dry
      ? `DryRun فعال — تغییر تاریخ پرداخت برای ${payload.ficheNos.length} فیش فقط شبیه‌سازی می‌شود. ادامه؟`
      : `تغییر تاریخ پرداخت برای ${payload.ficheNos.length} فیش با تاریخ «${payload.newPaymentDate}» ثبت شود؟`;
    if (!confirm(warn)) return;

    const btn = $('btnBankInquiryConfirm');
    const box = $('bankInquiryResultBox');
    btn.disabled = true;
    if (box) {
      box.hidden = false;
      box.textContent = 'در حال ثبت…';
    }
    try {
      const res = await apiFetch('/api/bank-inquiry/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await parseJsonResponse(res);
      if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
      if (box) box.textContent = formatBankInquiryConfirmResult(data);
      if (data.dryRun) {
        showAppInfo('تغییر تاریخ پرداخت — تغییری روی سرور اعمال نشد (DryRun).');
      } else if (data.success && (data.updated || 0) > 0) {
        showAppSuccess(data.message || `تایید ثبت شد — ${data.updated} فیش به‌روز`);
        resetMainTabPanelState('bankInquiry');
      } else {
        const firstFail = (data.results || []).find((r) => !r.success);
        const detail = data.message || firstFail?.message || firstFail?.bankInquiryMessage || 'استعلام بانک یا به‌روزرسانی ناموفق بود';
        showAppError(detail);
      }
    } catch (e) {
      if (box) box.textContent = e.message;
      showAppError(e.message);
    } finally {
      btn.disabled = false;
      syncBankInquiryConfirmButton();
    }
  });
}

function setupAuthAndAdminHandlers() {
  bindClick('btnLogout', async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    // نه /auth/login — نشست SSO فعال کاربر را بلافاصله دوباره وارد می‌کند
    window.location.href = '/login.html';
  });

  bindClick('btnCreateUser', createUserFromForm);
  bindClick('btnRefreshUsers', async () => {
    await loadGroupsTable();
    await loadUsersTable();
  });
  bindClick('btnCreateGroup', async () => {
    try {
      await saveGroupFromForm();
    } catch (e) {
      alert(e.message);
    }
  });
  bindClick('btnCancelGroupEdit', () => resetGroupForm());
  bindClick('btnRefreshGroups', loadGroupsTable);
  bindClick('btnSaveUserEdit', async () => {
    try {
      await saveUserEdit();
    } catch (e) {
      alert(e.message);
    }
  });
  bindClick('btnResetUserPassword', async () => {
    try {
      await resetUserPassword();
    } catch (e) {
      alert(e.message);
    }
  });
  bindClick('btnCancelUserEdit', closeUserEdit);
}

function showTahatorSendResult(data) {
  const tone = data.success ? (data.skipped ? 'warn' : 'ok') : 'err';
  const statusFa = data.dryRun
    ? 'آزمایشی — به رایورز ارسال نشد'
    : data.skipped
      ? 'ارسال نشد (قبلاً در رایورز است)'
      : data.success
        ? 'ارسال موفق'
        : 'ارسال ناموفق';
  renderSendResultCard([
    { label: 'وضعیت', value: statusFa },
    { label: 'شماره فیش', value: data.ficheNo || '—' },
    { label: 'پیام', value: data.message || '—' },
    { label: 'خطای ارسال', value: data.docNotSentError || '—' }
  ].filter((row) => row.value && row.value !== '—'), tone);
}

function formatTahatorCheck(d) {
  const snap = d.snapshot;
  const f = d.fiche;
  const pairLines = (d.pairMembers || []).map(m =>
    `  ${m.incomeAccountGroup} ${m.ficheNo}: DocTyp=${m.docTyp} Branch=${m.branch} Fund=${m.fund} | Header=${m.existsInAccountingDocHeader} Rayvarz=${m.existsInRayvarz} NeedsSend=${m.needsSend}`
  );
  return [
    '=== بررسی جفت تهاتر (۱۵۷+۱۵۸) ===',
    `FicheNo ورودی: ${d.ficheNo}`,
    d.pair ? `جفت: ۱۵۷=${d.pair.amountFicheNo} | ۱۵۸=${d.pair.incomeFicheNo}` : 'جفت: —',
    pairLines.length ? ['--- وضعیت هر فیش ---', ...pairLines].join('\n') : '',
    `NeedsSend (حداقل یکی از جفت): ${d.needsSend}`,
    f ? `فیش ورودی — Payable: ${Number(f.payable || 0).toLocaleString()}` : '',
    d.pendingStoredSnapshot
      ? `Snapshot Pending: Id=${d.pendingStoredSnapshot.snapshotId}`
      : 'Snapshot Pending: —',
    d.docNotSentError ? `DocNotSent: ${d.docNotSentError}` : 'DocNotSent: —',
    `پیام: ${d.message || ''}`,
    snap ? [
      '',
      '--- Snapshot فعلی (فیش ورودی) ---',
      `EumFicheStatus: ${snap.eumFicheStatus}`,
      `ExportPermanentDate: ${snap.exportPermanentDate || ''}`,
      `PaymentBreakDate: ${snap.paymentBreakDate || ''}`,
      `PaymentDate: ${snap.paymentDate || ''}`
    ].join('\n') : ''
  ].filter(Boolean).join('\n');
}

function formatTahatorSend(d) {
  const resultLines = (d.ficheResults || []).map(r =>
    `  ${r.incomeAccountGroup} ${r.ficheNo}: Success=${r.success} Skipped=${r.skipped}${r.skipReason ? ' (' + r.skipReason + ')' : ''} DocTyp=${r.docTyp} Branch=${r.branch}/${r.fund}${r.soapMessage ? ' — ' + r.soapMessage : ''}`
  );
  return [
    '=== نتیجه ارسال تهاتر ===',
    `FicheNo ورودی: ${d.ficheNo}`,
    d.pair ? `جفت: ۱۵۷=${d.pair.amountFicheNo} → ۱۵۸=${d.pair.incomeFicheNo}` : '',
    `Success: ${d.success}`,
    `Skipped: ${d.skipped}`,
    d.skipReason ? `SkipReason: ${d.skipReason}` : '',
    `DryRun: ${d.dryRun}`,
    resultLines.length ? ['--- هر فیش ---', ...resultLines].join('\n') : '',
    d.triggerDate ? `تاریخ تریگر: ${d.triggerDate}` : '',
    `پیام: ${d.message || ''}`,
    '',
    '--- مراحل ---',
    ...(d.steps || [])
  ].filter(Boolean).join('\n');
}

setupEventHandlers();
setupBankInquiryDiagnoseHandler();
setupAuthAndAdminHandlers();
init();
