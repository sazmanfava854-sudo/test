@echo off
cd /d "%~dp0"
echo RayvarzResend v39 — نسخه آخر (Qty=Payable + تهاتر DTL)
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
