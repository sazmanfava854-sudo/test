@echo off
cd /d "%~dp0"
echo RayvarzResend v49 — اکسل ۲۶ رقم قبض+پرداخت
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
