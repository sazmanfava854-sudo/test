@echo off
cd /d "%~dp0"
set ASPNETCORE_ENVIRONMENT=Development
echo RayvarzResend v26 DEBUG (PDB + verbose SSO logs)
echo Auth:Sso:DebugSigning=true in appsettings.json
echo.
echo SSO debug URLs (after start):
echo   http://localhost:5088/api/auth/sso-outbound-map
echo   http://localhost:5088/api/auth/sso-signing-preview
echo   http://localhost:5088/api/auth/sso-loginkey-check
echo   http://localhost:5088/api/auth/sso-loginkey-probe
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
