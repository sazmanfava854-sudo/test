const $ = (id) => document.getElementById(id);

async function parseJsonResponse(res) {
  const text = await res.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(text || `خطا (HTTP ${res.status})`);
  }
}

function resolvePostLoginTarget(mode) {
  const params = new URLSearchParams(window.location.search);
  const returnUrl = (params.get('returnUrl') || '').trim();
  if (returnUrl.startsWith('/') && !returnUrl.startsWith('//')) return returnUrl;
  const fallback = (mode?.postLoginDefaultPath || '/management/').trim();
  return fallback.startsWith('/') ? fallback : '/management/';
}

async function checkExistingSession(mode) {
  try {
    const res = await fetch('/api/auth/me', { credentials: 'include' });
    if (res.ok) {
      window.location.href = resolvePostLoginTarget(mode);
      return true;
    }
  } catch {
    // ignore
  }
  return false;
}

function showSsoBlock(mode) {
  const block = $('loginSsoBlock');
  if (!block) return;
  const publicSso = (mode?.publicSsoLoginUrl || '').trim();
  const loginPath = (mode?.loginPath || '/auth/login').trim();
  const show = !!mode?.ssoReady && (
    !!mode?.preferSsoLogin ||
    !!mode?.allowSsoOnLoopbackForDebug ||
    publicSso.length > 0 ||
    loginPath.startsWith('http')
  );
  block.hidden = !show;
  const link = $('btnSsoLogin');
  if (link) {
    link.setAttribute('href', publicSso || loginPath);
    if ((publicSso || loginPath).startsWith('http')) {
      link.setAttribute('rel', 'noopener');
    }
  }
}

async function initLoginPage() {
  let mode = null;
  try {
    const res = await fetch('/api/auth/mode');
    if (res.ok) mode = await res.json();
  } catch {
    // ignore
  }

  if (await checkExistingSession(mode)) return;

  try {
    if (mode) {
      showSsoBlock(mode);
      if (mode.preferSsoLogin && !mode.allowAdminLocalLoginOnPublicHost) {
        window.location.href = mode.loginPath || '/auth/login';
        return;
      }
      if (!mode.localLoginAvailable && !mode.allowAdminLocalLoginOnPublicHost) {
        const errEl = $('loginError');
        errEl.textContent = 'ورود محلی غیرفعال است';
        errEl.hidden = false;
        $('loginForm').hidden = true;
      }
    }
  } catch {
    // ignore
  }

  const params = new URLSearchParams(window.location.search);
  const error = params.get('error');
  if (error) {
    const errEl = $('loginError');
    errEl.textContent = decodeURIComponent(error);
    errEl.hidden = false;
  }
}

$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const errEl = $('loginError');
  const btn = $('btnLogin');
  errEl.hidden = true;
  errEl.textContent = '';
  btn.disabled = true;

  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({
        username: $('loginUsername').value.trim(),
        password: $('loginPassword').value
      })
    });
    const data = await parseJsonResponse(res);
    if (!res.ok) throw new Error(data.error || `خطا (HTTP ${res.status})`);
    let mode = null;
    try {
      const modeRes = await fetch('/api/auth/mode');
      if (modeRes.ok) mode = await modeRes.json();
    } catch {
      // ignore
    }
    window.location.href = resolvePostLoginTarget(mode);
  } catch (ex) {
    errEl.textContent = ex.message || 'ورود ناموفق';
    errEl.hidden = false;
  } finally {
    btn.disabled = false;
  }
});

initLoginPage();
