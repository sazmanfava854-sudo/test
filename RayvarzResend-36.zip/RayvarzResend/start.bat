@echo off
cd /d "%~dp0"
echo RayvarzResend v36 — نسخه آخر (تهاتر درآمدی — IncomeCode / ADP 158)
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
