RayvarzResend v25 — نسخه آخر (تهاتر + Accounting_Doc)

نصب روی سرور ویندوز
--------------------
1) Zip را باز کنید. فقط یک پوشه دارید: RayvarzResend
2) ConnectionStrings را در همین فایل ویرایش کنید:
     RayvarzResend\appsettings.json
   فقط همین یک فایل تنظیمات وجود دارد.
   appsettings.Production.json را اگر از قبل دارید حذف کنید.
3) .NET 8 Runtime/Hosting روی سرور کافی است (SDK لازم نیست).
4) start.bat را اجرا کنید (یا RayvarzResend.Web.exe)
5) مرورگر: http://localhost:5088
6) GET /api/config
     releaseVersion = 25
     accountingDoc.dryRun = false
     dryRun = false

Accounting_DocHeader / Accounting_DocDetails بعد از ارسال موفق به رایورز
در همین نسخه ثبت می‌شود (اگر DryRun=false باشد).

سورس روی GitHub است — داخل Zip نیست:
https://github.com/sazmanfava854-sudo/test/tree/cursor/tahator-accounting-doc-ffcb
