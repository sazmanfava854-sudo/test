RayvarzResend — نسخه آخر

=== سرور ویندوز (فقط این پوشه) ===
  deploy/win-x64/
    RayvarzResend.Web.exe
    appsettings.json   ← تنها فایل تنظیمات (ConnectionStrings و DryRun را اینجا ویرایش کنید)

appsettings.Production.json استفاده نمی‌شود — اگر روی سرور دارید، حذف کنید.

=== توسعه ===
  source/RayvarzResend.Web/appsettings.json

تأیید: GET /api/config → accountingDoc.dryRun = false
