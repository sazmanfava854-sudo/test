@echo off
cd /d "%~dp0"
echo RayvarzResend v48 — رفع باگ‌های بازبینی
echo Settings: %cd%\appsettings.json
echo.
RayvarzResend.Web.exe --urls http://0.0.0.0:5088
