using System.Security.Claims;
using Microsoft.Data.SqlClient;
using RayvarzResend.Web.Models;

namespace RayvarzResend.Web.Services;

public sealed class BankInquiryConfirmService
{
    private readonly IConfiguration _config;
    private readonly FicheRepository _repo;
    private readonly BankInquiryApiClient _bankInquiryApi;
    private readonly string _saraCs;

    public BankInquiryConfirmService(
        IConfiguration config,
        FicheRepository repo,
        BankInquiryApiClient bankInquiryApi)
    {
        _config = config;
        _repo = repo;
        _bankInquiryApi = bankInquiryApi;
        _saraCs = config.GetConnectionString("Sara")
            ?? throw new InvalidOperationException("ConnectionStrings:Sara not set");
    }

    public bool IsDryRun =>
        _config.GetValue<bool?>("BankInquiryConfirm:DryRun")
        ?? _config.GetValue("Rayvarz:DryRun", true);

    public async Task<BankInquirySearchResult> SearchAsync(
        BankInquirySearchRequest req,
        ClaimsPrincipal user,
        CancellationToken ct = default)
    {
        var result = new BankInquirySearchResult();
        var validationError = BankInquiryConfirmHelper.ValidateSearchRequest(req);
        if (validationError != null)
        {
            result.Error = validationError;
            return result;
        }

        var (whereSql, parameters) = BankInquiryConfirmHelper.BuildSearchWhere(req);
        if (string.IsNullOrWhiteSpace(whereSql))
        {
            result.Error = "فیلتر جستجو نامعتبر است";
            return result;
        }

        var whereClauses = new List<string> { whereSql };
        DistrictAccessService.AppendIncomeFicheDistrictFilter(user, whereClauses, parameters);
        whereSql = string.Join(" AND ", whereClauses);

        var page = req.Page > 0 ? req.Page : 1;
        var pageSize = req.PageSize is > 0 and <= 200 ? req.PageSize : 25;
        var offset = (page - 1) * pageSize;

        var countSql = $"""
            SELECT COUNT(*)
            FROM dbo.Income_Fiche f
            {BankInquiryConfirmHelper.IncomeFicheNosaziJoins}
            WHERE {whereSql}
            """;

        var sql = $"""
            SELECT f.FicheNo,
                   CAST(r.NidWorkItem AS nvarchar(50)) AS NidWorkItem,
                   f.BillID,
                   f.PaymentID,
                   f.PaymentDate,
                   f.BankPaymentDate,
                   f.EumFicheStatus,
                   f.UserConfirmDate,
                   f.UsernameUserConfirm,
                   {BankInquiryConfirmHelper.IncomeNosaziCodeSql} AS NosaziCode
            FROM dbo.Income_Fiche f
            {BankInquiryConfirmHelper.IncomeFicheNosaziJoins}
            WHERE {whereSql}
            ORDER BY f.PaymentDate DESC, f.FicheNo DESC
            OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY
            """;

        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);

        var totalCount = 0;
        await using (var countCmd = new SqlCommand(countSql, conn))
        {
            foreach (var (name, value) in parameters)
                countCmd.Parameters.AddWithValue(name, value);
            var scalar = await countCmd.ExecuteScalarAsync(ct);
            totalCount = scalar == null || scalar == DBNull.Value ? 0 : Convert.ToInt32(scalar);
        }

        var totalPages = pageSize > 0 ? (int)Math.Ceiling(totalCount / (double)pageSize) : 0;
        if (totalPages > 0 && page > totalPages)
        {
            page = totalPages;
            offset = (page - 1) * pageSize;
        }

        await using var cmd = new SqlCommand(sql, conn);
        foreach (var (name, value) in parameters)
            cmd.Parameters.AddWithValue(name, value);
        cmd.Parameters.AddWithValue("@offset", offset);
        cmd.Parameters.AddWithValue("@pageSize", pageSize);

        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
        {
            var status = ReadInt(reader, "EumFicheStatus");
            result.Items.Add(new BankInquiryListItem
            {
                FicheNo = reader["FicheNo"]?.ToString() ?? "",
                NidWorkItem = reader["NidWorkItem"]?.ToString() ?? "",
                BillId = reader["BillID"]?.ToString() ?? "",
                PaymentId = reader["PaymentID"]?.ToString() ?? "",
                PaymentDate = reader["PaymentDate"]?.ToString() ?? "",
                BankPaymentDate = reader["BankPaymentDate"]?.ToString() ?? "",
                NosaziCode = reader["NosaziCode"]?.ToString() ?? "",
                EumFicheStatus = status,
                EumFicheStatusLabel = FicheDateChangeHelper.StatusLabel(status),
                UserConfirmDate = reader["UserConfirmDate"]?.ToString() ?? "",
                UsernameUserConfirm = reader["UsernameUserConfirm"]?.ToString() ?? ""
            });
        }

        result.Count = result.Items.Count;
        result.TotalCount = totalCount;
        result.Page = page;
        result.PageSize = pageSize;
        result.TotalPages = totalPages;
        return result;
    }

    public async Task<BankInquiryConfirmResult> ConfirmAsync(
        BankInquiryConfirmRequest req,
        ClaimsPrincipal user,
        CancellationToken ct = default)
    {
        var result = new BankInquiryConfirmResult { DryRun = IsDryRun };

        var validationError = BankInquiryConfirmHelper.ValidateConfirmRequest(req);
        if (validationError != null)
        {
            result.Error = validationError;
            return result;
        }

        var ficheNos = (req.FicheNos ?? [])
            .Select(s => (s ?? "").Trim())
            .Where(s => s.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var paymentDate = BankInquiryConfirmHelper.NormalizeSlashDate(req.NewPaymentDate);
        var userConfirmDate = DateHelper.CurrentShamsiSlashDate();
        var usernameUserConfirm = (req.PerformedByUser ?? "").Trim();
        if (string.IsNullOrEmpty(usernameUserConfirm))
            usernameUserConfirm = "کاربر";

        result.PaymentDate = paymentDate;
        result.UserConfirmDate = userConfirmDate;
        result.UsernameUserConfirm = usernameUserConfirm;
        result.NewEumFicheStatus = BankInquiryConfirmHelper.ConfirmedFicheStatus;
        result.NewEumIncomePaymentType = BankInquiryConfirmHelper.ConfirmedIncomePaymentType;

        if (result.DryRun)
        {
            foreach (var ficheNo in ficheNos)
            {
                var item = await BuildConfirmItemPreviewAsync(ficheNo, user, ct);
                if (item.Success && item.WouldUpdate > 0)
                    item.Message = "DryRun — استعلام بانک واقعی و UPDATE انجام نمی‌شود (BankInquiryConfirm:DryRun=true)";
                AppendConfirmItemResult(result, item);
            }

            FinalizeConfirmResult(result);
            return result;
        }

        var sql = """
            UPDATE dbo.Income_Fiche
            SET EumFicheStatus = @status,
                EumIncomePaymentType = @paymentType,
                PaymentDate = @paymentDate,
                UserConfirmDate = @userConfirmDate,
                UsernameUserConfirm = @usernameUserConfirm
            WHERE FicheNo = @ficheNo
            """;

        await using var conn = new SqlConnection(_saraCs);
        await conn.OpenAsync(ct);

        foreach (var ficheNo in ficheNos)
        {
            var item = await BuildConfirmItemPreviewAsync(ficheNo, user, ct);
            if (!item.Success)
            {
                AppendConfirmItemResult(result, item);
                continue;
            }

            var inquiry = await _bankInquiryApi.InquireAsync(item.BillId, item.PaymentId, ct);
            item.BankInquiryMessage = inquiry.Message;
            item.BankPaymentDate = inquiry.PaymentDate;
            item.BankInquiryVerified = inquiry.IsPaid
                || BankInquiryResponseParser.LooksLikePaidMessage(inquiry.Message);
            item.BankInquirySource = inquiry.InquirySource;

            if (!item.BankInquiryVerified)
            {
                item.Success = false;
                item.Message = inquiry.ServiceError
                    || BankInquiryResponseParser.LooksLikeServiceFailure(inquiry.Message)
                    ? inquiry.Message
                    : BankInquiryConfirmHelper.UnpaidFicheMessage;
                AppendConfirmItemResult(result, item);
                continue;
            }

            try
            {
                await using var cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@status", BankInquiryConfirmHelper.ConfirmedFicheStatus);
                cmd.Parameters.AddWithValue("@paymentType", BankInquiryConfirmHelper.ConfirmedIncomePaymentType);
                cmd.Parameters.AddWithValue("@paymentDate", paymentDate);
                cmd.Parameters.AddWithValue("@userConfirmDate", userConfirmDate);
                cmd.Parameters.AddWithValue("@usernameUserConfirm", usernameUserConfirm);
                cmd.Parameters.AddWithValue("@ficheNo", ficheNo);

                var affected = await cmd.ExecuteNonQueryAsync(ct);
                item.RowsAffected = affected;
                item.Found = affected > 0;
                item.Success = affected > 0;
                item.Message = affected > 0
                    ? $"تایید استعلام بانک ثبت شد — {inquiry.InquirySource}: {inquiry.Message}"
                    : "یافت نشد";
            }
            catch (Exception ex)
            {
                item.Success = false;
                item.Message = ex.Message;
            }

            AppendConfirmItemResult(result, item);
        }

        FinalizeConfirmResult(result);
        return result;
    }

    private static void FinalizeConfirmResult(BankInquiryConfirmResult result)
    {
        if (result.DryRun)
        {
            result.Success = result.WouldUpdate > 0;
            result.Message = result.WouldUpdate > 0
                ? $"شبیه‌سازی — {result.WouldUpdate} فیش UPDATE می‌شد"
                : "شبیه‌سازی — هیچ فیشی به‌روز نمی‌شد";
            return;
        }

        result.Success = result.Updated > 0;
        if (result.Updated > 0)
        {
            result.Message = $"{result.Updated} فیش به‌روز شد";
            return;
        }

        if (result.Failed > 0)
        {
            var firstFailure = result.Results.FirstOrDefault(r => !r.Success && r.Found);
            result.Message = firstFailure?.Message
                ?? $"به‌روزرسانی انجام نشد — خطا: {result.Failed}";
            return;
        }

        result.Message = result.NotFound > 0
            ? "فیش انتخاب‌شده یافت نشد"
            : "هیچ فیشی به‌روز نشد";
    }

    private async Task<BankInquiryConfirmItemResult> BuildConfirmItemPreviewAsync(
        string ficheNo,
        ClaimsPrincipal user,
        CancellationToken ct)
    {
        var item = new BankInquiryConfirmItemResult { FicheNo = ficheNo };

        var fiche = await _repo.LoadAsync(IdentifierType.FicheNo, ficheNo, ct);
        if (fiche == null)
        {
            item.Found = false;
            item.Success = false;
            item.Message = "یافت نشد";
            return item;
        }

        var districtDenied = DistrictAccessService.GetAccessDeniedMessage(user, fiche);
        if (districtDenied != null)
        {
            item.Found = true;
            item.Success = false;
            item.Message = districtDenied;
            return item;
        }

        var billId = BankInquiryConfirmHelper.NormalizeBillOrPayId(fiche.BillIdRaw ?? fiche.BillId);
        var paymentId = BankInquiryConfirmHelper.NormalizeBillOrPayId(fiche.PaymentIdRaw ?? fiche.PaymentId);
        item.BillId = billId;
        item.PaymentId = paymentId;

        if (string.IsNullOrWhiteSpace(billId) || string.IsNullOrWhiteSpace(paymentId))
        {
            item.Found = true;
            item.Success = false;
            item.Message = "شناسه قبض یا شناسه پرداخت در فیش موجود نیست";
            return item;
        }

        item.Found = true;
        item.Success = true;
        item.WouldUpdate = 1;
        return item;
    }

    private static void AppendConfirmItemResult(BankInquiryConfirmResult result, BankInquiryConfirmItemResult item)
    {
        result.Results.Add(item);
        result.Total++;
        if (result.DryRun)
        {
            if (item.WouldUpdate > 0) result.WouldUpdate += item.WouldUpdate;
            if (!item.Found) result.NotFound++;
            else if (!item.Success) result.Failed++;
            return;
        }

        if (item.Success) result.Updated += item.RowsAffected;
        else if (!item.Found) result.NotFound++;
        else result.Failed++;
    }

    private static int ReadInt(SqlDataReader reader, string column)
    {
        var ordinal = reader.GetOrdinal(column);
        if (reader.IsDBNull(ordinal)) return 0;
        return Convert.ToInt32(reader.GetValue(ordinal));
    }
}
