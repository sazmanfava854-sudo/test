#Requires -Version 5.1
<#
.SYNOPSIS
  SSO loginKey test: prints exact apiName / requestTime / apiSecret (headers) then POSTs.
#>
param(
    [Parameter(Mandatory)][string]$ApiName,
    [Parameter()][string]$ClientId = "",
    [Parameter(Mandatory)][string]$SecretKey,
    [string]$State = "test",
    [int]$UserType = 0,
    [int]$DomainID = 0,
    [string]$BaseUrl = "https://login.mashhad.ir",
    [switch]$HashUpper,
    [switch]$UseLegacyLkeyClientId,
    [int]$RequestTimeoutSec = 60,
    [switch]$PrintOnly,
    [switch]$PauseBeforeSend
)

$ErrorActionPreference = "Stop"
$BaseUrl = $BaseUrl.TrimEnd('/')
$ApiName = $ApiName.Trim()
$SecretKey = $SecretKey.Trim()
$ClientId = $ClientId.Trim()

if ([string]::IsNullOrWhiteSpace($SecretKey)) {
    throw 'SecretKey is empty after trim (check copy/paste; no trailing spaces).'
}

if ($env:OS -like '*Windows*') {
    try {
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
        [System.Net.ServicePointManager]::CheckCertificateRevocationList = $false
        Write-Host 'TLS: revocation check off for this session.'
    }
    catch {
        Write-Host ('TLS note: ' + $_.Exception.Message)
    }
}

if ([string]::IsNullOrWhiteSpace($ClientId) -and -not [string]::IsNullOrWhiteSpace($env:MASHHAD_SSO_CLIENT_ID)) {
    $ClientId = $env:MASHHAD_SSO_CLIENT_ID.Trim()
}
if ([string]::IsNullOrWhiteSpace($ClientId)) {
    throw 'ClientId required for body (e.g. 53db42619cf3C333b13a18D34fbd9111). Header apiName = -ApiName.'
}

function Get-Sha256Hex([string]$Text, [bool]$Upper) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $bytes = $sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Text))
    $hex = [BitConverter]::ToString($bytes).Replace("-", "")
    if ($Upper) { return $hex.ToUpperInvariant() }
    return $hex.ToLowerInvariant()
}

function Write-SsoOutboundPreview(
    [string]$Api,
    [string]$Cid,
    [string]$Secret,
    [string]$ReqTime,
    [bool]$Upper,
    [string]$BodyJson
) {
    $raw = $Secret + $ReqTime
    $hash = Get-Sha256Hex $raw $Upper
    $enc = if ($Upper) { 'upper' } else { 'lower' }

    Write-Host ''
    Write-Host '========== BEFORE SEND (exact values) =========='
    Write-Host '--- Request.Headers (SSO reads these) ---'
    Write-Host ('apiName     = ' + $Api)
    Write-Host ('requestTime = ' + $ReqTime)
    Write-Host ('apiSecret   = ' + $hash)
    Write-Host '--- Hash formula (SecretKey is NOT sent in header) ---'
    Write-Host ('SHA256(SecretKey + requestTime) hex ' + $enc)
    Write-Host ('SecretKey length = ' + $Secret.Length + ' chars')
    Write-Host ('Concat preview     = [SecretKey] + "' + $ReqTime + '"')
    Write-Host '--- Body JSON (loginKey) ---'
    Write-Host ('Time     = ' + $ReqTime + '  (must equal header requestTime)')
    Write-Host ('Hash     = ' + $hash + '  (must equal header apiSecret)')
    Write-Host ('ClientId = ' + $Cid + '  (body only; NOT header apiName)')
    Write-Host $BodyJson
    Write-Host '=============================================='
    Write-Host ''
}

function Invoke-LoginKey([string]$Api, [string]$Cid, [string]$Secret, [string]$ReqTime, [bool]$Upper) {
    $raw = $Secret + $ReqTime
    $hash = Get-Sha256Hex $raw $Upper
    $bodyObj = @{
        Time     = $ReqTime
        Hash     = $hash
        ClientId = $Cid
        State    = $State
        UserType = $UserType
        DomainID = $DomainID
    }
    $body = $bodyObj | ConvertTo-Json -Compress

    Write-SsoOutboundPreview -Api $Api -Cid $Cid -Secret $Secret -ReqTime $ReqTime -Upper $Upper -BodyJson $body

    if ($PrintOnly) {
        Write-Host 'PrintOnly: request NOT sent.'
        return $null
    }

    if ($PauseBeforeSend) {
        Read-Host 'Press Enter to POST loginKey to SSO'
    }

    Write-Host ('Sending POST ' + $BaseUrl + '/api/Authentication/loginKey (timeout ' + $RequestTimeoutSec + 's)...')

    $uri = $BaseUrl + '/api/Authentication/loginKey'
    $headers = @{
        apiName     = $Api
        requestTime = $ReqTime
        apiSecret   = $hash
    }
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $response = Invoke-WebRequest -Uri $uri -Method Post -Headers $headers `
            -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) `
            -ContentType 'application/json; charset=utf-8' `
            -TimeoutSec $RequestTimeoutSec -UseBasicParsing
        $sw.Stop()
        Write-Host ('HTTP ' + [int]$response.StatusCode + ' in ' + $sw.ElapsedMilliseconds + ' ms')
        Write-Host '--- Response ---'
        return ($response.Content | ConvertFrom-Json)
    }
    catch [System.Net.WebException] {
        $sw.Stop()
        $resp = $_.Exception.Response
        if ($null -ne $resp) {
            $reader = New-Object System.IO.StreamReader($resp.GetResponseStream())
            $text = $reader.ReadToEnd()
            $reader.Close()
            Write-Host ('HTTP ' + [int]$resp.StatusCode + ' in ' + $sw.ElapsedMilliseconds + ' ms')
            Write-Host '--- Response ---'
            if (-not [string]::IsNullOrWhiteSpace($text)) {
                return ($text | ConvertFrom-Json)
            }
        }
        Write-Host ('Failed: ' + $_.Exception.Message)
        throw
    }
}

Write-Host '== 1) GET getCurrentTime =='
$timeResp = Invoke-RestMethod -Uri ($BaseUrl + '/api/Authentication/getCurrentTime') -Method Get -TimeoutSec 60
$requestTime = [string]$timeResp.Data
if ([string]::IsNullOrWhiteSpace($requestTime)) { throw 'getCurrentTime returned no Data' }
Write-Host ('Data (will become header requestTime and body Time): ' + $requestTime)

$attempts = @(
    @{ Label = 'configured'; Api = $ApiName; Cid = $ClientId; Upper = [bool]$HashUpper }
)
if (-not $HashUpper -and -not $PrintOnly) {
    $attempts += @{ Label = 'hex upper retry'; Api = $ApiName; Cid = $ClientId; Upper = $true }
}

$last = $null
foreach ($a in $attempts) {
    Write-Host ''
    Write-Host ('== Attempt: ' + $a.Label + ' ==')
    $last = Invoke-LoginKey -Api $a.Api -Cid $a.Cid -Secret $SecretKey -ReqTime $requestTime -Upper $a.Upper
    if ($PrintOnly) { continue }
    if ($null -ne $last) {
        $last | ConvertTo-Json -Depth 5
    }
    if ($null -ne $last -and $last.ErrorCode -eq 0 -and $last.Data.loginKey) {
        Write-Host ('OK - loginKey: ' + $last.Data.loginKey)
        exit 0
    }
    if ($null -ne $last -and $last.ErrorCode -eq 403) { break }
}

if ($PrintOnly) { exit 0 }

Write-Host ''
if ($null -ne $last -and $last.ErrorCode -eq 403) {
    Write-Host '403 Client info missmatched - check apiName, ClientId body, SecretKey with SSO portal.'
}
exit 3
